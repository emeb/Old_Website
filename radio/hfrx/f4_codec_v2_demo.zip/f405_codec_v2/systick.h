/*
 * systick.h - 1ms system tick setup
 */

#ifndef __systick__
#define __systick__

#include "stm32f4xx.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"

void SysTick_Init(void);
uint8_t get_button(void);
int16_t get_encoder(void);

#endif
