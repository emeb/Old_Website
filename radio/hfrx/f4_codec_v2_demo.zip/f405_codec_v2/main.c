/* Bare-bones i2S setup for stm32f405_codec_v2 board              */
/* copied from stlink project of texane & updated for STM32F4 lib */
/* E. Brombaugh 06-07-2014                                        */

#include <stdio.h>
#include "stm32f4xx.h"
#include "codec.h"
#include "i2s.h"
#include "adc.h"
#include "audio.h"
#include "cyclesleep.h"
#include "systick.h"
#include "spi.h"
#include "st7735.h"
#include "usart.h"
#include "eeprom.h"

extern uint32_t SysTick_Counter;

/* DMA buffers for I2S */
__IO int16_t tx_buffer[DMA_BUFFSZ], rx_buffer[DMA_BUFFSZ];

/* DMA buffer for ADC  & copy */
__IO uint16_t adc_buffer[8];

/* text buffer for writing to display */
char textbuf[17];

#define LED_GREEN (1 << 9) /* port B, pin 9 */

static inline void setup_led(void)
{
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;

	GPIOB->MODER |= (1 << (9 * 2)) |	// LED
					(1 << (7 * 2)) | (1 << (6 * 2));	// Flags
	GPIOB->OSPEEDR |= (3 << (7 * 2)) | (3 << (6 * 2));	// Flags are fast
}

static inline void switch_leds(uint32_t leds)
{
	uint32_t temp = GPIOB->ODR;
	temp &= ~LED_GREEN;
	temp |= LED_GREEN & (leds << 9);
	GPIOB->ODR = temp;
}

static inline void switch_leds_off(void)
{
	GPIOB->ODR = 0;
}

void main(void)
{
	uint32_t state;
	int32_t idx;
	int16_t data;
	uint8_t ee_data, ee_result;
	
	cyccnt_enable();
	setup_led();
	SysTick_Init();

	/* Setup USART diag output */
	setup_usart();
	printf("\nSTM32F405 Codec V2...\n");
	
	/* Setup LCD */
	setup_spi();
	ST7735_init();
	ST7735_fillScreen(ST7735_BLACK);
	ST7735_drawstr( 0, 8 *  0, "1 Test..........", ST7735_WHITE, ST7735_BLACK);
	ST7735_drawstr( 0, 8 *  1, "2 Ph'nglui      ", ST7735_WHITE, ST7735_BLACK);
	ST7735_drawstr( 0, 8 *  2, "3 mglw'nafh     ", ST7735_WHITE, ST7735_BLACK);
	ST7735_drawstr( 0, 8 *  3, "4 Cthulhu R'lyeh", ST7735_WHITE, ST7735_BLACK);
	ST7735_drawstr( 0, 8 *  4, "5 wgah'nagl     ", ST7735_WHITE, ST7735_BLACK);
	ST7735_drawstr( 0, 8 *  5, "6 fhtagn.       ", ST7735_WHITE, ST7735_BLACK);
	ST7735_drawstr( 0, 8 *  9, "Realtime values ", ST7735_WHITE, ST7735_BLACK);
	ST7735_drawstr( 0, 8 * 10, "----------------", ST7735_WHITE, ST7735_BLACK);
	printf("LCD Up\n");

	/* Setup audio processing */
	Audio_Init();
	
	/* Start ADC */
	ADC1_Init((uint16_t *)adc_buffer);
	printf("ADC Up\n");
	
	/* Start Codec */
	Codec_Init(48000);
	printf("Codec Up\n");
	
	/* Start I2S data */
	I2S_Block_Init();
	I2S_Block_PlayRec((uint32_t)&tx_buffer, (uint32_t)&rx_buffer, DMA_BUFFSZ);
	printf("I2S Up\n");
	
	/* Test the EEPROM */
	ee_result = eeprom_ReadByte(0, &ee_data);
	printf("Read EEPROM @ 0: 0x%02X (result %d)\n", ee_data, ee_result);
	ee_data = 0x63;
	ee_result = eeprom_WriteByte(0, ee_data);
	printf("Write EEPROM @ 0: 0x%02X (result %d)\n", ee_data, ee_result);
	ee_result = eeprom_WaitEepromStandbyState();
	printf("Wait EEPROM (result %d)\n", ee_result);
	ee_result = eeprom_ReadByte(0, &ee_data);
	printf("Read EEPROM @ 0: 0x%02X (result %d)\n", ee_data, ee_result);
	ee_data = 0x37;
	ee_result = eeprom_WriteByte(0, ee_data);
	printf("Write EEPROM @ 0: 0x%02X (result %d)\n", ee_data, ee_result);
	ee_result = eeprom_WaitEepromStandbyState();
	printf("Wait EEPROM (result %d)\n", ee_result);
	ee_result = eeprom_ReadByte(0, &ee_data);
	printf("Read EEPROM @ 0: 0x%02X (result %d)\n", ee_data, ee_result);
	
	state = 0;
	
	while(1)
	{
#if 0
		switch_leds(state);

		state = (state + 1) & 1;
		
		delay(200);
#else
		/* Blink the heartbeat LED */
		switch_leds((SysTick_Counter>>8)&1);

		/* compute duty cycle of audio routine */
		uint32_t act, tot;
		get_meas(&act, &tot);
		float32_t duty = 100*(float32_t)act/(float32_t)tot;
		snprintf(textbuf, 17, "CPU: % 4d", (uint16_t)(duty+0.5));
		ST7735_drawstr( 0, 11 * 8, textbuf, ST7735_BLUE, ST7735_BLACK);

		/* update pot, buttons, encoder values on display */
		uint16_t encval = get_encoder();
		snprintf(textbuf, 17, "encoder: % 6d", encval);
		ST7735_drawstr( 0, 8 * 12, textbuf, ST7735_CYAN, ST7735_BLACK);

		for(idx=0;idx<4;idx++)
		{
			snprintf(textbuf, 17, "pot %2d: % 5d", idx, adc_buffer[idx]);
			ST7735_drawstr( 0, (13+idx)*8, textbuf, ST7735_MAGENTA, ST7735_BLACK);
		}

		encval = get_button();
		snprintf(textbuf, 17, "button: % 2d", encval);
		ST7735_drawstr( 0, 17*8, textbuf, ST7735_GREEN, ST7735_BLACK);
		
		/* don't cycle too fast */
		delay(10);
#endif
	}
}

#ifdef  USE_FULL_ASSERT

#define assert_param(expr) ((expr) ? (void)0 : assert_failed((uint8_t *)__FILE__, __LINE__))

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

#if 1
/* exception handlers - so we know what's failing */
void NMI_Handler(void)
{ 
	while(1){};
}

void HardFault_Handler(void)
{ 
	while(1){};
}

void MemManage_Handler(void)
{ 
	while(1){};
}

void BusFault_Handler(void)
{ 
	while(1){};
}

void UsageFault_Handler(void)
{ 
	while(1){};
}

void SVC_Handler(void)
{ 
	while(1){};
}

void DebugMon_Handler(void)
{ 
	while(1){};
}

void PendSV_Handler(void)
{ 
	while(1){};
}
#endif
