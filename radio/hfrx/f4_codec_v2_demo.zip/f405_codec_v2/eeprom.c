/*
 * eeprom.c - stm32f405_codec board eeprm interface routines
 *
 * NOTE: requires I2C peripheral initialized by codec routines
 */

#include "eeprom.h"
#include "codec.h"

__IO uint32_t  eepromTimeout = CODEC_LONG_TIMEOUT;   

#define EEPROM_ADDRESS           (0x50<<1)
#define sEE_MAX_TRIALS_NUMBER     300

/*
 * come here if I2C bus times out
 */
uint32_t eeprom_TIMEOUT_UserCallback(uint8_t status)
{
	/* nothing */
	return status;
}

/*
 * Start an eeprom transaction and send address
 */
uint8_t eeprom_SendAddr(uint16_t Addr)
{
	/* Split address for 24AA256 */
	uint8_t Byte1 = (Addr>>8)&0xFF;
	uint8_t Byte2 = Addr&0xFF;

	/*!< While the bus is busy */
	eepromTimeout = CODEC_LONG_TIMEOUT;
	while(I2C_GetFlagStatus(CODEC_I2C, I2C_FLAG_BUSY))
	{
		if((eepromTimeout--) == 0)
			return eeprom_TIMEOUT_UserCallback(1);
	}

	/* Start the config sequence */
	I2C_GenerateSTART(CODEC_I2C, ENABLE);

	/* Test on EV5 and clear it */
	eepromTimeout = CODEC_FLAG_TIMEOUT;
	while (!I2C_CheckEvent(CODEC_I2C, I2C_EVENT_MASTER_MODE_SELECT))
	{
		if((eepromTimeout--) == 0)
			return eeprom_TIMEOUT_UserCallback(2);
	}

	/* Transmit the slave address and enable writing operation */
	I2C_Send7bitAddress(CODEC_I2C, EEPROM_ADDRESS, I2C_Direction_Transmitter);

	/* Test on EV6 and clear it */
	eepromTimeout = CODEC_FLAG_TIMEOUT;
	while (!I2C_CheckEvent(CODEC_I2C, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
	{
		if((eepromTimeout--) == 0)
			return eeprom_TIMEOUT_UserCallback(3);
	}

	/* Transmit the first address byte for write operation */
	I2C_SendData(CODEC_I2C, Byte1);

	/* Test on EV8 and clear it */
	eepromTimeout = CODEC_FLAG_TIMEOUT;
	while (!I2C_CheckEvent(CODEC_I2C, I2C_EVENT_MASTER_BYTE_TRANSMITTING))
	{
		if((eepromTimeout--) == 0)
			return eeprom_TIMEOUT_UserCallback(4);
	}

	/* Transmit the second address byte */
	I2C_SendData(CODEC_I2C, Byte2);

	/*!< Wait till all data have been physically transferred on the bus */
	eepromTimeout = CODEC_LONG_TIMEOUT;
	while(!I2C_GetFlagStatus(CODEC_I2C, I2C_FLAG_BTF))
	{
		if((eepromTimeout--) == 0)
			return eeprom_TIMEOUT_UserCallback(5);
	}
	
	/* Done sending Address - return w/o error */
	return 0;
}

/*
 * Write a byte
 */
uint8_t eeprom_WriteByte(uint16_t WriteAddr, uint8_t Data)
{
	uint32_t result;
	
	/* Send Address */
	if((result = eeprom_SendAddr(WriteAddr)))
		return result;
	
	/* Transmit the data byte */
	I2C_SendData(CODEC_I2C, Data);

	/*!< Wait till all data have been physically transferred on the bus */
	eepromTimeout = CODEC_LONG_TIMEOUT;
	while(!I2C_GetFlagStatus(CODEC_I2C, I2C_FLAG_BTF))
	{
		if((eepromTimeout--) == 0)
			return eeprom_TIMEOUT_UserCallback(6);
	}

	/* End the configuration sequence */
	I2C_GenerateSTOP(CODEC_I2C, ENABLE);  

	/* Return the verifying value: 0 (Passed) or >0 (Failed) */
	return 0;  
}

/*
 * Read a byte
 */
uint8_t eeprom_ReadByte(uint16_t WriteAddr, uint8_t *Data)
{
	uint32_t result;
	
	/* Send Address */
	if((result = eeprom_SendAddr(WriteAddr)))
		return result;
	
	/* Send Start condition for receiving 3rd byte */
	I2C_GenerateSTART(CODEC_I2C, ENABLE);

	/* Test on EV5 and clear it */
	eepromTimeout = CODEC_FLAG_TIMEOUT;
	while (!I2C_CheckEvent(CODEC_I2C, I2C_EVENT_MASTER_MODE_SELECT))
	{
		if((eepromTimeout--) == 0)
			return eeprom_TIMEOUT_UserCallback(7);
	}

	/* Transmit the slave address and enable reading operation */
	I2C_Send7bitAddress(CODEC_I2C, EEPROM_ADDRESS, I2C_Direction_Receiver);

	/* Test on EV6 and clear it */
	eepromTimeout = CODEC_FLAG_TIMEOUT;
	while (!I2C_CheckEvent(CODEC_I2C, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))
	{
		if((eepromTimeout--) == 0)
			return eeprom_TIMEOUT_UserCallback(8);
	}

    /*!< Disable Acknowledgement */
    I2C_AcknowledgeConfig(CODEC_I2C, DISABLE);   
    
    /* Clear ADDR register by reading SR1 then SR2 register (SR1 has already been read) */
    (void)CODEC_I2C->SR2;
    
    /*!< Send STOP Condition */
    I2C_GenerateSTOP(CODEC_I2C, ENABLE);
    
    /* Wait for the byte to be received */
    eepromTimeout = CODEC_FLAG_TIMEOUT;
    while(I2C_GetFlagStatus(CODEC_I2C, I2C_FLAG_RXNE) == RESET)
    {
      if((eepromTimeout--) == 0)
		  return eeprom_TIMEOUT_UserCallback(9);
    }
	
    /*!< Read the byte received from the EEPROM */
    *Data = I2C_ReceiveData(CODEC_I2C);
    
    /* Wait to make sure that STOP control bit has been cleared */
    eepromTimeout = CODEC_FLAG_TIMEOUT;
    while(CODEC_I2C->CR1 & I2C_CR1_STOP)
    {
      if((eepromTimeout--) == 0)
		  return eeprom_TIMEOUT_UserCallback(10);
    }  
    
    /*!< Re-Enable Acknowledgement to be ready for another reception */
    I2C_AcknowledgeConfig(CODEC_I2C, ENABLE);    
    
	/* Return the verifying value: 0 (Passed) or >0 (Failed) */
	return 0;  
}

/*
 * Read an arbitrary-length buffer of data from the eeprom
 */
//uint32_t eeprom_ReadBuffer(uint8_t* pBuffer, uint16_t ReadAddr, uint16_t* NumByteToRead)
//{
//}

/*
 * write buffer of data from the eeprom
 */
//uint32_t eeprom_WritePage(uint8_t* pBuffer, uint16_t WriteAddr, uint8_t* NumByteToWrite)
//{
//}

/*
 * write an arbitrary-length buffer of data from the eeprom
 */
//void eeprom_WriteBuffer(uint8_t* pBuffer, uint16_t WriteAddr, uint16_t NumByteToWrite)
//{
//}

/*
 * Wait for eeprom to finish whatever it's doing
 */
//uint32_t eeprom_WaitEepromStandbyState(void)
//{
//}

/*
 * wait for write to complete
 */
uint8_t eeprom_WaitEepromStandbyState(void)      
{
  __IO uint16_t tmpSR1 = 0;
  __IO uint32_t sEETrials = 0;

  /*!< While the bus is busy */
  eepromTimeout = CODEC_LONG_TIMEOUT;
  while(I2C_GetFlagStatus(CODEC_I2C, I2C_FLAG_BUSY))
  {
    if((eepromTimeout--) == 0)
		return eeprom_TIMEOUT_UserCallback(1);
  }

  /* Keep looping till the slave acknowledge his address or maximum number 
     of trials is reached (this number is defined by sEE_MAX_TRIALS_NUMBER define
     in STM324x7I_eval_i2c_ee.h file) */
  while (1)
  {
    /*!< Send START condition */
    I2C_GenerateSTART(CODEC_I2C, ENABLE);

    /*!< Test on EV5 and clear it */
    eepromTimeout = CODEC_FLAG_TIMEOUT;
    while(!I2C_CheckEvent(CODEC_I2C, I2C_EVENT_MASTER_MODE_SELECT))
    {
      if((eepromTimeout--) == 0)
		  return eeprom_TIMEOUT_UserCallback(2);
    }    

    /*!< Send EEPROM address for write */
    I2C_Send7bitAddress(CODEC_I2C, EEPROM_ADDRESS, I2C_Direction_Transmitter);
    
    /* Wait for ADDR flag to be set (Slave acknowledged his address) */
    eepromTimeout = CODEC_LONG_TIMEOUT;
    do
    {     
      /* Get the current value of the SR1 register */
      tmpSR1 = CODEC_I2C->SR1;
      
      /* Update the timeout value and exit if it reach 0 */
      if((eepromTimeout--) == 0)
		  return eeprom_TIMEOUT_UserCallback(11);
    }
    /* Keep looping till the Address is acknowledged or the AF flag is 
       set (address not acknowledged at time) */
    while((tmpSR1 & (I2C_SR1_ADDR | I2C_SR1_AF)) == 0);
     
    /* Check if the ADDR flag has been set */
    if (tmpSR1 & I2C_SR1_ADDR)
    {
      /* Clear ADDR Flag by reading SR1 then SR2 registers (SR1 have already 
         been read) */
      (void)CODEC_I2C->SR2;
      
      /*!< STOP condition */    
      I2C_GenerateSTOP(CODEC_I2C, ENABLE);
        
      /* Exit the function */
      return 0;
    }
    else
    {
      /*!< Clear AF flag */
      I2C_ClearFlag(CODEC_I2C, I2C_FLAG_AF);                  
    }
    
    /* Check if the maximum allowed number of trials has bee reached */
    if (sEETrials++ == sEE_MAX_TRIALS_NUMBER)
    {
      /* If the maximum number of trials has been reached, exit the function */
      return eeprom_TIMEOUT_UserCallback(12);
    }
  }
}

