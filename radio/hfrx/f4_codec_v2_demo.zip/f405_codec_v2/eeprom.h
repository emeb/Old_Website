/*
 * eeprom.h - stm32f405_codec board eeprm interface routines
 *
 * NOTE: requires I2C peripheral initialized by codec routines
 */

#ifndef __eeprom__
#define __eeprom__

#include "stm32f4xx.h"

uint8_t eeprom_WriteByte(uint16_t WriteAddr, uint8_t Data);
uint8_t eeprom_ReadByte(uint16_t WriteAddr, uint8_t *Data);

//uint32_t eeprom_ReadBuffer(uint8_t* pBuffer, uint16_t ReadAddr, uint16_t* NumByteToRead);
//uint32_t eeprom_WritePage(uint8_t* pBuffer, uint16_t WriteAddr, uint8_t* NumByteToWrite);
//void     eeprom_WriteBuffer(uint8_t* pBuffer, uint16_t WriteAddr, uint16_t NumByteToWrite);
//uint32_t eeprom_WaitEepromStandbyState(void);

uint8_t eeprom_WaitEepromStandbyState(void);

#endif