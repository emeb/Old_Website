/*
 * si570.h - si570 driver
 * 07-20-14 E. Brombaugh
 */

#ifndef __si570__
#define __si570__

#include "stm32f37x.h"

typedef struct
{
	uint8_t raw_regs[6];
	uint8_t HS_DIV;
	uint8_t N1;
	uint64_t RFREQ;
	uint32_t FXTAL;
	uint64_t FDCO;
	uint8_t BAND;
	uint32_t FREQ;
} si570state;

uint16_t si5703_Init(si570state *s);
uint16_t si570_ReadReg(uint8_t Reg);
uint16_t si570_WriteReg(uint8_t RegName, uint8_t RegValue);
uint16_t si570_GetState(si570state *s);
uint16_t si570_DefaultState(si570state *s);
uint16_t si570_SetState(si570state *s);
uint16_t si570_FreqUpdate(si570state *s, uint32_t Freq);

#endif
