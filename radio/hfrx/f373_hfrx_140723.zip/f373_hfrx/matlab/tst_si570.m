% si570.m - test out Si570 math
% 07-21-14 E. Brombaugh

% Reg 7 : 0xE1
% Reg 8 : 0xC2
% Reg 9 : 0xB6
% Reg 10 : 0x79
% Reg 11 : 0xC2
% Reg 12 : 0xBA

regs_hex = ['E1' ; 'C2' ; 'B6' ; '79' ; 'C2' ; 'BA'];
regs = hex2dec(regs_hex);
Default_Freq = 56.32e6;

HS_DIV = floor(regs(1) / 2^5)+4;
N1 = mod(regs(1), 2^5)*4 + floor(regs(2) / 2^6) + 1;
RFREQ = mod(regs(2), 2^6)*2^32 + regs(3)*2^24 + regs(4)*2^16 + regs(5)*2^8 + regs(6);
FXTAL = (Default_Freq * HS_DIV * N1)/(RFREQ/2^28);
