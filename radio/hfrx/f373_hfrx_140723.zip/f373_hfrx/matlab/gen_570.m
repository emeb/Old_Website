% gen_570.m - make divider tables for si570

%% Constants
hs = [4 5 6 7 9 11];
n1 = [1 2:2:128];
vco_min = 4.85e9;
vco_max = 5.67e9;

%% Ordered Table of divisors with reversible index
mul = hs' * n1;
lmul = reshape(mul, 1, 6*65);
[smul, ridx] = sort(lmul);

%% Bands per divisor set
b_min = vco_min ./ smul;
b_max = vco_max ./ smul;

%span = b_max - b_min;
plot(b_min, 'r*');
hold on;
plot(b_max, 'g+');
hold off;

%% Eliminate redundant bands
band_idx = 1;
sz = length(lmul);
bands = zeros(1, sz);
bands(1) = 1;
band_num = 2;
running = 1;

while(running)
	% search for the next least overlapping band
	b_bot = b_min(band_idx);
	min_overlap = 1e38;
	min_overlap_idx = -1;
	for i=band_idx+1:sz
		overlap = b_max(i)-b_bot;
		if overlap > 0 & overlap < min_overlap
			min_overlap = overlap;
			min_overlap_idx = i;
		end
	end
	
	% save this band
	if min_overlap_idx ~= -1
		% found a min overlap band so that's the next one
		band_idx = min_overlap_idx;
		%fprintf(1,' ');
	else
		% didn't find a min overlap, so just use the next one
		band_idx = band_idx + 1;
		%fprintf(1,'x');
	end
	bands(band_num) = band_idx;
	band_num = band_num + 1;
	%fprintf(1,'Band %d: %d - %d\n', band_idx, b_min(band_idx), b_max(band_idx));
	
	if band_idx >= sz
		running = 0;
	end
end

% trim off empty bands
bands = bands(1:band_num-1);
sz = length(bands);

% reverse the index to get the HS_DIV and N1 values
HS_DIV = zeros(1,sz);
N1 = zeros(1,sz);
top = zeros(1,sz);
bottom = zeros(1,sz);
for i=1:sz
	band_idx = ridx(bands(i));
	DIV = lmul(band_idx);
	HS_DIV(i) = hs(mod((band_idx-1),6)+1);
	N1(i) = n1(floor((band_idx-1)/6)+1);
	top(i) = vco_max/DIV;
	bottom(i) = vco_min/DIV;
end

% reverse the order for min freq at start
HS_DIV = fliplr(HS_DIV);
N1 = fliplr(N1);
top = fliplr(top);
bottom = fliplr(bottom);

% dump tables as C arrays to file
ofile = fopen('si570_tables.h', 'w');
fprintf(ofile,'/* Si570 PLL divisor band tables */\n');
fprintf(ofile,'#define NUM_BANDS %d\n', sz);
fprintf(ofile,'const uint8_t HS_DIV[] =\n{\n');
for i=1:sz
	fprintf(ofile,'\t%d,\n', HS_DIV(i));
end
fprintf(ofile,'};\n');

fprintf(ofile,'const uint8_t N1[] =\n{\n');
for i=1:sz
	fprintf(ofile,'\t%d,\n', N1(i));
end
fprintf(ofile,'};\n');

fprintf(ofile,'const uint32_t BAND_TOP[] =\n{\n');
for i=1:sz
	fprintf(ofile,'\t%d,\n', floor(top(i)));
end
fprintf(ofile,'};\n');

fprintf(ofile,'const uint32_t BAND_BOT[] =\n{\n');
for i=1:sz
	fprintf(ofile,'\t%d,\n', floor(bottom(i)));
end
fprintf(ofile,'};\n');
fclose(ofile);
