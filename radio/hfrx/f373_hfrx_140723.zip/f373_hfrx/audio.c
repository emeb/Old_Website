/***********************************************************************
 *    Project:                                                         *
 *    Author:         Eric Brombaugh                                   *
 *    Company:        KBADC                                            *
 **********************************************************************//*
 * audio.c - Audio processing routines
 */
#include <stdio.h>
#include "audio.h"
#include "i2s_dac.h"

/* the SDADC input buffers */
extern __IO int16_t sdadc_data[];

/* sine LUT */
float32_t sine_lut[256];
float32_t i_dc_acc, q_dc_acc, am_dc_acc;
float32_t freq_norm;
int32_t phs, frq;

#define DC_SCALE (1.0F/1000.0F)

/**
  * @brief  This function sets up audio processing. 
  * @param  none
  * @retval none
  */
void Audio_Init(void)
{
	int16_t i;
	
	/* fill the sine LUT */
	for(i=0;i<256;i++)
		sine_lut[i] = sinf(6.2832F*(float32_t)i/256.0F);

	/* setup DC block */
	i_dc_acc = q_dc_acc = 0.0F;
	
	/* setup oscillator */
	phs = 0;
	frq = 0;
}

void Audio_SetFreq(int16_t FreqHz)
{
	freq_norm = 65536.0F*((float32_t)FreqHz/18750.0F);
	frq = (int32_t)(freq_norm) << 16;
}

int16_t Audio_GetFreq(void)
{
	freq_norm = (float32_t)(frq>>16);
	return (int16_t)(18750.0F*freq_norm/65536.0F);
}

/* interpolating LUT-based wavetable */
float32_t sine_wave(uint32_t phs)
{
	uint32_t phs_int = (uint32_t)phs >> 24;
	float32_t phs_frac = (phs & 0xFFFFFF)/16777216.0F;
	float32_t result = sine_lut[phs_int]*(1.0F-phs_frac);
	return result + sine_lut[(phs_int+1)&0xFF]*phs_frac;
}

/* Vector processing */
/**
  * @brief  This function handles I2S TX buffer processing. 
  * @param  dst - pointer to dest buffer
  * @param  chl - channel to start (0 or 2)
  * @retval none
  */
void Audio_Generate(__IO int16_t *dst, uint8_t buf)
{
	uint16_t index;
	int16_t *cpy = (int16_t *)sdadc_data, i, q;
	float32_t i_in, q_in;
	float32_t i_dcb, q_dcb;
	float32_t i_lo, q_lo;
	float32_t i_tuner, q_tuner;
	float32_t am_raw, am_dcb;
	float32_t i_det, q_det;
	
	/* process SDADC data to output buffer */
	for(index=0;index<I2S_DAC_BUFSZ/4;index++)
	{
		/* get input from SDADC & convert to float */
		i_in = (float32_t)*cpy++/32768.0F;
		q_in = (float32_t)*cpy++/32768.0F;

		/* DC blocker ------------------------------ */
		i_dcb = i_in - i_dc_acc;
		i_dc_acc += (i_dcb * DC_SCALE);
		q_dcb = q_in - q_dc_acc;
		q_dc_acc += (q_dcb * DC_SCALE);
		
		/* Tuner ----------------------------------- */
		/* get LO */
		i_lo = sine_wave(phs+(1<<30));
		q_lo = sine_wave(phs);
		
		/* mix */
		i_tuner = (i_dcb*i_lo)-(q_dcb*q_lo);
		q_tuner = (i_dcb*q_lo)+(q_dcb*i_lo);
		
		/* update LO */
		phs = phs+frq;
		
		/* filter ---------------------------------- */
		
		/* 
		/*
		 * detector - one of
		 *  AM (mag)
		 *  SSB (weaver)
		 *  NBFM (freq diff)
		 */
		 
		/* AM detector */
		am_raw = sqrtf(i_tuner*i_tuner + q_tuner*q_tuner);
		
		/* AM DC Block */
		am_dcb = am_raw - am_dc_acc;
		am_dc_acc += (am_dcb * DC_SCALE);
		
		i_det = q_det = am_dcb;
		
		/* Convert to integer and send to DAC */
		*dst++ = 32768*i_det;
		*dst++ = 32768*q_det;
	}
}
