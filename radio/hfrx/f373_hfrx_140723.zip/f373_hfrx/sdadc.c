/*
 * sdadc.c - dual-channel DMA SDADC
 * 07-06-14 E. Brombaugh
 */
 
#include "stm32f37x.h"
#include "sdadc.h"
#include "cyclesleep.h"

__IO int16_t sdadc_data[2*MAX_SAMPLES];
__IO uint32_t sdadc_dma_data[MAX_SAMPLES];

/* SDADC setup */
uint32_t setup_sdadc(void)
{
	SDADC_AINStructTypeDef SDADC_AINStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	DMA_InitTypeDef DMA_InitStructure;
	uint32_t SDADCTimeout = 0;

	/* Enable GPIO C Clock */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, ENABLE);
	
	/* Enable PC14 for output */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	/* SDADC APB2 interface clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SDADC1 |
		RCC_APB2Periph_SDADC2, ENABLE);

	/* PWR APB1 interface clock enable */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
	/* Enable SDADC analog interface */
	PWR_SDADCAnalogCmd(PWR_SDADCAnalog_1, ENABLE);
	PWR_SDADCAnalogCmd(PWR_SDADCAnalog_2, ENABLE);

	/* Set the SDADC divider for 18.75kHz sample rate */
	/* If Sysclk is 72MHz, SDADC divider should be 32 */
	RCC_SDADCCLKConfig(RCC_SDADCCLK_SYSCLK_Div32);

	/* GPIO_CLK Peripheral clock enable */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB | RCC_AHBPeriph_GPIOE, ENABLE);

	/* SDADC1 channel 6PM (PB0/PB1), SDADC2 channel 8PM (PE8/PE9) */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
	GPIO_Init(GPIOE, &GPIO_InitStructure);

	/* Select External reference: The reference voltage selection is available
	 only in SDADC1 and therefore to select the VREF for SDADC2/SDADC3, SDADC1
	 clock must be already enabled */
	SDADC_VREFSelect(SDADC_VREF_Ext);

	/* Insert delay equal to ~5 ms */
	delay(5);

	/* Enable SDADC */
	SDADC_Cmd(SDADC1, ENABLE);
	SDADC_Cmd(SDADC2, ENABLE);

	/* Enter initialization mode */
	SDADC_InitModeCmd(SDADC1, ENABLE);
	SDADC_InitModeCmd(SDADC2, ENABLE);
	SDADCTimeout = SDADC_INIT_TIMEOUT;
	/* wait for INITRDY flag to be set */
	while((SDADC_GetFlagStatus(SDADC1, SDADC_FLAG_INITRDY) == RESET) && (--SDADCTimeout != 0));

	if(SDADCTimeout == 0)
	{
		/* INITRDY flag can not set */
		return 1;
	}
	
	/* wait for 2nd SDADC */
	SDADCTimeout = SDADC_INIT_TIMEOUT;
	/* wait for INITRDY flag to be set */
	while((SDADC_GetFlagStatus(SDADC2, SDADC_FLAG_INITRDY) == RESET) && (--SDADCTimeout != 0));

	if(SDADCTimeout == 0)
	{
		/* INITRDY flag can not set */
		return 1;
	}

	/* Analog Input configuration conf0: use single ended zero reference */
	//SDADC_AINStructure.SDADC_InputMode = SDADC_InputMode_SEZeroReference;
	SDADC_AINStructure.SDADC_InputMode = SDADC_InputMode_Diff;
	SDADC_AINStructure.SDADC_Gain = SDADC_Gain_1;
	//SDADC_AINStructure.SDADC_CommonMode = SDADC_CommonMode_VSSA;
	SDADC_AINStructure.SDADC_CommonMode = SDADC_CommonMode_VDDA_2;
	SDADC_AINStructure.SDADC_Offset = 0;
	SDADC_AINInit(SDADC1, SDADC_Conf_0, &SDADC_AINStructure);
	SDADC_AINInit(SDADC2, SDADC_Conf_0, &SDADC_AINStructure);

	/* select SDADC channel 5 to use conf0 */
	SDADC_ChannelConfig(SDADC1, SDADC_Channel_6, SDADC_Conf_0);
	SDADC_ChannelConfig(SDADC2, SDADC_Channel_8, SDADC_Conf_0);

	/* select channels 5, 6 */
	SDADC_ChannelSelect(SDADC1, SDADC_Channel_6);
	SDADC_ChannelSelect(SDADC2, SDADC_Channel_8);
	
	/* Enable continuous mode */
	SDADC_ContinuousModeCmd(SDADC1, ENABLE);
	SDADC_ContinuousModeCmd(SDADC2, ENABLE);
	
	/* enable fast mode - we're not switching channels */
	SDADC_FastConversionCmd(SDADC1, ENABLE);
	SDADC_FastConversionCmd(SDADC2, ENABLE);
	
	/* SDACD2 synched to SDADC1 */
	SDADC_RegularSynchroSDADC1(SDADC2, ENABLE);
	
	/* Exit initialization mode */
	SDADC_InitModeCmd(SDADC1, DISABLE);
	SDADC_InitModeCmd(SDADC2, DISABLE);

	/* configure calibration to be performed on conf0 */
	SDADC_CalibrationSequenceConfig(SDADC1, SDADC_CalibrationSequence_1);
	SDADC_CalibrationSequenceConfig(SDADC2, SDADC_CalibrationSequence_1);
	
	/* start SDADC Calibration */
	SDADC_StartCalibration(SDADC1);
	SDADC_StartCalibration(SDADC2);
	
	/* Set calibration timeout: 5.12 ms at 6 MHz in a single calibration sequence */
	SDADCTimeout = SDADC_CAL_TIMEOUT;
	/* wait for SDADC Calibration process to end */
	while((SDADC_GetFlagStatus(SDADC1, SDADC_FLAG_EOCAL) == RESET) && (--SDADCTimeout != 0));

	if(SDADCTimeout == 0)
	{
		/* EOCAL flag can not set */
		return 2;
	}

	/* Set calibration timeout: 5.12 ms at 6 MHz in a single calibration sequence */
	SDADCTimeout = SDADC_CAL_TIMEOUT;
	/* wait for SDADC Calibration process to end */
	while((SDADC_GetFlagStatus(SDADC2, SDADC_FLAG_EOCAL) == RESET) && (--SDADCTimeout != 0));

	if(SDADCTimeout == 0)
	{
		/* EOCAL flag can not set */
		return 2;
	}

	/* Turn on DMA2 */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);

	/* SDADC1 uses DMA2 channel3 */
	DMA_DeInit(DMA2_Channel3);
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&SDADC1->RDATA12R;
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&sdadc_dma_data;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStructure.DMA_BufferSize = MAX_SAMPLES;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA2_Channel3, &DMA_InitStructure);
	DMA_ITConfig(DMA2_Channel3, DMA_IT_TC, ENABLE);
	DMA_Cmd(DMA2_Channel3, ENABLE);

	/* NVIC Configuration */
	NVIC_InitStructure.NVIC_IRQChannel = DMA2_Channel3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	SDADC_DMAConfig(SDADC1, SDADC_DMATransfer_Regular, ENABLE);

	/* Start a software start conversion */
	SDADC_SoftwareStartConv(SDADC1);

	return 0;
}

/**
  * @brief  This function handles SDADC1 DMA terminal count interrupt request.
  * @param  None
  * @retval : None
  */
void DMA2_Channel3_IRQHandler(void)
{
	uint32_t *intlv_array = (uint32_t *)sdadc_data;
	
	/* set the activity flag */
	GPIOC->BSRR = (1<<14);
	
	if(DMA2->ISR&DMA2_FLAG_TC3)
	{
		/* Transfer complete - copy DMA to saved data */
		uint16_t i;
		for(i=0;i<MAX_SAMPLES;i++)
			intlv_array[i] = sdadc_dma_data[i];

		DMA_ClearFlag(DMA2_FLAG_TC3);
	}
	
	/* clear the activity flag */
	GPIOC->BRR = (1<<14);
}
