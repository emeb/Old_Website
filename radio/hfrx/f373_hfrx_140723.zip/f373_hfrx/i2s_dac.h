/***********************************************************************
 *    Project:                                                         *
 *    Author:         Eric Brombaugh                                   *
 *    Company:        KBADC                                            *
 **********************************************************************/
/*
    i2s_dac.h - CS4344 I2S DAC driver
	Copyright 07-04-2014 E. Brombaugh
 */

#ifndef __i2s_dac__
#define __i2s_dac__

#define I2S_DAC_BUFSZ 32

void init_i2s_dac(void);

#endif
