/*
 * oled.c - spi driver for Adafruit SSD1306 OLED display
 * 07-10-14 E. Brombaugh
 */
 
#include "stm32f37x.h"
#include "oled.h"
#include "cyclesleep.h"
#include "font_8x8.h"

/* the local buffer of the display */
uint8_t display_buffer[SSD1306_LCDWIDTH*SSD1306_LCDHEIGHT/8];

/* oled setup */
void oled_init(void)
{
	uint16_t i;
	GPIO_InitTypeDef GPIO_InitStructure;
	SPI_InitTypeDef   SPI_InitStructure;

	/* USE SPI3 on PA1,3 */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);

	/* Connect PA1,PA3 to SPI3 CLK, DATA */
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource1, GPIO_AF_6);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_6);

	/* Configure GPIO as alternate function push-pull for SPI */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/* Configure GPIO function push-pull for cs, d/c, rst */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_2 | GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	/* Set initial state */
	OLED_CS_HIGH();
	OLED_DC_CMD();
	OLED_RST_HIGH();
	
	/* SPI3 configuration */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3, ENABLE);

	SPI_InitStructure.SPI_Direction = SPI_Direction_1Line_Tx;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_8;

	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI3, &SPI_InitStructure);

	SPI_RxFIFOThresholdConfig(SPI3, SPI_RxFIFOThreshold_QF);

	SPI_Cmd(SPI3, ENABLE);
	
	/* reset the OLED */
	OLED_RST_LOW();
	delay(1);
	OLED_RST_HIGH();
	
	/* init the OLED */
	oled_command(SSD1306_DISPLAYOFF);                    // 0xAE
    oled_command(SSD1306_SETDISPLAYCLOCKDIV);            // 0xD5
    oled_command(0x80);                                  // the suggested ratio 0x80
    oled_command(SSD1306_SETMULTIPLEX);                  // 0xA8
    oled_command(0x3F);                                  // max rows
    oled_command(SSD1306_SETDISPLAYOFFSET);              // 0xD3
    oled_command(0x0);                                   // no offset
    oled_command(SSD1306_SETSTARTLINE | 0x0);            // line #0
    oled_command(SSD1306_CHARGEPUMP);                    // 0x8D
	oled_command(0x14);                                  // internal VCC
    oled_command(SSD1306_MEMORYMODE);                    // 0x20
    oled_command(0x00);                                  // 0x0 act like ks0108
    oled_command(SSD1306_SEGREMAP | 0x1);
    oled_command(SSD1306_COMSCANDEC);
    oled_command(SSD1306_SETCOMPINS);                    // 0xDA
    oled_command(0x02);                                  // 0x02 or 0x12
    oled_command(SSD1306_SETCONTRAST);                   // 0x81
    oled_command(0x8F);
    oled_command(SSD1306_SETPRECHARGE);                  // 0xd9
	oled_command(0xF1);                                  // internal VCC
    oled_command(SSD1306_SETVCOMDETECT);                 // 0xDB
    oled_command(0x40);
    oled_command(SSD1306_DISPLAYALLON_RESUME);           // 0xA4
    oled_command(SSD1306_NORMALDISPLAY);                 // 0xA6
	oled_command(SSD1306_DISPLAYON);                     //--turn on oled panel

	/* clear the buffer */
	oled_clear(0);
	
	/* clear the display */
	oled_update();
}

/* Send a SPI byte */
void oled_writebyte(uint8_t Data)
{
	/* Wait until the transmit buffer is empty */
	while((SPI3->SR & SPI_I2S_FLAG_TXE) == (uint16_t)RESET)
	{
	}

	/* Send the byte */
	*(__IO uint8_t *) ((uint32_t)SPI3+0x0C) = Data;
	
	/* Wait for end of transaction */
	while((SPI3->SR & SPI_I2S_FLAG_BSY) == (uint16_t)SPI_I2S_FLAG_BSY)
	{
	}
}

/* Send a command byte */
void oled_command(uint8_t Command)
{
	OLED_CS_HIGH();
	OLED_DC_CMD();
	OLED_CS_LOW();
	oled_writebyte(Command);
	OLED_CS_HIGH();
}

/* Send a data byte */
void oled_data(uint8_t Data)
{
	OLED_CS_HIGH();
	OLED_DC_DATA();
	OLED_CS_LOW();
	oled_writebyte(Data);
	OLED_CS_HIGH();
}

/* fast clear the display buffer */
void oled_clear(uint8_t color)
{
	uint16_t i;
	uint8_t byte = (color == 1) ? 0xFF : 0x00;
	
	for(i=0;i<SSD1306_LCDWIDTH*SSD1306_LCDHEIGHT/8;i++)
	{
		display_buffer[i] = byte;
	}
}

/* fill display with a given byte */
void oled_update(void)
{
	uint16_t i;
	
	/* set up for fill */
	oled_command(SSD1306_SETLOWCOLUMN | 0x0);  // low col = 0
	oled_command(SSD1306_SETHIGHCOLUMN | 0x0);  // hi col = 0
	oled_command(SSD1306_SETSTARTLINE | 0x0); // line #0

	/* start data */
	OLED_CS_HIGH();
	OLED_DC_DATA();
	OLED_CS_LOW();

    for (i=0; i<(SSD1306_LCDWIDTH*SSD1306_LCDHEIGHT/8); i++)
	{
      oled_writebyte(display_buffer[i]);
    }
	
	/* finish data */
	OLED_CS_HIGH();
}

/* draw a single pixel */
void oled_drawPixel(uint8_t x, uint8_t y, uint8_t color)
{
	/* clip to display dimensions */
	if ((x >= SSD1306_LCDWIDTH) || (y >= SSD1306_LCDHEIGHT))
	return;

	/* re-arrange y for interleaving */
	if(y&1)
		y = (y>>1) + SSD1306_LCDHEIGHT/2;
	else
		y = (y>>1);
	
	/* plot */
	if (color == 1) 
		display_buffer[x+ (y/8)*SSD1306_LCDWIDTH] |= (1<<(y%8));  
	else
		display_buffer[x+ (y/8)*SSD1306_LCDWIDTH] &= ~(1<<(y%8)); 
}

void oled_xorPixel(uint8_t x, uint8_t y)
{
	/* clip to display dimensions */
	if ((x >= SSD1306_LCDWIDTH) || (y >= SSD1306_LCDHEIGHT))
	return;

	/* re-arrange y for interleaving */
	if(y&1)
		y = (y>>1) + SSD1306_LCDHEIGHT/2;
	else
		y = (y>>1);
	
	/* xor */
	display_buffer[x+ (y/8)*SSD1306_LCDWIDTH] ^= (1<<(y%8));  
}

/* get a single pixel */
uint8_t oled_getPixel(uint8_t x, uint8_t y)
{
	uint8_t result;
	
	/* clip to display dimensions */
	if ((x >= SSD1306_LCDWIDTH) || (y >= SSD1306_LCDHEIGHT))
	return 0;

	/* re-arrange y for interleaving */
	if(y&1)
		y = (y>>1) + SSD1306_LCDHEIGHT/2;
	else
		y = (y>>1);
	
	/* get byte @ coords */
	result = display_buffer[x+ (y/8)*SSD1306_LCDWIDTH];
	
	/* get desired bit */
	return (result >> (y%8)) & 1;
}

/* Draw character to the display buffer */
void oled_drawchar(uint8_t x, uint8_t y, uint8_t chr, uint8_t color)
{
	uint16_t i, j, col;
	uint8_t d;
	
	for(i=0;i<8;i++)
	{
		d = fontdata[(chr<<3)+i];
		for(j=0;j<8;j++)
		{
			if(d&0x80)
				col = color;
			else
				col = (~color)&1;
			
			oled_drawPixel(x+j, y+i, col);
			
			// next bit
			d <<= 1;
		}
	}
}

/* draw a string to the display */
void oled_drawstr(uint8_t x, uint8_t y, char *str, uint8_t color)
{
	uint8_t c;
	
	while((c=*str++))
	{
		oled_drawchar(x, y, c, color);
		x += 8;
		if(x>120)
			break;
	}
}

/* invert a rectangle in the buffer */
void oled_xorrect(uint8_t x, uint8_t y, uint8_t w, uint8_t h)
{
	uint8_t m, n=y, iw = w;
	
	/* scan vertical */
	while(h--)
	{
		m=x;
		w=iw;
		/* scan horizontal */
		while(w--)
		{
			/* invert pixels */
			oled_xorPixel(m++, n);
		}
		n++;
	}
}