/*
 * systick.c - 1ms system tick timer & related services.
 * 	- also handles button debounce, LED refresh
 */

#include "systick.h"
#include "debounce.h"

uint32_t SysTick_Counter;
int16_t enc_val;

debounce_state dbs_btn, dbs_enc;

/*
 * SysTick_Init - sets up all the System Tick and UI state
 */
void SysTick_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	/* enable clocks for GPIOB */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);

	/* init GPIO for button & switch inputs */
	/* encoder phases on PB[4] PB[5], button on PB[6] */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	/* set up debounce objects for buttons & phases */
	init_debounce(&dbs_btn, 15);
	init_debounce(&dbs_enc, 2);

	/* Init tick counter */
	SysTick_Counter = 0;

	/* Init encoder */
	enc_val = 0;

	/* start Tick IRQ */
	if(SysTick_Config(SystemCoreClock/1000))
	{
		/* Hang here to capture error */
		while(1);
	}
}

/*
 * SysTick_Handler - Called by System Tick IRQ @ 1ms intervals to update UI elements
 */
void SysTick_Handler(void)
{
	/* debounce button */
	debounce(&dbs_btn, (((~GPIOB->IDR) >> 6)&1));

	/* debounce encoder clk */
	debounce(&dbs_enc, (((~GPIOB->IDR) >> 5)&1));

	/* if rising edge of clock then sample alternate phase for count dir */
	if(dbs_enc.fe)
	{
		if(((~GPIOB->IDR) >> 4)&1)
		{
			enc_val++;
		}
		else
		{
			enc_val--;
		}
	}

	/* Update SysTick Counter */
	SysTick_Counter++;
}

/*
 * get_button(n) - returns state of button #n
 */

uint8_t get_button(void)
{
	return dbs_btn.state;
}

/*
 * Get encoder value and clear for next time
 */
int16_t get_encoder(void)
{
	int16_t result = enc_val;
	enc_val = 0;
	return result;
}
