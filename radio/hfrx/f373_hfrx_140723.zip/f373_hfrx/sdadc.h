/*
 * sdadc.h - dual-channel DMA SDADC
 * 07-06-14 E. Brombaugh
 */

#ifndef __sdadc__
#define __sdadc__

#define MAX_SAMPLES 8

#define SDADC_INIT_TIMEOUT   30 /* ~ about two SDADC clock cycles after INIT is set */
#define SDADC_CAL_TIMEOUT    4*30720 /*  ~5.12 ms at 6 MHz  in a single calibration sequence */
#define SDADC_VREF           (float) 3300  /* SDADC external reference is set to 3.3V */
#define SDADC_GAIN           (uint32_t) 1  /* SDADC internal gain is set to 1: update this define */
#define SDADC_RESOL          (uint32_t) 65535 /* 2e16 - 1 */

uint32_t setup_sdadc(void);

#endif
