/***********************************************************************
 *    Project:                                                         *
 *    Author:         Eric Brombaugh                                   *
 *    Company:        KBADC                                            *
 **********************************************************************/
/*
 * audio.h - audio processing routines
 */

#ifndef __audio__
#define __audio__

#include <stdint.h>
#include <math.h>
#include "stm32f37x.h"
#include "arm_math.h"

void Audio_Init(void);
void Audio_SetFreq(int16_t FreqHz);
int16_t Audio_GetFreq(void);
void Audio_Generate(__IO int16_t *dst, uint8_t buf);

#endif

