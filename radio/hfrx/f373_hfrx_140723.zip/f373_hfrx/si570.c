/*
 * si570.c - si570 driver
 * 07-20-14 E. Brombaugh
 */
 
#include "si570.h"
#include "cyclesleep.h"

/* some constants we use */
#define I2C2_TIMING               0xC062121F	/* 100kHz */
#define si570_FLAG_TIMEOUT        ((uint32_t)0x1000)
#define si570_LONG_TIMEOUT        ((uint32_t)(10 * si570_FLAG_TIMEOUT))    
#define si570_ADDR                0xAA   /* si570 address shifted up 1 */
#define si570_DEF_FREQ            56320000

/* these are the LUTs used to set the frequency */
#include "si570_tables.h"

__IO uint32_t  si570_Timeout = si570_LONG_TIMEOUT; 

/* si570 setup */
uint16_t si570_Init(si570state *s)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	I2C_InitTypeDef I2C_InitStructure;
	
	/* Configure the I2C clock source. The clock is derived from the SYSCLK */
	RCC_I2CCLKConfig(RCC_I2C2CLK_SYSCLK);

	/* Enable the I2C fast mode plus driving capability */
	SYSCFG_I2CFastModePlusConfig(SYSCFG_I2CFastModePlus_I2C2, ENABLE);

	/* Setup I2C */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);

	/* Connect PA9/10 to I2C */
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_4);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_4);

	/* Configure si570 Tx as alternate function open drain */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/* I2C configuration */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C2, ENABLE);
	
	I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
	I2C_InitStructure.I2C_AnalogFilter = I2C_AnalogFilter_Enable;
	I2C_InitStructure.I2C_DigitalFilter = 0x00;
	I2C_InitStructure.I2C_OwnAddress1 = 0x00;
	I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
	I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
	I2C_InitStructure.I2C_Timing = I2C2_TIMING;

	I2C_Init(I2C2, &I2C_InitStructure);

	I2C_Cmd(I2C2, ENABLE);
	
	/* initialize the state structure */
	return si570_DefaultState(s);
}

/*
 * just pass on the error number with bit 8 set
 */
uint16_t si570_TIMEOUT_UserCallback(uint16_t errnum)
{
	return 0x0100 | errnum;
}

/**
  * @brief  Read the specified register.
  * @param  Reg: specifies the register to be read.
  * @retval si570 register value, or error condition (bit 8 set)
  */
uint16_t si570_ReadReg(uint8_t Reg)
{   
	uint8_t RegValue;

	/* Test on BUSY Flag */
	si570_Timeout = si570_LONG_TIMEOUT;
	while(I2C_GetFlagStatus(I2C2, I2C_ISR_BUSY) != RESET)
	{
		if((si570_Timeout--) == 0)
			return si570_TIMEOUT_UserCallback(0);
	}

	/* Configure slave address, nbytes, reload, end mode and start or stop generation */
	I2C_TransferHandling(I2C2, si570_ADDR, 1, I2C_SoftEnd_Mode, I2C_Generate_Start_Write);

	/* Wait until TXIS flag is set */
	si570_Timeout = si570_LONG_TIMEOUT;
	while(I2C_GetFlagStatus(I2C2, I2C_ISR_TXIS) == RESET)
	{
		if((si570_Timeout--) == 0)
			return si570_TIMEOUT_UserCallback(1);
	}

	/* Send Register address */
	I2C_SendData(I2C2, Reg);

	/* Wait until TC flag is set */
	si570_Timeout = si570_LONG_TIMEOUT;
	while(I2C_GetFlagStatus(I2C2, I2C_ISR_TC) == RESET)
	{
		if((si570_Timeout--) == 0)
			return si570_TIMEOUT_UserCallback(2);
	}  

	/* Configure slave address, nbytes, reload, end mode and start or stop generation */
	I2C_TransferHandling(I2C2, si570_ADDR, 1, I2C_AutoEnd_Mode, I2C_Generate_Start_Read);

	/* Wait until RXNE flag is set */
	si570_Timeout = si570_LONG_TIMEOUT;
	while(I2C_GetFlagStatus(I2C2, I2C_ISR_RXNE) == RESET)    
	{
		if((si570_Timeout--) == 0)
			return si570_TIMEOUT_UserCallback(3);
	}

	/* Read data from RXDR */
	RegValue = I2C_ReceiveData(I2C2);

	/* Wait until STOPF flag is set */
	si570_Timeout = si570_LONG_TIMEOUT;
	while(I2C_GetFlagStatus(I2C2, I2C_ISR_STOPF) == RESET)   
	{
		if((si570_Timeout--) == 0)
			return si570_TIMEOUT_UserCallback(4);
	}

	/* Clear STOPF flag */
	I2C_ClearFlag(I2C2, I2C_ICR_STOPCF);

	/* return a Reg value */
	return (uint16_t)RegValue;  
}

/**
  * @brief  Write to the specified register.
  * @param  RegName: specifies the register to be written.
  * @param  RegValue: value to be written to si570 register.  
  * @retval None
  */
uint16_t si570_WriteReg(uint8_t RegName, uint8_t RegValue)
{
	/* Test on BUSY Flag */
	si570_Timeout = si570_LONG_TIMEOUT;
	while(I2C_GetFlagStatus(I2C2, I2C_ISR_BUSY) != RESET)
	{
		if((si570_Timeout--) == 0)
			return si570_TIMEOUT_UserCallback(0);
	}

	/* Configure slave address, nbytes, reload, end mode and start or stop generation */
	I2C_TransferHandling(I2C2, si570_ADDR, 2, I2C_AutoEnd_Mode, I2C_Generate_Start_Write);

	/* Wait until TXIS flag is set */
	si570_Timeout = si570_LONG_TIMEOUT;  
	while(I2C_GetFlagStatus(I2C2, I2C_FLAG_TXIS) == RESET)   
	{
		if((si570_Timeout--) == 0)
			return si570_TIMEOUT_UserCallback(1);
	}

	/* Send Register address */
	I2C_SendData(I2C2, RegName);

	/* Wait until TXIS flag is set */
	si570_Timeout = si570_LONG_TIMEOUT;
	while(I2C_GetFlagStatus(I2C2, I2C_FLAG_TXIS) == RESET)
	{
		if((si570_Timeout--) == 0)
			return si570_TIMEOUT_UserCallback(2);
	}

	/* Send Register Data */
	I2C_SendData(I2C2, RegValue);

	/* Wait until STOPF flag is set */
	si570_Timeout = si570_LONG_TIMEOUT;
	while(I2C_GetFlagStatus(I2C2, I2C_ISR_STOPF) == RESET)
	{
		if((si570_Timeout--) == 0)
			return si570_TIMEOUT_UserCallback(4);
	}   
	
	/* Clear STOPF flag */
	I2C_ClearFlag(I2C2, I2C_ICR_STOPCF);

	return 0;
}

/*
 * get si570 state
 */
uint16_t si570_GetState(si570state *s)
{
	uint8_t Reg, Data;
	
	/* get the current Si570 frequency control values */
	for(Reg=7;Reg<13;Reg++)
	{
		if((Data = si570_ReadReg(Reg))&0x0100)
			return Data;
		else
			s->raw_regs[Reg-7] = Data;
	}
	
	/* parse the PLL control fields */
	s->HS_DIV = ((s->raw_regs[0]>>5)&0x7)+4;
	s->N1 = (((s->raw_regs[0]&0x1f)<<2) | ((s->raw_regs[1]&0xC0)>>6))+1;
	s->RFREQ = (((uint64_t)(s->raw_regs[1])&0x3f)<<32) | 
				((uint64_t)(s->raw_regs[2])<<24) |
				((uint64_t)(s->raw_regs[3])<<16) |
				((uint64_t)(s->raw_regs[4])<<8)  |
				((uint64_t)(s->raw_regs[5])<<0);

	/* Success */
	return 0;
}

/*
 * get si570 default state and comput FXTAL
 */
uint16_t si570_DefaultState(si570state *s)
{
	uint16_t result;
	uint64_t temp;
	
	/* Initialize */
	result = si570_WriteReg(135, 0x80);
	if(result & 0x0100)
		return result | 0x0200;	// reset failed
	
	/* delay 10ms */
	delay(10);
		
	result = si570_WriteReg(135, 0x01);
	if(result & 0x0100)
		return result | 0x0400;	// reload failed
	
	/* delay 10ms */
	delay(10);
		
	/* Get State */
	result = si570_GetState(s);
	if(result & 0x0100)
		return result | 0x0800;	// getstate failed
	
	/* Update FDCO and FXTAL */
	s->FDCO = ((uint64_t)si570_DEF_FREQ * (uint64_t)(s->HS_DIV) * (uint64_t)s->N1);
	temp = s->FDCO<<28;
	s->FXTAL =  (uint32_t)(temp / s->RFREQ);
	s->BAND = 0xff;	/* default band isn't in the table */
	s->FREQ = si570_DEF_FREQ;
	
	/* Success */
	return 0;
}

/*
 * set si570 state
 */
uint16_t si570_SetState(si570state *s)
{
	uint8_t Reg, Data;
	uint16_t result;
	
	/* send the current frequency control values to the Si570 */
	for(Reg=7;Reg<13;Reg++)
	{
		result = si570_WriteReg(Reg, s->raw_regs[Reg-7]);
		if(result&0x0100)
			return result;
	}
}

/*
 * update state with new frequency
 */
uint16_t si570_FreqUpdate(si570state *s, uint32_t Freq)
{
	si570state tmp_s;
	uint16_t result;
	uint8_t i;
	
	/* copy the current state */
	memcpy(&tmp_s, s, sizeof(si570state));
	
	/* find a band that matches the desired frequency */
	for(i=0;i<NUM_BANDS;i++)
	{
		if((Freq >= BAND_BOT[i]) && (Freq <= BAND_TOP[i]))
			break;
	}
	if(i==NUM_BANDS)
		return 0x0100;
	
	/* Set the vars according to the band */
	tmp_s.FREQ = Freq;
	tmp_s.BAND = i;
	tmp_s.HS_DIV = HS_DIV[i];
	tmp_s.N1 = N1[i];
	tmp_s.FDCO = (uint64_t)Freq * tmp_s.HS_DIV * tmp_s.N1;
	tmp_s.RFREQ = (tmp_s.FDCO << 28)/(uint64_t)tmp_s.FXTAL;
	
	/* Now parse out into raw regs */
	tmp_s.raw_regs[0] = (((tmp_s.HS_DIV-4)&7)<<5) | (((tmp_s.N1-1)>>2)&31);
	tmp_s.raw_regs[1] = (((tmp_s.N1-1)&3)<<6) | ((tmp_s.RFREQ>>32)&63);
	tmp_s.raw_regs[2] = ((tmp_s.RFREQ>>24)&255);
	tmp_s.raw_regs[3] = ((tmp_s.RFREQ>>16)&255);
	tmp_s.raw_regs[4] = ((tmp_s.RFREQ>>8)&255);
	tmp_s.raw_regs[5] = ((tmp_s.RFREQ>>0)&255);
	
	/*
	 * can compare current & new to see if FREEZE M would work instead
	 * of FREEZE DCO. Compare FDCO values to see if delta > 3500 ppm.
	 */
	
	/* Freeze the output */
	result = si570_WriteReg(137, 0x10);
	if(result & 0x0100)
		return result | 0x0200;	// freeze failed
	
	/* send the data */
	result = si570_SetState(&tmp_s);
	if(result & 0x0100)
		return result | 0x0400;	// send failed
	
	/* Unfreeze the output */
	result = si570_WriteReg(137, 0x00);
	if(result & 0x0100)
		return result | 0x0800;	// unfreeze failed
	
	/* Recalibrate */
	result = si570_WriteReg(135, 0x40);
	if(result & 0x0100)
		return result | 0x1000;	// recalibrate failed
	
	/* update the state */
	memcpy(s, &tmp_s, sizeof(si570state));
	
	/* success */
	return 0;
}

