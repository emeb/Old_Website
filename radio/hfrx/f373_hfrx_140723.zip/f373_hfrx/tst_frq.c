/* tst_frq.c - test frequency calculations */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef float float32_t;

int main(int argc, char **argv)
{
	int16_t FreqHz;
	float32_t freq_norm;
	int32_t frq;
	
	if(argc>1)
		FreqHz = atoi(argv[1]);
	else
		FreqHz = 0;
	
	printf("FreqHz = %d\n", FreqHz);
	freq_norm = 65536.0F*((float32_t)FreqHz/18750.0F);
	printf("freq_norm = %f\n", freq_norm);
	frq = (int32_t)(freq_norm) << 16;
	printf("frq = %d\n", frq);
	freq_norm = (float32_t)(frq>>16);
	printf("freq_norm = %f\n", freq_norm);
	FreqHz = (int16_t)(18750.0F*freq_norm/65536.0F);
	printf("FreqHz = %d\n", FreqHz);
}
