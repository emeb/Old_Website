/*
 * systick.h - 1ms system tick setup
 */

#ifndef __systick__
#define __systick__

#include "stm32f37x.h"

void SysTick_Init(void);
uint8_t get_button(void);
int16_t get_encoder(void);

#endif
