/***********************************************************************
 *    Project:                                                         *
 *    Author:         Eric Brombaugh                                   *
 *    Company:        KBADC                                            *
 **********************************************************************/
/*
    i2s_dac.c - CS4344 I2S DAC driver
	Copyright 09-19-2013 E. Brombaugh
 */

#include <stdint.h>
#include "stm32f37x.h"
#include "i2s_dac.h"
#include "audio.h"

/* vector-based processing DMA buffers */
__IO int16_t I2S2_Buffer_Tx[I2S_DAC_BUFSZ];

void init_i2s_dac(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	DMA_InitTypeDef DMA_InitStructure;
	I2S_InitTypeDef I2S_InitStructure;
	NVIC_InitTypeDef   NVIC_InitStructure;
	uint16_t i;
	
	/* Enable I2S GPIO clocks */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA|RCC_AHBPeriph_GPIOB|
		RCC_AHBPeriph_GPIOD, ENABLE);

	/* Connect pins to I2S2 peripheral  */
	GPIO_PinAFConfig(GPIOD, GPIO_PinSource8, GPIO_AF_5);  /* SCLK */
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_5);  /* WS */
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource15, GPIO_AF_5); /* DOUT */
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource14, GPIO_AF_5); /* MCLK */
	
	/* I2S2 pins configuration: SCLK, MCLK, DOUT pins ---------------------*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	/* I2S2 pins configuration: WS pin */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
		
	/* ISR Diagnostic on B7 */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	/* DMA clock enable */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

	/* SPI3 and SPI2 clocks enable */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
	
	/* clear the buffer */
	for(i=0;i<I2S_DAC_BUFSZ;i++)
	{
		I2S2_Buffer_Tx[i] = 0;
	}

	/* I2S2 TX uses DMA1 channel5 */
	DMA_DeInit(DMA1_Channel5);
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&SPI2->DR;
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&I2S2_Buffer_Tx;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = I2S_DAC_BUFSZ;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA1_Channel5, &DMA_InitStructure);
	DMA_ITConfig(DMA1_Channel5, DMA_IT_TC | DMA_IT_HT, ENABLE);
	DMA_Cmd(DMA1_Channel5, ENABLE);

	/* I2S2 peripheral configuration */
	SPI_I2S_DeInit(SPI2);

	I2S_InitStructure.I2S_Standard = I2S_Standard_Phillips;
	I2S_InitStructure.I2S_DataFormat = I2S_DataFormat_16b;
	I2S_InitStructure.I2S_MCLKOutput = I2S_MCLKOutput_Enable;
	I2S_InitStructure.I2S_AudioFreq =  18750; //I2S_AudioFreq_96k;
	I2S_InitStructure.I2S_CPOL = I2S_CPOL_Low;
	I2S_InitStructure.I2S_Mode = I2S_Mode_MasterTx;

	I2S_Init(SPI2, &I2S_InitStructure);

	/* Enable the Tx DMA request */
	SPI_I2S_DMACmd(SPI2, SPI_I2S_DMAReq_Tx, ENABLE);

	/* Turn on DMA interrupts with priority */
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	/* Enable the I2S port */
	I2S_Cmd(SPI2, ENABLE);
}

/**
  * @brief  This function handles DMA1_Channel5 (I2S2) interrupt request.
			It is the first of the two I2S ISRs to run.
  * @param  None
  * @retval None
  */
void DMA1_Channel5_IRQHandler(void)
{
	/* Active ISR */
	GPIOB->BSRR = 1<<7;	/* RX */

	if(DMA1->ISR&DMA1_FLAG_HT5)
	{
		/* Half transfer - refill 1st half buffer*/
		Audio_Generate(&I2S2_Buffer_Tx[0], 0);
		DMA_ClearFlag(DMA1_FLAG_HT5);
	}
	
	if(DMA1->ISR&DMA1_FLAG_TC5)
	{
		/* Transfer complete - refill 2nd half buffer */
		Audio_Generate(&I2S2_Buffer_Tx[I2S_DAC_BUFSZ/2], 1);
		DMA_ClearFlag(DMA1_FLAG_TC5);
	}
	
	/* Inactive ISR */
	GPIOB->BRR = 1<<7;
}
