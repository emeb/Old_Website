/* STM32F373 HFRX prototype */
/* 07-23-2014 E. Brombaugh  */

#include <stdio.h>
#include <stdlib.h>
#include "stm32f37x.h"
#include "arm_math.h"
#include "cyclesleep.h"
#include "usart.h"
#include "sdadc.h"
#include "oled.h"
#include "systick.h"
#include "si570.h"
#include "menu.h"

extern uint32_t frq;
si570state si570_state;

/*
 * LED setup
 */
void setup_led(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* Enable GPIO C Clock */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, ENABLE);
	
	/* Enable PC15 for output */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
}

/*
 * Diagnostic - print the Si570 state
 */
void dump_si570(si570state *s)
{
	uint8_t i;
	
	printf("Si570 State:\n");
	for(i=0;i<6;i++)
		printf("Reg %d : 0x%02X\n", i+7, s->raw_regs[i]);
	printf("HS_DIV : %u\n", s->HS_DIV);
	printf("    N1 : %u\n", s->N1);
	printf("RFREQH : 0x%08X\n", (uint32_t)(s->RFREQ>>32));
	printf("RFREQL : 0x%08X\n", (uint32_t)(s->RFREQ&0xffffffff));
	printf(" FDCOH : 0x%08X\n", (uint32_t)(s->FDCO>>32));
	printf(" FDCOL : 0x%08X\n", (uint32_t)(s->FDCO&0xffffffff));
	printf(" FXTAL : %u\n", s->FXTAL);
	printf("  BAND : %u\n", s->BAND);
	printf("  FREQ : %u\n", s->FREQ);
}

int main(void)
{
	uint16_t result;
	
	/* start cycle counter */
	cyccnt_enable();
	
	/* Setup LED */
	setup_led();
	
	/* Setup USART diag output */
	setup_usart3();
	printf("\n----------------------------\n");
	printf("STM32F373 HFRX\n");
	
	/* Setup Systick & enc, button */
	SysTick_Init();
	printf("Systick initialized\n");
	
	/* init the oled */
	oled_init();
	printf("OLED initialized...\n");
	
	/* init the Si570 */
	if((result = si570_Init(&si570_state))==0)
	{
		printf("Si570 initialized...\n");
		//dump_si570(&si570_state);
		
		/* try to change frequency */
		if((result = si570_FreqUpdate(&si570_state, 40000000))==0)
		{
			printf("Frequency changed to %d\n", si570_state.FREQ);
			//dump_si570(&si570_state);
		}
		else
			printf("si570_FreqUpdate failed 0x%04X\n", result);
	}
	else
		printf("si570_Init failed 0x%04X\n", result);
	
	/* init the menu */
	menu_init();
	printf("Menu initialized...\n");
		
	/* init the Audio */
	Audio_Init();
	printf("Audio configured\n");
	
	/* init the I2S */
	init_i2s_dac();
	printf("I2S configured\n");

	/* Configure the SDADC */
	setup_sdadc();
	printf("SDADC configured\n");

	/* main loop */
	printf("Looping...\n");
	while(1)
	{
		menu_update();
	}
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

