/*
 * menu.h - UI menu driver for f373_hfrx project
 * 07-23-14 E. Brombaugh
 */

#ifndef __menu__
#define __menu__

void menu_init(void);
void menu_update(void);

#endif
