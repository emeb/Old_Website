/*
 * menu.c - UI menu driver for f373_hfrx project
 * 07-23-14 E. Brombaugh
 */

#include <stdio.h>
#include "menu.h"
#include "systick.h"
#include "si570.h"
#include "audio.h"

/* this is the LO generator state from main.c */
extern si570state si570_state;

/* local vars used by menu system */
int16_t prev_button;
char txt_buff[17];
uint32_t Dfreq;
int16_t Fbfo, Dbfo;
uint8_t cursor_loc, cursor_type;

/*
 * draw LO frequency
 */
void menu_LO_draw(void)
{
	snprintf(txt_buff,17,"LO: % 9u Hz", si570_state.FREQ/4);
	oled_drawstr(0,16,txt_buff, 1);
}

/*
 * draw BFO frequency
 */
void menu_BFO_draw(void)
{
	snprintf(txt_buff,17,"BFO:    % 5d Hz  ", Fbfo);
	oled_drawstr(0,24,txt_buff, 1);
}

/*
 * draw the cursor
 */
void menu_draw_cursor(void)
{
	uint8_t x,y;
	
	/* compute location of cursor */
	if(cursor_loc < 9)
	{
		/* In LO digits */
		x = (cursor_loc + 4)*8;
		y = 16;
	}
	else if(cursor_loc < 13)
	{
		/* In BFO digits */
		x = ((cursor_loc-9) + 9)*8;
		y = 24;
	}
	
	/* type 1 is value - use block invert */
	oled_xorrect(x, y + (cursor_type ? 0 : 7), 8, cursor_type ? 8 : 1);
}

/*
 * generate a power-of-10 digit increment
 */
int32_t menu_diginc(int16_t incdec, uint8_t digit)
{
	int32_t result=1;
	
	while(digit--)
		result *=10;
	
	return result*incdec;
}

/*
 * initialize the menu system
 */
void menu_init(void)
{
	/* init the state */
	Fbfo = 0;
	prev_button = -100;
	cursor_loc = 0;
	cursor_type = 0;

	/* init the display */
	oled_drawstr(0, 0," STM32F373 HFRX ", 1);
	oled_drawstr(0, 8,"----------------", 1);
	menu_LO_draw();
	menu_BFO_draw();
	oled_drawstr(0,32,"Fltr BW: xxxx Hz", 1);
	oled_drawstr(0,40,"Mod: AM         ", 1);
	oled_drawstr(0,48,"RSSI: xxx       ", 1);
	oled_drawstr(0,56,"                ", 1);
	menu_draw_cursor();
	oled_update();
}

/*
 * update the menu
 */
void menu_update(void)
{
	int16_t new_encoder, new_button;
 	uint16_t result;
	int16_t tempBFO;
	uint32_t tempLO;
	
	/* update location / value */
	new_encoder = get_encoder();
	if(new_encoder != 0)
	{
		printf("Encoder update: %d\n", new_encoder);
		if(cursor_type)
		{
			/* cursor type 1 => update value */
			if(cursor_loc<9)
			{
				/* Locations 0-8 are LO digits */
				tempLO = (si570_state.FREQ/4)+ menu_diginc(new_encoder, 8-cursor_loc);
				if(tempLO < 999999999)
				{
					si570_FreqUpdate(&si570_state, tempLO*4);
					printf("Flo (actual): %u\n", si570_state.FREQ);
					menu_LO_draw();
					menu_draw_cursor();
				}
			}
			else if(cursor_loc < 13)
			{
				/* Locations 9-12 are BFO digits */
				tempBFO = Fbfo + menu_diginc(new_encoder, 3-(cursor_loc-9));
				if((tempBFO <= 9375) && (tempBFO >= -9375))
				{
					Fbfo = tempBFO;
					Audio_SetFreq(Fbfo);
					printf("Fbfo: %d\n", Fbfo);
					menu_BFO_draw();
					menu_draw_cursor();
				}
			}
		}
		else
		{
			/* cursor type 0 => update location */
			menu_draw_cursor();
			cursor_loc += new_encoder;
			if(cursor_loc == 13)
				cursor_loc = 0;
			if(cursor_loc == 255)
				cursor_loc = 12;
			printf("cursor_loc = %d\n", cursor_loc);
			menu_draw_cursor();
		}
		oled_update();
	}
	
	/* Switch cursor types */
	new_button = get_button();
	if(new_button != prev_button)
	{
		printf("Button update: %d\n", new_button);
		prev_button = new_button;
		snprintf(txt_buff, 17, "btn = % 6d", new_button);
		if(new_button)
		{
			menu_draw_cursor();
			cursor_type = 1^cursor_type;
			menu_draw_cursor();
			oled_update();
		}
		printf("cursor_type: %d\n", cursor_type);
		
	}
}