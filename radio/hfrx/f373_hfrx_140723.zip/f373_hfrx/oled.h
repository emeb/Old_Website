/*
 * oled.h - spi driver for Adafruit SSD1306 OLED display
 * 07-10-14 E. Brombaugh
 */

#ifndef __oled__
#define __oled__

/* macros for bit twiddling */
#define OLED_CS_LOW()    GPIO_ResetBits(GPIOA, GPIO_Pin_0)
#define OLED_CS_HIGH()   GPIO_SetBits(GPIOA, GPIO_Pin_0)
#define OLED_DC_CMD()    GPIO_ResetBits(GPIOA, GPIO_Pin_2)
#define OLED_DC_DATA()   GPIO_SetBits(GPIOA, GPIO_Pin_2)
#define OLED_RST_LOW()   GPIO_ResetBits(GPIOA, GPIO_Pin_4)
#define OLED_RST_HIGH()  GPIO_SetBits(GPIOA, GPIO_Pin_4)

/* characteristics of this display */
#define SSD1306_LCDWIDTH 128
#define SSD1306_LCDHEIGHT 64

/* Commands */
#define SSD1306_SETCONTRAST 0x81
#define SSD1306_DISPLAYALLON_RESUME 0xA4
#define SSD1306_DISPLAYALLON 0xA5
#define SSD1306_NORMALDISPLAY 0xA6
#define SSD1306_INVERTDISPLAY 0xA7
#define SSD1306_DISPLAYOFF 0xAE
#define SSD1306_DISPLAYON 0xAF

#define SSD1306_SETDISPLAYOFFSET 0xD3
#define SSD1306_SETCOMPINS 0xDA

#define SSD1306_SETVCOMDETECT 0xDB

#define SSD1306_SETDISPLAYCLOCKDIV 0xD5
#define SSD1306_SETPRECHARGE 0xD9

#define SSD1306_SETMULTIPLEX 0xA8

#define SSD1306_SETLOWCOLUMN 0x00
#define SSD1306_SETHIGHCOLUMN 0x10

#define SSD1306_SETSTARTLINE 0x40

#define SSD1306_MEMORYMODE 0x20
#define SSD1306_COLUMNADDR 0x21
#define SSD1306_PAGEADDR   0x22

#define SSD1306_COMSCANINC 0xC0
#define SSD1306_COMSCANDEC 0xC8

#define SSD1306_SEGREMAP 0xA0

#define SSD1306_CHARGEPUMP 0x8D

#define SSD1306_EXTERNALVCC 0x1
#define SSD1306_SWITCHCAPVCC 0x2

// Scrolling #defines
#define SSD1306_ACTIVATE_SCROLL 0x2F
#define SSD1306_DEACTIVATE_SCROLL 0x2E
#define SSD1306_SET_VERTICAL_SCROLL_AREA 0xA3
#define SSD1306_RIGHT_HORIZONTAL_SCROLL 0x26
#define SSD1306_LEFT_HORIZONTAL_SCROLL 0x27
#define SSD1306_VERTICAL_AND_RIGHT_HORIZONTAL_SCROLL 0x29
#define SSD1306_VERTICAL_AND_LEFT_HORIZONTAL_SCROLL 0x2A

void oled_init(void);
void oled_writebyte(uint8_t Data);
void oled_command(uint8_t Command);
void oled_data(uint8_t Data);
void oled_clear(uint8_t color);
void oled_update(void);
void oled_drawPixel(uint8_t x, uint8_t y, uint8_t color);
void oled_xorPixel(uint8_t x, uint8_t y);
uint8_t oled_getPixel(uint8_t x, uint8_t y);
void oled_drawchar(uint8_t x, uint8_t y, uint8_t chr, uint8_t color);
void oled_drawstr(uint8_t x, uint8_t y, char *str, uint8_t color);
void oled_xorrect(uint8_t x, uint8_t y, uint8_t w, uint8_t h);

#endif
