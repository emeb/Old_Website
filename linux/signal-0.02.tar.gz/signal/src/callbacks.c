#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

/* why did I need to do this? */
void set_device(char *new_device);

extern GtkWidget *entry_device;

gboolean
on_window_main_delete_event            (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{

  gtk_main_quit();
  return TRUE;
}


void
on_entry_device_changed                (GtkEditable     *editable,
                                        gpointer         user_data)
{
  set_device(gtk_entry_get_text (GTK_ENTRY (editable)));
}

