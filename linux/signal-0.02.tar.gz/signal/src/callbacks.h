#include <gtk/gtk.h>


gboolean
on_window_main_delete_event            (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_entry_device_changed                (GtkEditable     *editable,
                                        gpointer         user_data);
