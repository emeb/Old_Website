/* functions to write .wav audiofiles */
/* 2002-12-10, E.Brombaugh            */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct waveformat 
{
  unsigned short formatTag;      /* format category  */
  unsigned short nChannels;      /* # of channels    */
  unsigned int nSamplesPerSec;   /* Sample rate      */
  unsigned int nAvgBytesPerSec;  /* for buffering    */
  unsigned short nBlockAlign;    /* Block Alignments */
  unsigned short nBitsPerSample; /* word size        */
};

unsigned short shortend(unsigned short);
unsigned int intend(unsigned int);

int readtag(FILE *file, char *tag)
{
  char buff[5];
  
  /* get a 32-bit chunk */
  if(!fread(buff, sizeof(char), 4, file))
    return -1;
  
  buff[4] = 0;
  
  return strncmp(buff, tag, 4);
}

unsigned char *read_wav(FILE *infile, size_t *bytes, int *rate, int *fmt, int *chl)
{
  unsigned long temp;
  struct waveformat wfmt;
  unsigned char *data;
  
  /* read the RIFF header*/
  if(readtag(infile, "RIFF"))
    return NULL;
  
  /* read a dummy - we won't key off of it */
  if(!fread(&temp, sizeof(long), 1, infile))
    return NULL;
  
  /* grab the next few tags */
  if(readtag(infile, "WAVE"))
    return NULL;
  if(readtag(infile, "fmt "))
    return NULL;
  
  /* This should be the size of a waveformat */
  if(!fread(&temp, sizeof(long), 1, infile))
    return NULL;
  if(temp != sizeof(struct waveformat))
    return NULL;
  
  /* grab the waveformat stucture */
  if(!fread(&wfmt, sizeof(struct waveformat), 1, infile))
    return NULL;
  if(wfmt.formatTag != 1)
    return NULL;
  *chl = wfmt.nChannels;
  *rate = wfmt.nSamplesPerSec;
  if(wfmt.nBlockAlign != 1)
    return NULL;
  *fmt = wfmt.nBitsPerSample;
  
  /* check the data tag */
  if(readtag(infile, "data"))
    return NULL;
  
  /* get the size of the data */
  if(!fread(&temp, sizeof(long), 1, infile))
    return NULL;
  *bytes = temp;
  
  /* allocate the memory */
  if(!(data = malloc(*bytes)))
    return NULL;
  
  /* get the data */
  if(!fread(data, *bytes, 1, infile))
    return NULL;
  
  return data;
}

