% plot_wavdump.m: plot fft of output from wavdump

% choose portion of wavdump to analyze
offset = 4096;
len = 4096;

% load the file
load -force out;
rate = out(1);
fmt = out(2);
chl = out(3);
samples = out(4);
data = out(5:samples+4);

% transform it
h = fft(data(offset:offset+len-1));
w = fftshift(rate*((1:len)-len/2)/len);

% plot it
maxf = 50;
grid;
plot(w(1:maxf),20*log10(abs(h(1:maxf))));

