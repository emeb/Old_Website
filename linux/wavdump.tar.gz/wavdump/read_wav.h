/* functions to read .wav audiofiles */
/* 2002-12-10, E.Brombaugh            */

#ifndef _read_wav_
#define _read_wav_

unsigned char *read_wav(FILE *infile, size_t *bytes, int *rate, int *fmt, int *chl);

#endif
