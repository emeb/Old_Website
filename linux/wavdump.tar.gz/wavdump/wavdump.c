/* tst_read_wav.c - test the read_wav() function */
/* 2002-12-10: E.Brombaugh */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "read_wav.h"

int main(int argc, char **argv)
{
  FILE *infile;
  unsigned char *data, *dataptr;
  short *sdataptr;
  size_t bytes;
  int rate, fmt, chl;
  int samples, i, j;
  if(argc < 2)
  {
    fprintf(stderr, "USAGE: %s <infile>\n", argv[0]);
    exit(-1);
  }
  
  if(!(infile = fopen(argv[1], "r")))
  {
    fprintf(stderr, "Couldn't open %s for input\n", argv[1]);
    exit(-1);
  }
  
  data = read_wav(infile, &bytes, &rate, &fmt, &chl);
  
  if(data <= 0)
    fprintf(stderr, "read_wav failed: %d\n", data);
  
  //fprintf(stdout, "%d\n", bytes);
  fprintf(stdout, "%d\n", rate);
  fprintf(stdout, "%d\n", fmt);
  fprintf(stdout, "%d\n", chl);
  
  samples = bytes / (fmt == 8 ? 1 : 2) / chl;
  fprintf(stdout, "%d\n", samples);
  
  dataptr = data;
  sdataptr = (short *)data;
  for(i=0;i<samples;i++)
  {
    for(j=0;j<chl;j++)
    {
      switch(fmt)
      {
        case 8:
          fprintf(stdout, "%d ", *dataptr++);
          break;
        
        case 16:
          fprintf(stdout, "%d ", *sdataptr++);
          break;
      }
    }
     
    fprintf(stdout, "\n");
  }
  
  if(data > 0)
    free(data);
    
  fclose(infile);
  
  return 0;
}
