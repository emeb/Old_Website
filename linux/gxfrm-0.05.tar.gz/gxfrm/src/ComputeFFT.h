/*
 * Header file for ComputeFFT()
 * a standard FFT routine.
 */
 
#ifndef _ComputeFFT_
#define _ComputeFFT_

void ComputeFFT(float data[],int n);

#endif

