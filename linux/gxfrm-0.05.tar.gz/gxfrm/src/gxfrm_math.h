/*
 * gxfrm_math.h - math/file header for gxfrm
 * 2001-03-07 E. Brombaugh created
 */
 
#define WNDW_RECT       0
#define WNDW_BLCKMNHRRS 1
#define WNDW_HAMMING    2
#define VIEW_TIME     0
#define VIEW_FREQ     1

#define MAXFFTLEN 4096

typedef struct
{
  char fname[256];
  int viewtype;
  int wndwtype;
  int fftlen;
  int offset;
  int columns;
  int chl;
  int rawlen;
  float *rawdata;
  float scale;
  float freq;
  float windowgain;
  float window[MAXFFTLEN];
  float fftdata[2*MAXFFTLEN];
}
gxfrm_math_block;

int gxfrm_math_init(gxfrm_math_block *gmb);

int gxfrm_math_load(gxfrm_math_block *gmb, char *fname);

int gxfrm_math_set_view(gxfrm_math_block *gmb, int view);

int gxfrm_math_set_len(gxfrm_math_block *gmb, int len);

int gxfrm_math_set_window(gxfrm_math_block *gmb, int wndw);

int gxfrm_math_set_offset(gxfrm_math_block *gmb, int offset);

int gxfrm_math_set_chl(gxfrm_math_block *gmb, int chl);

char *gxfrm_math_get_filename(gxfrm_math_block *gmb);

int gxfrm_math_get_size(gxfrm_math_block *gmb);

int gxfrm_math_get_columns(gxfrm_math_block *gmb);

float gxfrm_math_get_scale(gxfrm_math_block *gmb);

float gxfrm_math_get_freq(gxfrm_math_block *gmb);

float *gxfrm_math_calc(gxfrm_math_block *gmb);

void gxfrm_math_destroy(gxfrm_math_block *gmb);
