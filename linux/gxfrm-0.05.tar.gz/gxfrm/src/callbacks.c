/*
 * callbacks.c - UI interfaces for gxfrm
 * 2001-03-07 E. Brombaugh created
 * 2001-09-05 E. Brombaugh added reload
 * 2001-09-15 E. Brombaugh add scale, ref
 * 2002-09-22 E. Brombaugh converted to Gtk only w/o gettext
 */

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "gxfrm_draw.h"
#include "gxfrm_math.h"

#define gxfrm_VERSION "v 0.05"

extern GtkWidget *window_main;
extern GtkWidget *window_about;
extern GtkWidget *fileselection1;
extern GtkWidget *spinbutton_len;
extern GtkWidget *spinbutton_freq;
extern GtkWidget *spinbutton_db;
extern GtkWidget *spinbutton_ref;
extern GtkAdjustment *hscrollbar_pos_adj;
extern GtkWidget *radiobutton_view[2];
extern GtkWidget *radiobutton_win[3];

extern gxfrm_draw_block gdblock;
extern gxfrm_math_block gmblock;

gboolean
on_window_main_delete_event            (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  gtk_main_quit();
  return TRUE;
}


void
on_phase_plot_activate                 (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  static int do_phase = 0;

  /* this seems like a cheesy way to track the state */
  do_phase = 1-do_phase;
  gxfrm_draw_set_do_phase(&gdblock, do_phase);
  gxfrm_draw(&gdblock);
}


void
on_settin_chl_cmplx_activate           (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  gxfrm_math_set_chl(&gmblock, 0);
  gxfrm_draw_set_data(&gdblock, gxfrm_math_calc(&gmblock));
  gxfrm_draw(&gdblock);
}


void
on_setting_chl_swp_activate            (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  gxfrm_math_set_chl(&gmblock, 1);
  gxfrm_draw_set_data(&gdblock, gxfrm_math_calc(&gmblock));
  gxfrm_draw(&gdblock);
}


void
on_setting_chl_r_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  gxfrm_math_set_chl(&gmblock, 2);
  gxfrm_draw_set_data(&gdblock, gxfrm_math_calc(&gmblock));
  gxfrm_draw(&gdblock);
}


void
on_setting_chl_l_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  gxfrm_math_set_chl(&gmblock, 3);
  gxfrm_draw_set_data(&gdblock, gxfrm_math_calc(&gmblock));
  gxfrm_draw(&gdblock);
}


void
on_setting_chl_rl_activate             (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  gxfrm_math_set_chl(&gmblock, 4);
  gxfrm_draw_set_data(&gdblock, gxfrm_math_calc(&gmblock));
  gxfrm_draw(&gdblock);
}


gboolean
on_drawingarea1_configure_event        (GtkWidget       *widget,
                                        GdkEventConfigure *event,
                                        gpointer         user_data)
{
  gxfrm_draw_update_pixmap(&gdblock);
  gxfrm_draw(&gdblock);

  return FALSE;
}


gboolean
on_drawingarea1_expose_event           (GtkWidget       *widget,
                                        GdkEventExpose  *event,
                                        gpointer         user_data)
{
  gxfrm_draw(&gdblock);

  return FALSE;
}


/*
 * This is a home-made function that figures out which radiobutton is set
 */
int get_radiobutton_index(GtkWidget *buttons[], GtkToggleButton *thisbutton, int count)
{
  int i;
  
  for(i=0;i<count;i++)
    if((int)buttons[i] == (int)thisbutton)
      return i;
  
  return -1;
}


void
on_radiobutton_view_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  int view_type;
  
  if(gtk_toggle_button_get_active(togglebutton))
  {
    view_type = get_radiobutton_index(radiobutton_view, togglebutton, 2);
    gxfrm_math_set_view(&gmblock, view_type);
    gxfrm_draw_set_view(&gdblock, view_type);
    gxfrm_draw_set_data(&gdblock, gxfrm_math_calc(&gmblock));
    gxfrm_draw(&gdblock);
  }
}


void
on_button_reload_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
  gxfrm_loadfile(gmblock.fname);
}


void
on_radiobutton_win_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  int win_type;
  
  if(gtk_toggle_button_get_active(togglebutton))
  {
    win_type = get_radiobutton_index(radiobutton_win, togglebutton, 3);
    gxfrm_math_set_window(&gmblock, win_type);
    gxfrm_draw_set_data(&gdblock, gxfrm_math_calc(&gmblock));
    gxfrm_draw(&gdblock);
  }
}


void
on_spinbutton_len_changed              (GtkEditable     *editable,
                                        gpointer         user_data)
{
  int fft_len;
  
  fft_len = 1 << gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_len));
  gxfrm_draw_set_len(&gdblock, fft_len);
  hscrollbar_pos_adj->page_size = fft_len;
  gtk_adjustment_changed(hscrollbar_pos_adj);
  gxfrm_math_set_len(&gmblock, fft_len);
  gxfrm_draw_set_len(&gdblock, fft_len);
  gxfrm_draw_set_data(&gdblock, gxfrm_math_calc(&gmblock));
  gxfrm_draw(&gdblock);
}


void
on_spinbutton_freq_changed             (GtkEditable     *editable,
                                        gpointer         user_data)
{
  int freq;
  
  freq = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_freq));
  gxfrm_draw_set_freq(&gdblock, freq);
  gxfrm_draw(&gdblock);
}


void
on_spinbutton_ref_changed              (GtkEditable     *editable,
                                        gpointer         user_data)
{
  int ref;
  
  ref = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_ref));
  gxfrm_draw_set_ref(&gdblock, ref);
  gxfrm_draw(&gdblock);
}


void
on_spinbutton_db_changed               (GtkEditable     *editable,
                                        gpointer         user_data)
{
  int db;
  
  db = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_db));
  gxfrm_draw_set_db(&gdblock, db);
  gxfrm_draw(&gdblock);
}


void
on_about_button1_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
  gtk_widget_destroy (window_about);
  window_about = NULL;
}


void
on_file_ok_button1_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
  int status;
  char *filename, *nodir, title[256];
  int fft_len, freq;
  
  filename = gtk_file_selection_get_filename(GTK_FILE_SELECTION(fileselection1));
    
  status = gxfrm_math_load(&gmblock, filename);
  
  if(!status)
  {
    /* get rid of the file dialog */
    gtk_widget_destroy (fileselection1);
    fileselection1 = NULL;
    
    /* set the window title */
    strcpy(title, "gxfrm:");
    nodir = strrchr(filename, '/')+1;
    strncat(title, nodir, 251);
    gtk_window_set_title(GTK_WINDOW(window_main), title);
    
    /* setup all the widgets & state */
    hscrollbar_pos_adj->upper = gxfrm_math_get_size(&gmblock);
    hscrollbar_pos_adj->value = 0;
    fft_len = 1<<gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_len));
    hscrollbar_pos_adj->page_size = fft_len;
    gtk_adjustment_changed(hscrollbar_pos_adj);
    gxfrm_draw_set_offset(&gdblock, 0);
    gxfrm_draw_set_columns(&gdblock, gxfrm_math_get_columns(&gmblock));
    gxfrm_draw_set_scale(&gdblock, gxfrm_math_get_scale(&gmblock));
    freq = gxfrm_math_get_freq(&gmblock);
    gxfrm_draw_set_freq(&gdblock, freq);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spinbutton_freq), freq);
    
    /* calculate & draw */
    gxfrm_draw_set_data(&gdblock, gxfrm_math_calc(&gmblock));
    gxfrm_draw(&gdblock);
  }
  else
    fprintf(stderr, "gxfrm_load: error %d\n", status);
}

void
on_file_cancel_button1_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
  gtk_widget_destroy (fileselection1);
  fileselection1 = NULL;
}

/*
 * The following functions didn't get generated by Glade
 */

void
on_open1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  char *filename;
  
  if(fileselection1 == NULL)
  {
    fileselection1 = create_fileselection1();
    filename = gxfrm_math_get_filename(&gmblock);
    if(filename)
      gtk_file_selection_set_filename(GTK_FILE_SELECTION(fileselection1), filename);
    gtk_widget_show(fileselection1);
  }
}


void
on_about1_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  GtkWidget *label;

  if(window_about == NULL)
  {
    /* create the window */
    window_about = create_window_about ();
    
    /* Set the about box labels */
    label = lookup_widget (window_about, "label_about_version");
    gtk_label_set_text(GTK_LABEL(label), gxfrm_VERSION);
    label = lookup_widget (window_about, "label_about_date");
    gtk_label_set_text(GTK_LABEL(label), __DATE__);
    
    /* display the window */
    gtk_widget_show(window_about);
  }
}

void
on_hscrollbar_pos_adj_value_changed     (GtkAdjustment *adjustment,
                                         gpointer user_data)
{
  gxfrm_math_set_offset(&gmblock, hscrollbar_pos_adj->value);
  gxfrm_draw_set_offset(&gdblock, hscrollbar_pos_adj->value);
  gxfrm_draw_set_data(&gdblock, gxfrm_math_calc(&gmblock));
  gxfrm_draw(&gdblock);
}

/*
 * This doesn't really belong here, but it is a convenient place for it
 */
int
gxfrm_loadfile(char *filename)
{
  int status;
  int fft_len, freq;
    
  status = gxfrm_math_load(&gmblock, filename);
  
  if(!status)
  {
    /* setup all the widgets & state */
    hscrollbar_pos_adj->upper = gxfrm_math_get_size(&gmblock);
    hscrollbar_pos_adj->value = 0;
    fft_len = 1<<gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_len));
    hscrollbar_pos_adj->page_size = fft_len;
    gtk_adjustment_changed(hscrollbar_pos_adj);
    gxfrm_draw_set_offset(&gdblock, 0);
    gxfrm_draw_set_columns(&gdblock, gxfrm_math_get_columns(&gmblock));
    gxfrm_draw_set_scale(&gdblock, gxfrm_math_get_scale(&gmblock));
    freq = gxfrm_math_get_freq(&gmblock);
    gxfrm_draw_set_freq(&gdblock, freq);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spinbutton_freq), freq);
    
    /* calculate & draw */
    gxfrm_draw_set_data(&gdblock, gxfrm_math_calc(&gmblock));
    gxfrm_draw(&gdblock);
  }
  else
    fprintf(stderr, "gxfrm_loadfile: error %d\n", status);

  return status;
}

void
on_exit1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  gtk_main_quit();
}

