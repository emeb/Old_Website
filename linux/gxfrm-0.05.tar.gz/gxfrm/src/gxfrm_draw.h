/*
 * gxfrm_draw.h - header for gxfrm_draw
 * 2001-03-07 E. Brombaugh created
 * 2001-09-05 E. Brombaugh add command line file def
 * 2001-09-15 E. Brombaugh add scale, ref
 */

#define DATASZ 4096
#define DATAMAX 10

typedef struct
{
  int magic_cookie;
  float data_blue[DATASZ];
  float data_red[DATASZ];
  int offset;
  int len;
  int view;
  int do_phase;
  int columns;
  float scale;
  float freq;
  float dbs;
  float ref;
  int redraw_grid;
  int xcenter, ycenter;
  int xborder, yborder;
  int xmax, xmin;
  int ymax, ymin;
  float xscale, yscale;
  GtkWidget *drawingarea;
  GdkGC *GC_blue, *GC_red, *GC_white, *GC_black_solid, *GC_black_dash;
  GdkPixmap *GP_offscreen;
  GdkPixmap *GP_grid;
  GdkFont *GF_default;
  GdkVisual *gdk_visual1;
}
gxfrm_draw_block;

int gxfrm_draw_init(gxfrm_draw_block *gfb, GtkWidget *drawingarea);

void gxfrm_draw_update_pixmap(gxfrm_draw_block *gfb);

void gxfrm_draw(gxfrm_draw_block *gfb);

int gxfrm_draw_set_offset(gxfrm_draw_block *gfb, int offset);

int gxfrm_draw_set_len(gxfrm_draw_block *gfb, int len);

int gxfrm_draw_set_view(gxfrm_draw_block *gfb, int view);

int gxfrm_draw_set_columns(gxfrm_draw_block *gfb, int columns);

int gxfrm_draw_set_do_phase(gxfrm_draw_block *gfb, int do_phase);

int gxfrm_draw_set_scale(gxfrm_draw_block *gfb, float scale);

int gxfrm_draw_set_freq(gxfrm_draw_block *gfb, float freq);

int gxfrm_draw_set_db(gxfrm_draw_block *gfb, float dbs);

int gxfrm_draw_set_ref(gxfrm_draw_block *gfb, float ref);

void gxfrm_draw_set_data(gxfrm_draw_block *gfb, float data[]);

