/*
 * main.c - main routine for gxfrm
 * 2001-03-07 E. Brombaugh created
 * 2001-09-05 E. Brombaugh add command line file def
 * 2001-09-05 E. Brombaugh add scale, ref
 * 2002-09-22 E. Brombaugh converted to Gtk only w/o gettext
 */

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "interface.h"
#include "support.h"
#include "callbacks.h"
#include "gxfrm_draw.h"
#include "gxfrm_math.h"

GtkWidget *window_main;
GtkWidget *window_about;
GtkWidget *fileselection1;
GtkWidget *hscrollbar_pos;
GtkWidget *spinbutton_len;
GtkWidget *spinbutton_freq;
GtkWidget *spinbutton_db;
GtkWidget *spinbutton_ref;
GtkAdjustment *hscrollbar_pos_adj;
GtkWidget *radiobutton_view[2];
GtkWidget *radiobutton_win[3];

gxfrm_draw_block gdblock;
gxfrm_math_block gmblock;

int
main (int argc, char *argv[])
{
  GtkWidget *drawingarea1;

  gtk_set_locale ();
  gtk_init (&argc, &argv);

  add_pixmap_directory (PACKAGE_DATA_DIR "/pixmaps");
  add_pixmap_directory (PACKAGE_SOURCE_DIR "/pixmaps");

  /*
   * The following code was added by Glade to create one of each component
   * (except popup menus), just so that you see something after building
   * the project. Delete any components that you don't want shown initially.
   */
  window_main = create_window_main ();
  radiobutton_view[0] = lookup_widget (window_main, "radiobutton_time");
  radiobutton_view[1] = lookup_widget (window_main, "radiobutton_freq");
  radiobutton_win[0] = lookup_widget (window_main, "radiobutton_rect");
  radiobutton_win[1] = lookup_widget (window_main, "radiobutton_BH");
  radiobutton_win[2] = lookup_widget (window_main, "radiobutton_ham");
  spinbutton_len = lookup_widget (window_main, "spinbutton_len");
  spinbutton_freq = lookup_widget (window_main, "spinbutton_freq");
  spinbutton_db = lookup_widget (window_main, "spinbutton_db");
  spinbutton_ref = lookup_widget (window_main, "spinbutton_ref");
  drawingarea1 = lookup_widget (window_main, "drawingarea1");
  hscrollbar_pos = lookup_widget(window_main, "hscrollbar_pos");
  
  hscrollbar_pos_adj = gtk_range_get_adjustment(GTK_RANGE(hscrollbar_pos));
  gtk_signal_connect(GTK_OBJECT(hscrollbar_pos_adj),
                     "value_changed",
                     GTK_SIGNAL_FUNC(on_hscrollbar_pos_adj_value_changed),
                     NULL);
  
  gtk_widget_show (window_main);

  /*
   * Init the globals
   */
  gxfrm_draw_init(&gdblock, drawingarea1);
  gxfrm_math_init(&gmblock);
  
  /*
   * Load a file if given on the command line
   */
  if(argc > 1)
  {
    gxfrm_loadfile(argv[1]);
  }
  
  gtk_main ();

  /*
   * Clean up
   */
  gxfrm_math_destroy(&gmblock); 
  
  return 0;
}

