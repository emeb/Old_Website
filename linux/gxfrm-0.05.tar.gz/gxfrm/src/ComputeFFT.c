/*
 * ComputeFFT()
 * a standard FFT routine.
 *
 * This has been in my library for more than a decade - I'm not sure where
 * it came from, but I think it's from 'Numerical Methods in C'.
 * data is input/output array w/ interleaved real & imaginary values
 * n is size (power of 2) (number of real/imag pairs)
 */

#include <math.h>
#include "ComputeFFT.h"
	
#define swap(a,b)     tempr = (a); (a) = (b); (b) = tempr
#define TWO_PI        2*3.14159265358979

void ComputeFFT(float data[],int n)
{
  int N;		// total number of real numbers (2*n)
  int i,j;		// indexes
  int m,mmax,istep;
  float theta,wr,wi,wpr,wpi;
  float wtemp,tempr,tempi;
	
  N = n << 1;
	
  // Realign time sample inputs into bit reversed order
  j = n;
  for (i=2; i<N; i+=2)
  {
    if (j>i)
    {
      swap(data[i],data[j]);
      swap(data[i+1],data[j+1]);
    }
    m = n;
    while ((m>=2) && (j>=m))
    {
      j -= m;
      m >>= 1;
    }
    j += m;
  }
	
  // Compute frequency samples from realigned time samples
  mmax = 2;
  while (N>mmax)
  {
    istep = mmax << 1;
    theta = -TWO_PI/mmax;
    wtemp = sin(0.5*theta);
    wpr = -2.0*wtemp*wtemp;
    wpi = sin(theta);
    wr = 1.0;
    wi = 0.0;
    for (m=0; m<mmax; m+=2)
    {
      for (i=m; i<N; i+=istep)
      {
        j = i + mmax;
        tempr = wr*data[j] - wi*data[j+1];
        tempi = wr*data[j+1] + wi*data[j];
        data[j]   = data[i]   - tempr;
        data[j+1] = data[i+1] - tempi;
        data[i]   = data[i]   + tempr;
        data[i+1] = data[i+1] + tempi;
      }
      wr = (wtemp=wr)*wpr - wi*wpi + wr;
      wi = wi*wpr + wtemp*wpi + wi;
    }
    mmax = istep;
  }
}
