/*
 * gxfrm_math.c - math/file code for gxfrm
 * 2001-03-07 E. Brombaugh created
 * 2001-09-15 E. Brombaugh update freq clipping
 * 2002-12-10 E. Brombaugh add WAV file reader
 */

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

#include "gxfrm_math.h"
#include "read_wav.h"
#include "ComputeFFT.h"

#define TWO_PI    (2*3.14159265358979)

#define SEEK_SET  0
#define SEEK_CUR  1
#define SEEK_END  2

int findWAVdata(FILE *infile);
int findASCdata(FILE *infile, int *dsize, float *scale, int *columns);

int gxfrm_math_init(gxfrm_math_block *gmb)
{
  gmb->fname[0] = 0;
  gmb->freq = 0.0;
  gmb->columns = 0;
  gmb->scale = 0.0;
  gmb->rawlen = 0;
  gmb->rawdata = NULL;
  
  gxfrm_math_set_view(gmb, VIEW_TIME);
  gxfrm_math_set_len(gmb, 256);
  gxfrm_math_set_window(gmb, WNDW_RECT);
  gxfrm_math_set_offset(gmb, 0);

  return 0;
}

int gxfrm_math_load(gxfrm_math_block *gmb, char *fname)
{
  FILE *infile;
  long i;
  int err = 0;

  strncpy(gmb->fname, fname, 256);
    
  /*
   * Open the file, else return error
   */
  if(!(infile=fopen(gmb->fname,"rb")))
  {
    gmb->rawlen = 0;
    gmb->freq = 0.0;
    return -1; /* bad file */
  }

  /*
   * Load the data
   */
  if(findWAVdata(infile))
  {
    size_t bytes;
    int rate, fmt, chl, bps;
    unsigned char *data, *dataptr;
    short *sdataptr;
    
    /* free the previous data */
    if(gmb->rawdata)
      free(gmb->rawdata);

    /* this should always succeed */
    data = read_wav(infile, &bytes, &rate, &fmt, &chl);
    
    gmb->freq = rate;
    gmb->columns  = chl;
    gmb->scale = fmt == 8 ? 128 : 32768;
    
    /* figure out how many samples */
    bps = (fmt == 8 ? 1 : 2) * chl;
    gmb->rawlen = bytes / bps;
    
    if((gmb->rawdata=(float *)calloc(gmb->rawlen*2+1, sizeof(float)))==0)
    {
      gmb->rawlen = 0;
      gmb->freq = 0.0;
      err = -2; /* out of memory */
    }
    else
    {
      dataptr = data;
      sdataptr = (short *)data;
      for(i=0;i<gmb->rawlen;i++)
      {
        if(gmb->columns == 2)
        {
          if(fmt == 8)
          {
            gmb->rawdata[i*2] = (*dataptr++) - 128;
            gmb->rawdata[i*2+1] = (*dataptr++) - 128;
          }
          else
          {
            gmb->rawdata[i*2] = (*sdataptr++);
            gmb->rawdata[i*2+1] = (*sdataptr++);
          }
        }
        else
        {
          if(fmt == 8)
          {
            gmb->rawdata[i*2] = (*dataptr++) - 128;
            gmb->rawdata[i*2+1] = 0.0;
          }
          else
          {
            gmb->rawdata[i*2] = (*sdataptr++);
            gmb->rawdata[i*2+1] = 0.0;
          }
        }
        gmb->rawdata[i*2] /= gmb->scale;
        gmb->rawdata[i*2+1] /= gmb->scale;
      }
    }
    
    /* we're done with the wav data */
    free(data);
  }
  else if(findASCdata(infile, &gmb->rawlen, &gmb->scale, &gmb->columns))
  {
    gmb->freq = 50000.0;
      
    if(gmb->rawdata)
      free(gmb->rawdata);

    if((gmb->rawdata=(float *)calloc(gmb->rawlen*2+1, sizeof(float)))==0)
    {
      gmb->rawlen = 0;
      gmb->freq = 0.0;
      err = -2; /* out of memory */
    }
    else
    {
      for(i=0;i<gmb->rawlen;i+=1)
      {
        if(gmb->columns == 2)
          fscanf(infile,"%f\t%f\n",&gmb->rawdata[i*2], &gmb->rawdata[i*2+1]);
        else
        {
          fscanf(infile,"%f\n",&gmb->rawdata[i*2]);
          gmb->rawdata[i*2+1] = 0.0;
        }
        gmb->rawdata[i*2] /= gmb->scale;
        gmb->rawdata[i*2+1] /= gmb->scale;
      }
    }
  }
  else
    err = -3; /* unsupported data */
  
  fclose(infile);
  
  gmb->offset = 0;
  
  return err;
}

/*
 * Set the View type & check for errors
 */
int gxfrm_math_set_view(gxfrm_math_block *gmb, int view)
{
  int err = 0;
  
  switch(view)
  {
    case VIEW_TIME:
    case VIEW_FREQ:
      gmb->viewtype = view;
      break;
    
    default:
      gmb->viewtype = VIEW_TIME;
      err = 1;
  }
  
  return err;
}

/*
 * Set the FFT length & check for errors
 */
int gxfrm_math_set_len(gxfrm_math_block *gmb, int len)
{
  int err = 0;
  
  
  switch(len)
  {
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
      gmb->fftlen = len;
      break;
    
    default:
      gmb->fftlen = 256;
      err = 1;
  }
  
  return err;
}

/*
 * Set the Window type & check for errors
 */
int gxfrm_math_set_window(gxfrm_math_block *gmb, int wndw)
{
  int i, err=0;
  float a;
   
  gmb->wndwtype = wndw;
   
  switch(gmb->wndwtype)
  {
    case WNDW_RECT:
      gmb->windowgain = 1.0;
      break;

    case WNDW_BLCKMNHRRS:
      for(i=0;i<MAXFFTLEN;i++)
      {
        a= TWO_PI * (float)i / (float)MAXFFTLEN;
        gmb->window[i] = 0.35875 -
                         0.48829*cos(a) +
                         0.14128*cos(2.0*a) -
                         0.01168*cos(3.0*a);
      }
      gmb->windowgain = 0.36;
      break;

    case WNDW_HAMMING:
      for(i=0;i<MAXFFTLEN;i++)
      {
        a= TWO_PI * (float)i / (float)MAXFFTLEN;
        gmb->window[i] = 0.54 - 0.46*cos(a);
      }
      gmb->windowgain = 0.54;
      break;
   
    default:
      gmb->windowgain = 1.0;
      gmb->wndwtype = WNDW_RECT;
      err = 1;
  }
  
  return err;
}

/*
 * Set the offset into the data & check for errors
 */
int gxfrm_math_set_offset(gxfrm_math_block *gmb, int offset)
{
  int err = 0;
  
  if (offset < 0)
  {
    offset = 0;
    err = 1;
  }
  
  if(offset > gmb->rawlen)
  {
    offset = gmb->rawlen;
    err = 1;
  }
  
  gmb->offset = offset;
  
  return err;
}

/*
 * Set the channel selection & check for errors
 */
int gxfrm_math_set_chl(gxfrm_math_block *gmb, int chl)
{
  int err = 0;
  
  if((chl < 0) || (chl > 4))
  {
    chl = 0;
    err = 1;
  }
  
  gmb->chl = chl;
  
  return err;
}

/*
 * Get the filename
 */
char *gxfrm_math_get_filename(gxfrm_math_block *gmb)
{
  return gmb->fname;
}

/*
 * Get the data size
 */
int gxfrm_math_get_size(gxfrm_math_block *gmb)
{
  return gmb->rawlen;
}

/*
 * Get the columns
 */
int gxfrm_math_get_columns(gxfrm_math_block *gmb)
{
  return gmb->columns;
}

/*
 * Get the scale
 */
float gxfrm_math_get_scale(gxfrm_math_block *gmb)
{
  return gmb->scale;
}

/*
 * Get the frequency
 */
float gxfrm_math_get_freq(gxfrm_math_block *gmb)
{
  return gmb->freq;
}

/*
 * Return pointer to time/freq data
 */
float *gxfrm_math_calc(gxfrm_math_block *gmb)
{
  int i,rei,imi,offset,wi;
  float real, imag, temp;
  float mag, phase, *data, gain;

  data = gmb->fftdata;  /* shorten up that pointer name */

  if(gmb->rawlen == 0)
    return NULL;        /* don't try it if there's no data */

  /*
   * Copy the data from the raw buffer to the FFT array & window
   */
  for(i=0;i<gmb->fftlen;i++)
  {
    /* compute the source addresses */
    rei = i<<1;
    imi = rei+1;
    offset = gmb->offset << 1;
    
    /* get the data - pad if beyond end */
    if(i >= gmb->rawlen)
    {
      real = 0.0;
      imag = 0.0;
    }
    else
    {
      real = gmb->rawdata[rei+offset];
      imag = gmb->rawdata[imi+offset];
    }
    
    /* apply the window */
    if(gmb->wndwtype != 0)
    {
      wi = i * MAXFFTLEN/gmb->fftlen;
      real *= gmb->window[wi];
      imag *= gmb->window[wi];
    }
    
    /* mangle the channels */
    switch(gmb->chl)
    {
      case 0: /* complex - do nothing */
        break;
      
      case 1: /* complex swap - reverse real/imag */
        temp = real;
        real = imag;
        imag = temp;
        break;
        
      case 2: /* right - real is right channel */
        real = imag;
        imag = 0.0;
        break;
      
      case 3: /* left - real is left channel */
        imag = 0.0;
        break;
      
      case 4: /* right + left - real is sum/2 */
        real = (real + imag)/2;
        imag = 0.0;
    }
        
    /* at last, save in the FFT array */
    data[rei] = real;
    data[imi] = imag;
  }

  /*
   * If Freq view, compute FFT, adjust gain & compute log mag & phase.
   */
  if(gmb->viewtype == VIEW_FREQ)
  {
    ComputeFFT(data, gmb->fftlen);
    gain = gmb->fftlen * gmb->windowgain;
    for(i=0;i<gmb->fftlen;i++)
    {
      rei = i <<1;
      imi = rei+1;
      mag = hypot(data[rei], data[imi])/gain;
      mag = 20.0 * log10(mag);
      phase = atan2(data[imi], data[rei])/TWO_PI;
      data[rei] = mag;
      data[imi] = phase;
    }
  }
  
  return data;
}

/*
 * Free any memory we may have allocated
 */
void gxfrm_math_destroy(gxfrm_math_block *gmb)
{
    if(gmb->rawdata)
      free(gmb->rawdata);
}
  
/*
 * Check for WAV data file
 */
int findWAVdata(FILE *infile)
{
   size_t bytes;
   int rate, fmt, chl;
   unsigned char *data;
   
   /* try to open the wav file */
   data = read_wav(infile, &bytes, &rate, &fmt, &chl);
   
   /* rewind file to beginning for next search */
   fseek(infile, 0, SEEK_SET);
         
   if(data == 0)
   {
      return 0;
   }
   else
   {
      free(data);
      return 1;
   }
}

/*
 * Check for ASCII data file
 */
int findASCdata(FILE *infile, int *dsize, float *scale, int *columns)
{
   char text[80]; 
   int argc = 0, running = 1;
   float fl1, fl2, min = 1e38, max = -1e38;

   *dsize = 0;

   while(running)
   {
      if(fgets(text,80,infile))
      {
         argc = sscanf(text,"%f\t%f\n",&fl1,&fl2);
         if((argc == 1) || (argc == 2))
         {
            (*dsize)++;
            max = (max > fl1) ? max : fl1;
            max = (max > fl2) ? max : fl2;
            min = (min < fl1) ? min : fl1;
            min = (min < fl2) ? min : fl2;
         }
         else
            running = 0;
      }
      else
         running = 0;
   }

   fseek(infile, 0, SEEK_SET);   /* rewind to beginning for next search */

   min = fabs(min);
   max = (max > min) ? max : min;
   *scale = max;
   
   *columns = argc;
   
   if(*dsize == 0)
      return 0;
   else
      return 1;
}
