/*
 * gxfrm_draw.c - drawing code for gxfrm
 * 2001-03-07 E. Brombaugh created
 * 2001-09-15 E. Brombaugh add db scale, ref level
 * 2002-09-22 E. Brombaugh converted to Gtk only w/o gettext
 */

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>

#include "gxfrm_draw.h"

/*
 * Initialize the draw structure
 */
int gxfrm_draw_init(gxfrm_draw_block *gfb, GtkWidget *drawingarea)
{
  int i;
  GdkColormap *gcm1;
  GdkColor color;
  gchar dashlist[2];
  GdkGCValues values;
  
  /*
   * set the cookie!
   */
  gfb->magic_cookie = 0xdeadbeef;
  
  /*
   * copy the drawingarea into our struct
   */
  gfb->drawingarea = drawingarea;
  
  /*
   * Create the pixmaps
   */
  gxfrm_draw_update_pixmap(gfb);
  
  /*
   * Get the default font
   */
  gdk_gc_get_values(gfb->drawingarea->style->fg_gc[gfb->drawingarea->state],
                    &values);
  gfb->GF_default = values.font;

  
  /*
   * set up colors
   */
  gcm1 = gdk_window_get_colormap(drawingarea->window);
  gdk_colormap_ref(gcm1);
  gfb->gdk_visual1 = gdk_window_get_visual(drawingarea->window);
  gdk_visual_ref(gfb->gdk_visual1);
  
  /* Blue on White context */
  gfb->GC_blue = gdk_gc_new(drawingarea->window);
  color.red = 0;
  color.green = 0;
  color.blue = 0xffff;
  gdk_color_alloc(gcm1, &color);
  gdk_gc_set_foreground(gfb->GC_blue, &color);
  color.red = 0xffff;
  color.green = 0xffff;
  color.blue = 0xffff;
  gdk_color_alloc(gcm1, &color);
  gdk_gc_set_background(gfb->GC_blue, &color);
  
  /* Red on White context */
  gfb->GC_red = gdk_gc_new(drawingarea->window);
  color.red = 0xffff;
  color.green = 0;
  color.blue = 0;
  gdk_color_alloc(gcm1, &color);
  gdk_gc_set_foreground(gfb->GC_red, &color);
  color.red = 0xffff;
  color.green = 0xffff;
  color.blue = 0xffff;
  gdk_color_alloc(gcm1, &color);
  gdk_gc_set_background(gfb->GC_red, &color);

  /* White on White context */
  gfb->GC_white = gdk_gc_new(drawingarea->window);
  color.red = 0xffff;
  color.green = 0xffff;
  color.blue = 0xffff;
  gdk_color_alloc(gcm1, &color);
  gdk_gc_set_foreground(gfb->GC_white, &color);
  color.red = 0xffff;
  color.green = 0xffff;
  color.blue = 0xffff;
  gdk_color_alloc(gcm1, &color);
  gdk_gc_set_background(gfb->GC_white, &color);
  
  /* Solid Black on White context */
  gfb->GC_black_solid = gdk_gc_new(drawingarea->window);
  color.red = 0;
  color.green = 0;
  color.blue = 0;
  gdk_color_alloc(gcm1, &color);
  gdk_gc_set_foreground(gfb->GC_black_solid, &color);
  color.red = 0xffff;
  color.green = 0xffff;
  color.blue = 0xffff;
  gdk_color_alloc(gcm1, &color);
  gdk_gc_set_background(gfb->GC_black_solid, &color);
  
  /* Dashed Black on White context */
  gfb->GC_black_dash = gdk_gc_new(drawingarea->window);
  color.red = 0;
  color.green = 0;
  color.blue = 0;
  gdk_color_alloc(gcm1, &color);
  gdk_gc_set_foreground(gfb->GC_black_dash, &color);
  color.red = 0xffff;
  color.green = 0xffff;
  color.blue = 0xffff;
  gdk_color_alloc(gcm1, &color);
  gdk_gc_set_background(gfb->GC_black_dash, &color);
  gdk_gc_set_line_attributes(gfb->GC_black_dash, 1, GDK_LINE_ON_OFF_DASH,
                             GDK_CAP_ROUND, GDK_JOIN_ROUND);
  dashlist[0] = 3;
  dashlist[1] = 7;
  gdk_gc_set_dashes(gfb->GC_black_dash, 0, dashlist, 2);
  
  gdk_colormap_unref(gcm1);
  gdk_visual_unref(gfb->gdk_visual1);
  
  /*
   * init the data array
   */
  for(i=0;i<DATASZ;i++)
  {
    gfb->data_blue[i] = 0.0;
    gfb->data_red[i] = 0.0;
  }
  gfb->len = 256;
  gfb->offset = 0;
  
  /*
   * init the control vars
   */
  gfb->view = 0;
  gfb->scale = 2.0;
  gfb->freq = 1.0;
  gfb->do_phase = 0;
  gfb->redraw_grid = 1;
  gfb->dbs = 120.0;
  gfb->ref = 0.0;

  return FALSE;
}

/*
 * Resize or create the offscreen pixmaps
 */
void gxfrm_draw_update_pixmap(gxfrm_draw_block *gfb)
{

  /*
   * Check the cookie
   */
  if(gfb->magic_cookie != 0xdeadbeef)
    return;
  
  if(gfb->GP_offscreen != NULL)
  {
    /*
     * Destroy the pixmap
     */
     gdk_pixmap_unref(gfb->GP_offscreen);
     gdk_pixmap_unref(gfb->GP_grid);
  }
  
  /*
   * Create a pixmap to draw offscreen
   */
  gfb->GP_offscreen = gdk_pixmap_new(gfb->drawingarea->window,
                                     gfb->drawingarea->allocation.width,
                                     gfb->drawingarea->allocation.height,
                                     -1);
  gfb->GP_grid = gdk_pixmap_new(gfb->drawingarea->window,
                                gfb->drawingarea->allocation.width,
                                gfb->drawingarea->allocation.height,
                                -1);
  
  gfb->redraw_grid = 1;

}

/*
 * set up the grid offscreen
 */
void gxfrm_draw_grid(gxfrm_draw_block *gfb)
{
  int i;
  int width, height;
  int x1, y1, x2, y2;
  float vscale;
  float xtic, ytic;
  char text[80];
  int txwid;
  
  /* Compute some common values */
  width = gfb->drawingarea->allocation.width;
  height = gfb->drawingarea->allocation.height;
  gfb->xcenter = width>>1;
  gfb->ycenter = height>>1;
  sprintf(text, " %6.1f ", -10000.0);
  gfb->xborder = gdk_text_width(gfb->GF_default, text, strlen(text));
  gfb->yborder = 24;
  gfb->ymax = gfb->yborder;
  gfb->ymin = height - gfb->yborder;
  gfb->xmax = width - gfb->xborder;
  gfb->xmin = gfb->xborder;
  gfb->xscale = (float)(gfb->xmax - gfb->xmin);
  gfb->yscale = (float)(gfb->ymax - gfb->ymin);
  
  /* clear the grid pixmap */
  gdk_draw_rectangle (gfb->GP_grid,
                      gfb->GC_white,
                      TRUE,
                      0,
                      0,
                      width,
                      height);
  
  /* draw the grid */
  switch(gfb->view)
  {
    case 1: /* Freq view */
      /* draw the y axis */
      gdk_draw_line(gfb->GP_grid,
                    gfb->GC_black_solid,
                    gfb->xmin,
                    gfb->ymin,
                    gfb->xmin,
                    gfb->ymax);
  
      /* draw the y gridlines and legend */
      x1 = (int)(gfb->yscale/-19.0);
      vscale = gfb->yscale/gfb->dbs;
      for(ytic=0.0;ytic>=-gfb->dbs;ytic-=gfb->dbs/(float)x1)
      {
        y1 = gfb->ymax + (int)(vscale * ytic);
        gdk_draw_line(gfb->GP_grid,
                      gfb->GC_black_dash,
                      gfb->xmin,
                      y1,
                      gfb->xmax,
                      y1);
                      
        /* the magnitude legend */
        sprintf(text, "%6.1f ", ytic+gfb->ref);
        txwid = gdk_text_width(gfb->GF_default,
                               text,
                               strlen(text));
        x2 = gfb->xmin - txwid;
        y2 = y1+5;
        gdk_draw_string(gfb->GP_grid,
                        gfb->GF_default,
                        gfb->GC_black_solid,
                        x2,
                        y2,
                        text);
                      
        if(gfb->do_phase)
        {
          /* the phase legend */
          sprintf(text, " %6.1f", 180.0+(360.0*ytic/gfb->dbs));
          x2 = gfb->xmax;
          y2 = y1+5;
          gdk_draw_string(gfb->GP_grid,
                          gfb->GF_default,
                          gfb->GC_black_solid,
                          x2,
                          y2,
                          text);
        }
      }
      
      /* draw the x axis */
      gdk_draw_line(gfb->GP_grid,
                    gfb->GC_black_solid,
                    gfb->xmin,
                    gfb->ymin,
                    gfb->xmax,
                    gfb->ymin);
      
      /* draw the x gridlines and legend */
      xtic = (float)gfb->xmin;
      y2 = gfb->ymin+16;
      x1 = (int)(gfb->xscale/50.0);
      x1 = x1 & (~1);
      for(i=0;i<=x1;i++)
      {
        gdk_draw_line(gfb->GP_grid,
                      gfb->GC_black_dash,
                      (int)xtic,
                      gfb->ymin,
                      (int)xtic,
                      gfb->ymax);
        sprintf(text, "%d", (i-(x1>>1))*(int)gfb->freq/x1);
        txwid = gdk_text_width(gfb->GF_default,
                               text,
                               strlen(text));
        x2 = (int)xtic -(txwid/2);
        gdk_draw_string(gfb->GP_grid,
                        gfb->GF_default,
                        gfb->GC_black_solid,
                        x2,
                        y2,
                        text);
        xtic += gfb->xscale/(float)x1;
      }
      break;
      
    case 0: /* Time view */
      /* draw the y axis */
      gdk_draw_line(gfb->GP_grid,
                  gfb->GC_black_solid,
                  gfb->xmin,
                  gfb->ymin,
                  gfb->xmin,
                  gfb->ymax);
  
      /* draw the y grid and legend */
      x1 = (int)(gfb->yscale/-20.0);
      x1 = x1 & (~1);
      vscale = gfb->yscale / 2.0;
      for(ytic=-1.0;ytic<=1.0;ytic+=2.0/(float)x1)
      {
        y1 = gfb->ycenter + (int)(vscale * ytic);
        gdk_draw_line(gfb->GP_grid,
                      gfb->GC_black_dash,
                      gfb->xmin,
                      y1,
                      gfb->xmax,
                      y1);
        sprintf(text, "%6.1f ", ytic*gfb->scale);
        txwid = gdk_text_width(gfb->GF_default,
                               text,
                               strlen(text));
        x2 = gfb->xmin - txwid;
        y2 = y1+5;
        gdk_draw_string(gfb->GP_grid,
                        gfb->GF_default,
                        gfb->GC_black_solid,
                        x2,
                        y2,
                        text);
      }
      
      /* draw the x axis */
      gdk_draw_line(gfb->GP_grid,
                    gfb->GC_black_solid,
                    gfb->xmin,
                    gfb->ycenter,
                    gfb->xmax,
                    gfb->ycenter);
      
      /* draw the x gridlines and legend */
      xtic = (float)gfb->xmin;
      y2 = gfb->ymin+16;
      x1 = (int)(gfb->xscale/50.0);
      for(i=0;i<=x1;i++)
      {
        gdk_draw_line(gfb->GP_grid,
                      gfb->GC_black_dash,
                      (int)xtic,
                      gfb->ymin,
                      (int)xtic,
                      gfb->ymax);
        sprintf(text, "%d", gfb->offset + (i*gfb->len)/x1);
        txwid = gdk_text_width(gfb->GF_default,
                               text,
                               strlen(text));
        x2 = (int)xtic -(txwid/2);
        gdk_draw_string(gfb->GP_grid,
                        gfb->GF_default,
                        gfb->GC_black_solid,
                        x2,
                        y2,
                        text);
        xtic += gfb->xscale/(float)x1;
      }      
  }
  
  gfb->redraw_grid = 0;
}

/*
 * Draw based on the settings in the structure
 */
void gxfrm_draw(gxfrm_draw_block *gfb)
{
  int i, index;
  int x1, x2, y1, y2, y1i, y2i;
  float vscale;
  char text[80];
  int txwid;
  
  /* Check the cookie */
  if(gfb->magic_cookie != 0xdeadbeef)
    return;
  
  /* Check if we need to redraw the grid */
  if(gfb->redraw_grid)
    gxfrm_draw_grid(gfb);
  
  /*
   * Display warning if no data
   */
  if(0)
  {
    sprintf(text, "No Data");
    txwid = gdk_text_width(gfb->GF_default, text, strlen(text));    
    gdk_draw_string(gfb->GP_offscreen,
                    gfb->GF_default,
                    gfb->GC_black_solid,
                    gfb->xcenter - (txwid/2),
                    gfb->ycenter,
                    text);
    return;
  }
  
  /* Copy the grid onto our offscreen */
  gdk_draw_pixmap(gfb->GP_offscreen,
                  gfb->GC_red,
                  gfb->GP_grid,
                  0,
                  0,
                  0,
                  0,
                  -1,
                  -1);
  
  /* draw the data on the offscreen */
  switch(gfb->view)
  {
    case 1: /* Freq view */      
      /* draw the log magnitude and phasedata */
      vscale = gfb->yscale/gfb->dbs;
      y1 = (int)(vscale*(-gfb->ref + gfb->data_blue[gfb->len>>1])) + gfb->ymax;
      y1 = (y1>gfb->ymin) ? gfb->ymin : y1;
      y1 = (y1<gfb->ymax) ? gfb->ymax : y1;
      y1i = (int)(gfb->yscale*gfb->data_red[gfb->len>>1]) + gfb->ycenter;
      x1 = gfb->xmin;
      for(i=1;i<gfb->len;i++)
      {
        index = ((gfb->len >> 1) + i) % gfb->len;
        x2 = gfb->xmin + (int)(((float)i/(float)gfb->len) * (float)gfb->xscale);
        
        /* Magnitude */
        y2 = (int)(vscale*(-gfb->ref + gfb->data_blue[index])) + gfb->ymax;
        y2 = (y2>gfb->ymin) ? gfb->ymin : y2;
        y2 = (y2<gfb->ymax) ? gfb->ymax : y2;
        gdk_draw_line(gfb->GP_offscreen,
                      gfb->GC_blue,
                      x1,
                      y1,
                      x2,
                      y2);
        y1 = y2;
        
        if(gfb->do_phase)
        {
          /* Phase */
          y2i = (int)(gfb->yscale*gfb->data_red[index]) + gfb->ycenter;
          gdk_draw_line(gfb->GP_offscreen,
                        gfb->GC_red,
                        x1,
                        y1i,
                        x2,
                        y2i);
          y1i = y2i;
        }
        x1 = x2;
      }
      break;
      
    case 0: /* Time view */
      vscale = gfb->yscale / 2.0;
      /* draw the time data */
      y1 = (int)(vscale*gfb->data_blue[0] + gfb->ycenter);
      y1i = (int)(vscale*gfb->data_red[0] + gfb->ycenter);
      x1 = gfb->xmin;
      for(i=1;i<gfb->len;i++)
      {
        x2 = gfb->xmin + (int)(((float)i/(float)gfb->len)*(float)gfb->xscale);
        y2 = (int)(vscale*gfb->data_blue[i] + gfb->ycenter);
        gdk_draw_line(gfb->GP_offscreen,
                      gfb->GC_blue,
                      x1,
                      y1,
                      x2,
                      y2);
        y1 = y2;
        if(gfb->columns == 2)
        {
          y2i = (int)(vscale*gfb->data_red[i] + gfb->ycenter);
          gdk_draw_line(gfb->GP_offscreen,
                        gfb->GC_red,
                        x1,
                        y1i,
                        x2,
                        y2i);
          y1i = y2i;
        }
        x1 = x2;
      }
      break;
  }
  
  /* copy the offscreen to the display */
  gdk_draw_pixmap(gfb->drawingarea->window,
                  gfb->GC_red,
                  gfb->GP_offscreen,
                  0,
                  0,
                  0,
                  0,
                  -1,
                  -1);
}

/*
 * Set the offset into the data
 */
int gxfrm_draw_set_offset(gxfrm_draw_block *gfb, int offset)
{
  gfb->offset = offset;
  gfb->redraw_grid = 1;
  
  return FALSE;
}

/*
 * Set the length of the data
 */
int gxfrm_draw_set_len(gxfrm_draw_block *gfb, int len)
{
  if(len > DATASZ)
    return TRUE;
  
  gfb->len = len;
  
  if(gfb->view == 0)
    gfb->redraw_grid = 1;
  
  return FALSE;
}

/*
 * Set the view
 */
int gxfrm_draw_set_view(gxfrm_draw_block *gfb, int view)
{  
  gfb->view = view;
  gfb->redraw_grid = 1;
  
  return FALSE;
}

/*
 * Set the columns
 */
int gxfrm_draw_set_columns(gxfrm_draw_block *gfb, int columns)
{  
  gfb->columns = columns;
  
  return FALSE;
}

/*
 * Set the columns
 */
int gxfrm_draw_set_do_phase(gxfrm_draw_block *gfb, int do_phase)
{  
  gfb->do_phase = do_phase;
  gfb->redraw_grid = 1;
  
  return FALSE;
}

/*
 * Set the scale
 */
int gxfrm_draw_set_scale(gxfrm_draw_block *gfb, float scale)
{  
  gfb->scale = scale;
  gfb->redraw_grid = 1;
  
  return FALSE;
}

/*
 * Set the frequency
 */
int gxfrm_draw_set_freq(gxfrm_draw_block *gfb, float freq)
{  
  gfb->freq = freq;
  gfb->redraw_grid = 1;
  
  return FALSE;
}

/*
 * Set the db scale
 */
int gxfrm_draw_set_db(gxfrm_draw_block *gfb, float dbs)
{  
  gfb->dbs = dbs;
  gfb->redraw_grid = 1;
  
  return FALSE;
}

/*
 * Set the ref level
 */
int gxfrm_draw_set_ref(gxfrm_draw_block *gfb, float ref)
{  
  gfb->ref = ref;
  gfb->redraw_grid = 1;
  
  return FALSE;
}

/*
 * Copy data into the structure
 */
void gxfrm_draw_set_data(gxfrm_draw_block *gfb, float data[])
{
  int i;
  
  if(data == NULL)
  {
    for(i=0;i<gfb->len;i++)
    {
      gfb->data_blue[i] = 0.0;
      gfb->data_red[i] = 0.0;
    }
  }
  else
  {
    //for(i=0;i<8192;i++)
    //  printf("gxfrm_draw_set_data: %d %f\n", i, data[i]);
    
    for(i=0;i<gfb->len;i++)
    {
      gfb->data_blue[i] = data[(i<<1)];
      gfb->data_red[i] = data[((i<<1)+1)];
    }
  }
}

