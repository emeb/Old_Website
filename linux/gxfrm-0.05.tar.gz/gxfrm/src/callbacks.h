#include <gtk/gtk.h>


gboolean
on_window_main_delete_event            (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_phase_plot_activate                 (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_settin_chl_cmplx_activate           (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_setting_chl_swp_activate            (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_setting_chl_r_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_setting_chl_l_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_setting_chl_rl_activate             (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

gboolean
on_drawingarea1_configure_event        (GtkWidget       *widget,
                                        GdkEventConfigure *event,
                                        gpointer         user_data);

gboolean
on_drawingarea1_expose_event           (GtkWidget       *widget,
                                        GdkEventExpose  *event,
                                        gpointer         user_data);

void
on_radiobutton_view_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_reload_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_win_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_spinbutton_len_changed              (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_spinbutton_freq_changed             (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_spinbutton_ref_changed              (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_spinbutton_db_changed               (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_about_button1_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_file_ok_button1_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_file_cancel_button1_clicked         (GtkButton       *button,
                                        gpointer         user_data);
 
void
on_open1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_about1_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);
                                        
void
on_hscrollbar_pos_adj_value_changed     (GtkAdjustment *adjustment,
                                         gpointer user_data);

int
gxfrm_loadfile                          (char *filename);


void
on_exit1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);
