/* functions to write .wav audiofiles */
/* 2002-12-10, E.Brombaugh            */

#ifndef _write_wav_
#define _write_wav_

int write_wav(FILE *outfile, unsigned char *data, int bytes, int rate, int fmt, int chl);

#endif
