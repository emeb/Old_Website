/* ramrec.c : record a wav file from an OSS audio device */
/* 12-09-02 : E. Brombaugh */

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>
#include <math.h>
#include "write_wav.h"

// VR4181 driver's buffer size
#define DRV_BUFSZ 2048

int main(int argc, char **argv)
{
  // variables for getopt()
  extern char *optarg;
  int opt;

  // rest of vars...
  int audio_fd;  
  FILE *outfile;
  unsigned char *audio_buffer, *audio_bufptr;  
  int rate_in = 8000, rate_out;         // sample rate
  int verbose = 0;                      // 
  int dur = 1;                          // duration (s)
  int fmt_in = AFMT_U8, fmt_out;        // width AFMT_U8 = 8bit, AFMT_S16LE = 16bit signed
  int stereo_in = 0, stereo_out;        // derived from channel
  char *device = "/dev/dsp";	        // output filename
  char *outname = "default.wav";        // output filename
  int bps, samples, len, bytes, reqsize, count;
  
  // parse options
  while((opt = getopt(argc, argv, "w:d:o:r:Vt:c:h")) != EOF)
  {
    switch(opt)
    {
      case 'w':
        /* width */
        switch(atoi(optarg))
        {
          case 8:
            fmt_in = AFMT_U8;
            break;
            
          case 16:
            fmt_in = AFMT_S16_LE;
            break;
          
          default:
            fprintf(stderr, "Unknown width (use 8 or 16)\n");
            exit(-1);
        }
        break;
                
      case 'd':
        /* device */
        device = optarg;
        break;

      case 'o':
        /* output file */
        outname = optarg;
        break;

      case 'r':
        /* rate */
        rate_in = atoi(optarg);
        if((rate_in < 8000) || (rate_in > 48000))
        {
          fprintf(stderr, "Frequency out of range: 8k - 48k\n");
          exit(-1);
        }
        break;
      
      case 'V':
        verbose = 1;
        break;
        
      case 't':
        /* duration */
        dur = atoi(optarg);
        if((dur < 1) || (dur > 10000))
        {
          fprintf(stderr, "Duration out of range: 1 - 10000\n");
          exit(-1);
        }
        break;

      case 'c':
        /* channels */
        switch(optarg[0])
        {
          case 'm':
            stereo_in = 0;
            break;
          
          case 's':
            stereo_in = 1;
            break;
        }
        break;

      case 'h':
      case '?':
        fprintf(stderr, "USAGE: %s [options]\n", argv[0]);
        fprintf(stderr, "Options:\n");
        fprintf(stderr, " -w <bits> (8 | 16)        Default: %d\n", fmt_in);
        fprintf(stderr, " -d <device>               Default: %s\n", device);
        fprintf(stderr, " -o <output file>          Default: %s\n", outname);
        fprintf(stderr, " -r <rate> (8000 - 48000)  Default: %d\n", rate_in);
        fprintf(stderr, " -V (verbose)              Default: off\n");
        fprintf(stderr, " -t <time> (1 - 10000)     Default: %d\n", dur);
        fprintf(stderr, " -c <chl> (m | s)          Default: m\n");
        fprintf(stderr, " -h (this message)\n");
        exit(1);
    }
  }
  
  /* open up the sound device for input */
  if((audio_fd = open(device, O_RDONLY, 0)) == -1)  
  {
    fprintf(stderr, "Can't open %s for input!\n", device);
    exit(-1);
  }

  /* open up the output file */
  if(!(outfile = fopen(outname, "w")))  
  {
    fprintf(stderr, "Can't open %s for output!\n", outname);
    close(audio_fd);
    exit(-1);
  }

  /* set to desired format */
  fmt_out = fmt_in;
  if(ioctl(audio_fd, SNDCTL_DSP_SETFMT, &fmt_out)==-1)  
  {
    /* Fatal error */  
    perror("SNDCTL_DSP_SETFMT");  
    exit(-1);  
  }
  
  if(fmt_out != fmt_in)
    fprintf(stderr, "Format Mismatch: requested %d, reports %d)\n", fmt_in, fmt_out);
  
  /* set stereo */
  stereo_out = stereo_in;     /* 0=mono, 1=stereo */
  if(ioctl(audio_fd, SNDCTL_DSP_STEREO, &stereo_out)==-1)
  { /* Fatal error */
    perror("SNDCTL_DSP_STEREO");
    exit(-1);
  }

  if (stereo_out != stereo_in)
    fprintf(stderr, "Stereo Mismatch: requested %d, reports %d)\n", stereo_in, stereo_out);
  
  /* set sample rate */
  rate_out = rate_in;
  if(ioctl(audio_fd, SNDCTL_DSP_SPEED, &rate_out)==-1)  
  { /* Fatal error */  
    perror("SNDCTL_DSP_SPEED");  
    exit(-1);  
  }  

  if(abs(rate_out - rate_in) > rate_in/100)
    fprintf(stderr, "Rate Mismatch: requested %d, reports %d\n", rate_in, rate_out);
  
  /* compute duration in samples */
  samples = rate_out * dur;
  
  /* compute bytes per sample */
  bps = ((fmt_out == AFMT_S16_LE) ? 2 : 1) * ((stereo_out == 0) ? 1 : 2);
  
  /* compute total bytes */
  bytes = samples * bps;
  
  /* verbose output */
  if(verbose)
  {
    fprintf(stdout, "rate: %d\n", rate_out);
    fprintf(stdout, "width: %d, channel: %s\n", fmt_out, (stereo_out ? "stereo" : "mono"));
    fprintf(stdout, "duration: %d -> samples: %d (%d bytes)\n", dur, samples, bytes);
  }
  
  /* allocate buffer */
  if((audio_buffer = malloc(bytes)) == NULL)
  {
    fprintf(stderr, "Can't allocate %d bytes memory!\n", samples * bps);
    fclose(outfile);
    close(audio_fd);
    exit(-1);
  }
  
  /* get samples */
  audio_bufptr = audio_buffer;
  count = bytes;
  while(count > 0)
  {
    if(verbose)
      fprintf(stdout, "count: %d\n", count);
    
    /* limit read request to size of driver's buffer or less (Why?) */
    reqsize = count > DRV_BUFSZ ? DRV_BUFSZ : count;
    
    /* get the data */
    if ((len = read(audio_fd, audio_bufptr, reqsize)) == -1)
    {  
      perror("audio read");  
      exit(-1);  
    }
    count -= len;
    audio_bufptr += len;
  }
  
  /* write .wav file */
  if(verbose)
    fprintf(stdout, "Writing results to %s\n", outname);
  
  write_wav(outfile, audio_buffer, bytes, rate_out,
    ((fmt_out == AFMT_S16_LE) ? 16 : 8), stereo_out+1);
  
  /* shut down */
  free(audio_buffer);
  fclose(outfile);
  close(audio_fd);
  
  return 0;
}


