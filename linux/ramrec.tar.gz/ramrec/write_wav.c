/* functions to write .wav audiofiles */
/* 2002-12-10, E.Brombaugh            */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct waveformat 
{
  unsigned short formatTag;      /* format category  */
  unsigned short nChannels;      /* # of channels    */
  unsigned int nSamplesPerSec;   /* Sample rate      */
  unsigned int nAvgBytesPerSec;  /* for buffering    */
  unsigned short nBlockAlign;    /* Block Alignments */
  unsigned short nBitsPerSample; /* word size        */
};

unsigned short shortend(unsigned short);
unsigned int intend(unsigned int);

int writetag(FILE *file, char c1, char c2, char c3, char c4)
{
  fputc(c1, file);
  fputc(c2, file);
  fputc(c3, file);
  fputc(c4, file);
  
  return 0;
}

int write_wav(FILE *outfile, unsigned char *data, int bytes, int rate, int fmt, int chl)
{
  unsigned long temp;
  struct waveformat wfmt;

  /* write the RIFF header*/
  writetag(outfile, 'R', 'I', 'F', 'F');
  temp = 4 + 4 + 4 + sizeof(struct waveformat) + 4 + 4 + bytes;
  fwrite(&temp, sizeof(long), 1, outfile);
  writetag(outfile, 'W', 'A', 'V', 'E');
  writetag(outfile, 'f', 'm', 't', ' ');
  temp = sizeof(struct waveformat);
  fwrite(&temp, sizeof(long), 1, outfile);
  wfmt.formatTag = 1;
  wfmt.nChannels = chl;
  wfmt.nSamplesPerSec = rate;
  wfmt.nAvgBytesPerSec = rate;
  wfmt.nBlockAlign = 1;
  wfmt.nBitsPerSample = fmt;
  fwrite(&wfmt, sizeof(struct waveformat), 1, outfile);
  writetag(outfile, 'd', 'a', 't', 'a');
  temp = bytes;
  fwrite(&temp, sizeof(long), 1, outfile);
  fwrite(data, bytes, 1, outfile);
  
  return 0;
}

