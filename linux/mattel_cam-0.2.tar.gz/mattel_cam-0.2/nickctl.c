/* 
 * nickctl.c - grab a jpeg image with the Nick Click camera
 * 08-25-00 E. Brombaugh forked from nicksnap.c
 * 09-02-00 E. Brombaugh updated defaults, removed diag msg, added verbose mode
 *                       and skip unsharp for raw mode.
 * 02-15-03 E. Brombaugh update to use image, fix bugs, etc.
 *
 * Copyright (C) 2000, 2003 Eric Brombaugh
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include "mattcam.h"
#include "mattgfx.h"
#include "gfxfile.h"

int main(int argc, char **argv)
{
  /* variables for getopt() */
  extern char *optarg;
  int opt;
  
  mc_struct mcs;
  int comm_err=0, grab_result = 0;
  char *inname = "/dev/ttyS0", *outname = "nick.jpg";
  unsigned char databuf[20680];
  image *im, *cp, *unsharp, *scale, *outpic;
  char *text;
  int r;
  int v;
  int dmt;
  int quality;
  int g;
  int u;
  double C;
  int m;
  
  /* defaults */
  text = NULL;
  dmt = 3;
  quality = 50;
  C = 2.0;
  r = 2;
  g = -1;
  u = -1;
  v = 0;
  m = 1;
  
  /* parse options */
  while((opt = getopt(argc, argv, "c:d:g:m:o:q:r:t:u:vx:h")) != EOF)
  {
    switch(opt)
    {
      case 'c':
        /* Unsharp Coeff */
        C = atof(optarg);
        break;

      case 'd':
        /* input device */
        inname = optarg;
        break;

      case 'g':
        /* grab image */
        g = atoi(optarg);
        break;

      case 'm':
        /* rendered text */
        text = optarg;
        break;

      case 'o':
        /* out filename */
        outname = optarg;
        break;

      case 'q':
        /* jpeg quality */
        quality = atoi(optarg);
        break;

      case 'r':
        /* Unsharp Radius */
        r = atoi(optarg);
        break;

      case 't':
        /* Demosaic type */
        dmt = atoi(optarg);
        break;

      case 'u':
        /* upload image */
        u = atoi(optarg);
        break;

      case 'v':
        /* Verbose mode */
        v = 1;
        break;
        
      case 'x':
        /* interpolate */
        m = atoi(optarg);
        break;
        
      case 'h':
      case '?':
        fprintf(stderr, "USAGE: %s [options]\n", argv[0]);
        fprintf(stderr, "Version 0.2, February 16, 2003\n");
        fprintf(stderr, "Options: -c <Unsharp coeff>  Default: %f\n", C);
        fprintf(stderr, "         -d <device>         Default: %s\n", inname);
        fprintf(stderr, "         -g <image #>        Default: %d\n", g);
        fprintf(stderr, "         -m <text>           Default: none\n");
        fprintf(stderr, "         -o <out file>       Default: %s\n", outname);
        fprintf(stderr, "         -q <JPEG quality>   Default: %d\n", quality);
        fprintf(stderr, "         -r <Unsharp radius> Default: %d\n", r);
        fprintf(stderr, "         -t <demosaic type > Default: %d\n", dmt);
        fprintf(stderr, "         -u <image #>        Default: %d\n", u);
        fprintf(stderr, "         -v (verbose)        Default: off\n");
        fprintf(stderr, "         -x <scale>          Default: %d\n", m);
        exit(1);
    }
  }
  
  if((g==-1) && (u==-1))
  {
    fprintf(stderr, "Nothing to do!\n");
    exit(-1);
  }
  
  /* open up the camera I/O */
  if(init_mc(&mcs, inname, v))
  {
    fprintf(stderr, "Trouble opening the camera I/O.");
    exit(-1);
  }

  /* take a picture */
  if((g>=0) && (g<6))
  {
    if(mc_send_cmd(&mcs, ADDR_IMAGE, g)==ERR_COMM)
      comm_err = 1;
    if(mc_send_cmd(&mcs, GRAB_IMAGE, 0)==ERR_COMM)
      comm_err |= 2;
    if((grab_result = mc_send_cmd(&mcs, GRAB_RESULT, 0))==ERR_COMM)
      comm_err |= 4;
    
    if(v)
      fprintf(stderr, "Grab_result: %x\n", grab_result);
  }
  
  if((u>=0) && (u<6))
  {
    if(mc_send_cmd(&mcs, ADDR_IMAGE, u)==ERR_COMM)
      comm_err |= 8;
  
    /* get the picture */
    bzero(databuf, sizeof(databuf));
    if(mc_recv_pic(&mcs, databuf)==ERR_COMM)
      comm_err |= 16;
  
    /* check if everything worked */
    if(comm_err)
    {
      if(v)
        fprintf(stderr, "Communications Error %x: aborting.\n", comm_err);
      exit(ERR_COMM);
    }
  
    /* correct black level and parse camera data into image */
    if(!(im = bayer_parse(databuf)))
    {
      if(v)
        fprintf(stderr, "Couldn't parse camera data: aborting\n");
      exit(ERR_MEMORY);
    }
    
    /* now do the bayer->normal magic */
    demosaic(dmt, im);
    
    /* crop off the edges */
    cp = crop_image(im, 2, 4, 160, 120);
  
    /* don't need this anymore */
    destroy_image(im);
  
    /* if rawtype, don't unsharp image */
    if(!dmt || (r == 0))
    {
      outpic = cp;
    }
    else
    {
      /* unsharp mask */
      if(!(unsharp = unsharp_mask(cp, C, r)))
      {
        if(v)
          fprintf(stderr, "Couldn't process unsharp mask\n");
        exit(ERR_MEMORY);
      }
      outpic = unsharp;
      
      /* don't need this anymore */
      destroy_image(cp);
    }
    
    /* scale if required */
    if(m > 1)
    {
      if(!(scale = interp_image(outpic, m)))
      {
        if(v)
          fprintf(stderr, "Couldn't scale image\n");
        exit(ERR_MEMORY);
      }
      
      /* don't need this */
      destroy_image(outpic);
      
      outpic = scale;
    }
  
    /* if message, put it on the image */
    if(text)
      text_image(outpic, 0, outpic->ys, text);
  
    /* output the image */
    if(write_gfx(outname, outpic, quality) && v)
      fprintf(stderr, "Couldn't save file.\n");
    
    /*cleanup*/
    destroy_image(outpic);
  }
  
  /* we're all done with the camera, so close it */
  close_mc(&mcs);

  return grab_result;
}

