/* winfat.c - modify a DOS FAT to use Win9x EOC markers */
/* 2002-02-03, E.Brombaugh, copied from chkfat.c v0.1 */

#include <stdio.h>

#define PACK_STRUCT __attribute__((packed))

void print_nstr(char *p, int num);
int trace_fat(unsigned char *FATs, int FAT_type, int cluster, int *offset);
void update_fat(unsigned char *FATs, int FAT_type, int cluster, int value);

typedef struct
{
    unsigned char drive_num;
    unsigned char head;
    unsigned char signature;
    unsigned char serial_num[4];
    char vol_label[11];
    char fs_id[8];
} PACK_STRUCT EXT_BPB;

typedef struct
{
    unsigned char jump[3]; /* 3-byte jump */
    char oem_name[8]; /* Name, version */
    unsigned short bytes_sector;
    unsigned char sect_per_alloc_unit;
    unsigned short reserved_sects;
    unsigned char num_FATs;
    unsigned short root_dir_entries;
    unsigned short num_sectors;
    unsigned char media;
    unsigned short FAT_sectors;
    unsigned short sectors_track;
    unsigned short num_heads;
    unsigned long hidden_sectors;
    unsigned long total_sectors;
    EXT_BPB bpb;
    unsigned char code[448];
    unsigned short boot_sig;
} PACK_STRUCT BOOT_REC;

typedef struct
{
    unsigned char fname[8];
    char fext[3];
    unsigned char fattr;
    unsigned char NT_reserved;
    unsigned char ctime_tenths;
    unsigned short ctime;
    unsigned short cdate;
    unsigned short adate;
    unsigned short high_cluster;
    unsigned short mtime;
    unsigned short mdate;
    unsigned short cluster;
    unsigned long fsize;
} PACK_STRUCT DIR_ENTRY;

    

int main(int argc, char **argv)
{
    char *inname;
    FILE *infile;
    BOOT_REC br;
    int szFAT, szFATs, FAT_type, cluster_sz;
    unsigned char *FATs;
    int i, j;
    int mismatches = 0;
    int szRD;
    char *RD;
    DIR_ENTRY *de;
    char buffer[256];
    int cluster, next_cluster, end_cluster, first_cluster, num_clusters;
    int offset;
    int frag, newfrag;
    int fat_modified = 0;
    
    if(argc < 2)
    {
        fprintf(stderr, "USAGE: %s <infile>\n", argv[0]);
        exit(-1);
    }
    
    if(!(infile = fopen(argv[1], "r+")))
    {
        fprintf(stderr, "Couldn't open input file %s\n", argv[1]);
        exit(-1);
    }
    
    /* get the boot record */
    if(fread(&br, sizeof(BOOT_REC), 1, infile) != 1)
    {
        fprintf(stderr, "Ran out of data reading boot record.\n");
        exit(-1);
    }
        
    if(br.boot_sig != 0xaa55)
    {
        fprintf(stderr, "Illegal Boot Signature!\n");
        fclose(infile);
        exit(-1);
    }
    
    /* figure out what type of FAT by M'soft method */
    cluster_sz = (int)br.total_sectors / (int)br.sect_per_alloc_unit;
    if(cluster_sz < 4085)
        FAT_type = 12;
    else if(cluster_sz < 65525)
        FAT_type = 16;
    else
        FAT_type = 32;
    
    fprintf(stdout, "FAT% d\n", FAT_type);

    if(FAT_type == 32)
    {
        fprintf(stderr, "Sorry! This only works on FAT12 and FAT16!\n");
        fclose(infile);
        exit(-1);
    }
    
    /* calc the EOC value */
    end_cluster = (1<<FAT_type)-8;
    fprintf(stdout, "EOC % x\n", end_cluster);
    
    /* alloc mem for the FAT(s) & read 'em */
    szFAT = br.bytes_sector * br.FAT_sectors;
    szFATs = szFAT * br.num_FATs;
    fprintf(stdout, "FAT size: 0x% x\n", szFAT);

    if(!(FATs = (unsigned char *)malloc(szFATs)))
    {
        fprintf(stderr, "Couldn't allocate memory for FATs!");
        fclose(infile);
        exit(-1);
    }
    
    if(fread(FATs, 1, szFATs, infile) != szFATs)
    {
        fprintf(stderr, "Couldn't read FATs\n");
        free(FATs);
        fclose(infile);
        exit(1);
    }
    
    /* Compare the FATs */
    for(i=1;i<br.num_FATs;i++)
    {
        for(j=0;j<szFAT;j++)
        {
            if(FATs[j] != FATs[szFAT*i+j])
            {
                fprintf(stdout, "Compare FAT 0 / FAT %d fails @ byte %d\n", i, j);
                mismatches++;
            }
        }
    }
    
    if(mismatches)
    {
        fprintf(stdout, "The FATs don't match - I'm not touching this one!\n");
        free(FATs);
        fclose(infile);
        exit(1);
    }
    
    /* load the root directory */
    szRD = br.root_dir_entries * 32;
    
    if(!(RD = (char *)malloc(szRD)))
    {
        fprintf(stderr, "Couldn't allocate memory for Root Dir!\n");
        free(FATs);
        fclose(infile);
        exit(-1);
    }
    
    if(fread(RD, 1, szRD, infile) != szRD)
    {
        fprintf(stderr, "Couldn't read Root Directory\n");
        free(RD);
        free(FATs);
        fclose(infile);
        exit(1);
    }
    
    /* scan through the root directory */
    de = (DIR_ENTRY *)RD;
    for(i=0;i<br.root_dir_entries;i++)
    {
        if(de->fname[0] == 0)
            break;
        if(de->fname[0] == 0xe5)
        {
            // fprintf(stdout, "Deleted/Free\n");
        }
        else if((de->cluster == 0) && (de->fattr == 0x0f))
        {
            // fprintf(stdout, "LFN part #%d\n", de->fname[0]&0x1f);
        }
        else
        {
            /* scan through the clusters */
            cluster = de->cluster;
            num_clusters = 0;
            if(cluster != 0)
            {
                frag = 0;
                newfrag = 1;
                while(cluster < end_cluster)
                {
                    if(newfrag)
                    {
                        newfrag = 0;
                        first_cluster = cluster;
                    }
                
                    next_cluster = trace_fat(FATs, FAT_type, cluster, &offset);
                
                    if(next_cluster != (cluster+1))
                    {
                        newfrag = 1;
                        frag++;
                    }
                                        
                    if(next_cluster >= end_cluster)
                    {
                        fprintf(stdout, "Entry %d Last Cluster %d = 0x% x\n", i, cluster, next_cluster);
                        fprintf(stdout, "Location: %d\n", offset);
                        
                        if(next_cluster != (end_cluster | 0xf))
                        {
                            fprintf(stdout, "Updating EOC\n");
                            update_fat(FATs, FAT_type, cluster, (end_cluster|0xf));
                            fat_modified = 1;
                        }
                    }
                    
                    cluster = next_cluster;
                    num_clusters++;
                }
            }
        }
        
        de++;
    }
    
    if(fat_modified)
    {
        fprintf(stdout, "FAT was altered - resyncing copies & writing out.\n");
        
        /* copy changes to other FATs */
        for(i=1;i<br.num_FATs;i++)
        {
            for(j=0;j<szFAT;j++)
            {
                FATs[szFAT*i+j] = FATs[j];
            }
        }
        
        /* write the FATs back out at this point */
        fseek(infile, sizeof(BOOT_REC), SEEK_SET);
        if(fwrite(FATs, 1, szFATs, infile) != szFATs)
        {
            fprintf(stderr, "PANIC! Error writing FATs!\n");
        }
    }
    
    /* free/close */
    free(RD);
    free(FATs);
    fclose(infile);
}

int trace_fat(unsigned char *FATs, int FAT_type, int cluster, int *offset)
{
    int next_cluster, half;
    
    switch(FAT_type)
    {
        case 12:
            cluster = (cluster * 12) >> 2;
            half = cluster & 1;
            *offset = cluster >> 1;
            if(half)
                next_cluster = ((FATs[*offset] & 0xf0) >> 4) | (FATs[*offset+1] << 4);
            else
                next_cluster = FATs[*offset] | ((FATs[*offset+1] & 0xf) << 8);
            break;
        
        case 16:
            *offset = cluster << 1;
            next_cluster = FATs[*offset] | (FATs[*offset+1] << 8);
            break;
        
        default:
            next_cluster = 0;
     }
     
     return next_cluster;
}

void update_fat(unsigned char *FATs, int FAT_type, int cluster, int value)
{
    int next_cluster, half, offset;
    
    switch(FAT_type)
    {
        case 12:
            cluster = (cluster * 12) >> 2;
            half = cluster & 1;
            offset = cluster >> 1;
            if(half)
            {
                FATs[offset] = (FATs[offset] & 0xf) | ((value & 0xf) << 4);
                FATs[offset+1] = value >> 4;
            }
            else
            {
                FATs[offset] = value & 0xff;
                FATs[offset+1] = (FATs[offset+1] & 0xf0) | ((value & 0xf00) >> 8);
            }
            break;
        
        case 16:
            offset = cluster << 1;
            FATs[offset] = value & 0xff;
            FATs[offset+1] = ((value & 0xff00) >> 8);
            break;
        
        default:
            next_cluster = 0;
     }
}
