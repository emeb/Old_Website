/* chkfat.c - check a DOS FAT */
/* 2002-01-18, E.Brombaugh, created v0.1 */

#include <stdio.h>

#define PACK_STRUCT __attribute__((packed))

void print_nstr(char *p, int num);
char *dostime(unsigned short dtime, char *buffer);
char *dosdate(unsigned short ddate, char *buffer);
int trace_fat(unsigned char *FATs, int FAT_type, int cluster);

typedef struct
{
    unsigned char drive_num;
    unsigned char head;
    unsigned char signature;
    unsigned char serial_num[4];
    char vol_label[11];
    char fs_id[8];
} PACK_STRUCT EXT_BPB;

typedef struct
{
    unsigned char jump[3]; /* 3-byte jump */
    char oem_name[8]; /* Name, version */
    unsigned short bytes_sector;
    unsigned char sect_per_alloc_unit;
    unsigned short reserved_sects;
    unsigned char num_FATs;
    unsigned short root_dir_entries;
    unsigned short num_sectors;
    unsigned char media;
    unsigned short FAT_sectors;
    unsigned short sectors_track;
    unsigned short num_heads;
    unsigned long hidden_sectors;
    unsigned long total_sectors;
    EXT_BPB bpb;
    unsigned char code[448];
    unsigned short boot_sig;
} PACK_STRUCT BOOT_REC;

typedef struct
{
    unsigned char fname[8];
    char fext[3];
    unsigned char fattr;
    unsigned char NT_reserved;
    unsigned char ctime_tenths;
    unsigned short ctime;
    unsigned short cdate;
    unsigned short adate;
    unsigned short high_cluster;
    unsigned short mtime;
    unsigned short mdate;
    unsigned short cluster;
    unsigned long fsize;
} PACK_STRUCT DIR_ENTRY;

    

int main(int argc, char **argv)
{
    char *inname;
    FILE *infile;
    BOOT_REC br;
    int szFAT, szFATs, FAT_type, cluster_sz;
    unsigned char *FATs;
    int i, j;
    int mismatches = 0;
    int szRD;
    char *RD;
    DIR_ENTRY *de;
    char buffer[256];
    int cluster, next_cluster, end_cluster, first_cluster, num_clusters;
    int frag, newfrag;
    
    if(argc < 2)
    {
        fprintf(stderr, "USAGE: %s <infile>\n", argv[0]);
        exit(-1);
    }
    
    if(!(infile = fopen(argv[1], "rb")))
    {
        fprintf(stderr, "Couldn't open input file %s\n", argv[1]);
        exit(-1);
    }
    
    /* get the boot record */
    if(fread(&br, sizeof(BOOT_REC), 1, infile) != 1)
    {
        fprintf(stderr, "Ran out of data reading boot record.\n");
        exit(-1);
    }
    
    fprintf(stdout, "------------ Boot Block ------------\n");
    fprintf(stdout, "oem_name: ");
    print_nstr(br.oem_name, 8);
    fprintf(stdout, "bytes_sector: %u\n", br.bytes_sector);
    fprintf(stdout, "sect_per_alloc_unit: %u\n", br.sect_per_alloc_unit);
    fprintf(stdout, "reserved_sects: %u\n", br.reserved_sects);
    fprintf(stdout, "num_FATs: %u\n", br.num_FATs);
    fprintf(stdout, "root_dir_entries: %u\n", br.root_dir_entries);
    fprintf(stdout, "num_sectors: %u\n", br.num_sectors);
    fprintf(stdout, "media: 0x% x\n", br.media);
    fprintf(stdout, "FAT_sectors: %u\n", br.FAT_sectors);
    fprintf(stdout, "sectors_track: %u\n", br.sectors_track);
    fprintf(stdout, "num_heads: %u\n", br.num_heads);
    fprintf(stdout, "hidden_sectors: %u\n", br.hidden_sectors);
    fprintf(stdout, "total_sectors: %u\n", br.total_sectors);
    fprintf(stdout, "drive_num: %u\n", br.bpb.drive_num);
    fprintf(stdout, "head: %u\n", br.bpb.head);
    fprintf(stdout, "signature: %u\n", br.bpb.signature);
    fprintf(stdout, "serial_num: 0x% x% x% x% x\n", br.bpb.serial_num[0], br.bpb.serial_num[1], br.bpb.serial_num[2], br.bpb.serial_num[3]);
    fprintf(stdout, "vol_label: ");
    print_nstr(br.bpb.vol_label, 11);
    fprintf(stdout, "fs_id: ");
    print_nstr(br.bpb.fs_id, 8);
    fprintf(stdout, "boot_sig: 0x% x\n", br.boot_sig);
    
    if(br.boot_sig != 0xaa55)
    {
        fprintf(stderr, "Illegal Boot Signature!\n");
        fclose(infile);
        exit(-1);
    }
    
    /* figure out what type of FAT by M'soft method */
    cluster_sz = (int)br.total_sectors / (int)br.sect_per_alloc_unit;
    if(cluster_sz < 4085)
        FAT_type = 12;
    else if(cluster_sz < 65525)
        FAT_type = 16;
    else
        FAT_type = 32;
    
    fprintf(stdout, "%d clusters -> FAT% d\n", cluster_sz, FAT_type);

    if(FAT_type == 32)
    {
        fprintf(stderr, "Illegal FS type!\n");
        fclose(infile);
        exit(-1);
    }
    
    /* calc the EOC value */
    end_cluster = (1<<FAT_type)-8;
    fprintf(stdout, "EOC % x = %d\n", end_cluster, end_cluster);
    
    /* alloc mem for the FAT(s) & read 'em */
    fprintf(stdout, "------------ FATs ------------\n");
    szFAT = br.bytes_sector * br.FAT_sectors;
    szFATs = szFAT * br.num_FATs;
    fprintf(stdout, "FAT size: 0x% x\n", szFAT);

    if(!(FATs = (unsigned char *)malloc(szFATs)))
    {
        fprintf(stderr, "Couldn't allocate memory for FATs!");
        fclose(infile);
        exit(-1);
    }
    
    if(fread(FATs, 1, szFATs, infile) != szFATs)
    {
        fprintf(stderr, "Couldn't read FATs\n");
        free(FATs);
        fclose(infile);
        exit(1);
    }
    
    /* Compare the FATs */
    for(i=1;i<br.num_FATs;i++)
    {
        for(j=0;j<szFAT;j++)
        {
            if(FATs[j] != FATs[szFAT*i+j])
            {
                fprintf(stdout, "Compare FAT 0 / FAT %d fails @ byte %d\n", i, j);
                mismatches++;
            }
        }
    }
    
    if(!mismatches)
        fprintf(stdout, "FATs Match!\n");
    
#if(0)
    /* dump the fat */
    for(i=0;i<(1<<FAT_type);i++)
        fprintf(stdout, "% 4x: % 4x\n", i, trace_fat(FATs, FAT_type, i));
#endif

    /* load the root directory */
    fprintf(stdout, "------------ Root Directory ------------\n");
    szRD = br.root_dir_entries * 32;
    
    if(!(RD = (char *)malloc(szRD)))
    {
        fprintf(stderr, "Couldn't allocate memory for Root Dir!\n");
        free(FATs);
        fclose(infile);
        exit(-1);
    }
    
    if(fread(RD, 1, szRD, infile) != szRD)
    {
        fprintf(stderr, "Couldn't read Root Directory\n");
        free(RD);
        free(FATs);
        fclose(infile);
        exit(1);
    }
    
    /* scan through the root directory */
    de = (DIR_ENTRY *)RD;
    for(i=0;i<br.root_dir_entries;i++)
    {
        if(de->fname[0] == 0)
            break;
        fprintf(stdout, "-----Dir Entry %d----\n", i);
        if(de->fname[0] == 0xe5)
        {
            fprintf(stdout, "Deleted/Free\n");
        }
        else if((de->cluster == 0) && (de->fattr == 0x0f))
        {
            fprintf(stdout, "LFN part #%d\n", de->fname[0]&0x1f);
        }
        else
        {
            fprintf(stdout, "fname: ");
            print_nstr(de->fname, 8);
            fprintf(stdout, "fext: ");
            print_nstr(de->fext, 3);
            fprintf(stdout, "fattr: 0x% x\n", de->fattr);
            fprintf(stdout, "NT_reserved: 0x% x\n", de->NT_reserved);
            fprintf(stdout, "ctime_tenths: 0x% x\n", de->ctime_tenths);
            fprintf(stdout, "ctime: 0x% x = %s\n", de->ctime, dostime(de->ctime, buffer));
            fprintf(stdout, "cdate: 0x% x = %s\n", de->cdate, dosdate(de->cdate, buffer));
            fprintf(stdout, "adate: 0x% x = %s\n", de->adate, dosdate(de->adate, buffer));
            fprintf(stdout, "high_cluster: 0x% x\n", de->high_cluster);
            fprintf(stdout, "mtime: 0x% x = %s\n", de->mtime, dostime(de->mtime, buffer));
            fprintf(stdout, "mdate: 0x% x = %s\n", de->mdate, dosdate(de->mdate, buffer));
            fprintf(stdout, "cluster: 0x% x\n", de->cluster);
            fprintf(stdout, "fsize: 0x% x = %d\n", de->fsize, de->fsize);
            
            /* scan through the clusters */
            cluster = de->cluster;
            num_clusters = 0;
            if(cluster != 0)
            {
                frag = 0;
                newfrag = 1;
                while(cluster < end_cluster)
                {
                    if(newfrag)
                    {
                        fprintf(stdout, "fragment %d: %d", frag, cluster);
                        newfrag = 0;
                        first_cluster = cluster;
                    }
                
                    next_cluster = trace_fat(FATs, FAT_type, cluster);
                
                    if(next_cluster != (cluster+1))
                    {
                        newfrag = 1;
                        frag++;
                    }
                    
                    if(newfrag || (next_cluster >= end_cluster))
                    {
                        if(cluster != first_cluster)
                            fprintf(stdout, "-%d", cluster);
                        
                        fprintf(stdout, " EOC = 0x% x\n", next_cluster);
                    }
                    
                    cluster = next_cluster;
                    num_clusters++;
                }
            }
            
            fprintf(stdout, "Clusters: %d\n", num_clusters);
            fprintf(stdout, "Size on disk: %d\n", num_clusters * br.bytes_sector *
            br.sect_per_alloc_unit);
        }
        
        de++;
    }
    
    /* free/close */
    free(RD);
    free(FATs);
    fclose(infile);
}

void print_nstr(char *p, int num)
{
    int i;
    
    for(i=0;i<num;i++)
        fprintf(stdout, "%c", *p++);
    
    fprintf(stdout, "\n");
}

char *dostime(unsigned short dtime, char *buffer)
{
    int h, m, s2;
    
    s2 = dtime & 0x1f;
    m = (dtime >> 5) & 0x3f;
    h = (dtime >> 11) & 0x1f;
    sprintf(buffer, "%2d:%2d:%2d", h, m, s2*2);
    
    return buffer;
}

char *dosdate(unsigned short ddate, char *buffer)
{
    int d, m, y;
    
    d = ddate & 0x1f;
    m = (ddate >> 5) & 0xf;
    y = (ddate >> 9) + 1980;
    sprintf(buffer, "%4d/%2d/%2d", y, m, d);
    
    return buffer;
}

int trace_fat(unsigned char *FATs, int FAT_type, int cluster)
{
    int next_cluster, half, offset;
    
    switch(FAT_type)
    {
        case 12:
            cluster = (cluster * 12) >> 2;
            half = cluster & 1;
            offset = cluster >> 1;
            if(half)
                next_cluster = ((FATs[offset] & 0xf0) >> 4) | (FATs[offset+1] << 4);
            else
                next_cluster = FATs[offset] | ((FATs[offset+1] & 0xf) << 8);
            break;
        
        case 16:
            offset = cluster << 1;
            next_cluster = FATs[offset] | (FATs[offset+1] << 8);
            break;
        
        default:
            next_cluster = 0;
     }
     
     return next_cluster;
}

