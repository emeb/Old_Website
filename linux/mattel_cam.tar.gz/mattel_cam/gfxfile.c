/*
 *  gfxfile.c - write graphics files
 *  08-20-00 E. Brombaugh
 *  09-02-00 E. Brombaugh - fixed no filetype segfault
 */

#include <stdio.h>
#include "gfxfile.h"

int write_gfx(char *outname, unsigned char *scanlines, int quality)
{
  int out = 0;
  FILE *outfile;
  
  /* open the output file */
  if(!(outfile = fopen(outname, "wb")))
  {
    fprintf(stderr, "Couldn't open %s for output.\n", outname);
    exit(-1);
  }
  
  /* figure out what type of file it's going to be */
  switch(gfxtype(outname))
  {
    case 0:
      /* write data as a jpg */
      /* fprintf(stderr, "writing jpg file %s\n", outname); */
      write_jpeg(outfile, scanlines, quality);
      break;
    
    case 1:
      /* write data as a BMP */
      /* fprintf(stderr, "writing bmp file %s\n", outname); */
      write_bmp(outfile, scanlines);
      break;
    
    case 2:
      /* write data as a PPM */
      /* fprintf(stderr, "writing ppm file %s\n", outname); */
      write_ppm(outfile, scanlines);
      break;
    
    default:
      /* unknown file type */
      fprintf(stderr, "Unknown file type - use only .jpg, .bmp or .ppm\n");
      out = -1;
      break;
  }
  
  fclose(outfile);
  
  return out;
}

int gfxtype(char *name)
{
  char *typ;
  
  /* find period - default to jpeg if none */
  if((typ = strchr(name, '.')) == NULL)
    return 0;
    
  /* point to start of filetype */
  typ ++;
  
  if(strncmp(typ, "jpg", 3) == 0)
    return0;
  else if(strncmp(typ, "bmp", 3) == 0)
    return 1;
  else if(strncmp(typ, "ppm", 3) == 0)
    return 2;
  else
    return -1;
}

void write_jpeg(FILE *outfile, unsigned char *scanlines, int quality)
{
  int y;
  JSAMPROW lines[120];
  struct jpeg_compress_struct cinfo;
  struct jpeg_error_mgr jerr;
  
  /* set up the pointers */
  for(y=0;y<120;y++)
    lines[y] = (JSAMPROW)&scanlines[(y+4)*(164*3)+6];
  
  /* init the jpeg stuff */
  cinfo.err = jpeg_std_error(&jerr);
  jpeg_create_compress(&cinfo);
  jpeg_stdio_dest(&cinfo, outfile);
  
  cinfo.image_width = 160; 	/* image width and height, in pixels */
  cinfo.image_height = 120;
  cinfo.input_components = 3;	/* # of color components per pixel */
  cinfo.in_color_space = JCS_RGB; /* colorspace of input image */
  jpeg_set_defaults(&cinfo);
  
  /* set quality */
  jpeg_set_quality (&cinfo, quality, FALSE);
  
  /* process the jpeg data */
  jpeg_start_compress(&cinfo, TRUE);
  
  while (cinfo.next_scanline < cinfo.image_height)
  {
    jpeg_write_scanlines(&cinfo, &lines[cinfo.next_scanline], 1);
  }

  /* finish up */
  jpeg_finish_compress(&cinfo);
  jpeg_destroy_compress(&cinfo);
}

void write_bmp(FILE *outfile, unsigned char *scanlines)
{
  int y;
  BMPSAMPROW lines[120];
  bmp_struct cinfo;  
  
  /* set up the pointers */
  for(y=0;y<120;y++)
    lines[y] = (BMPSAMPROW)&scanlines[(y+4)*(164*3)+6];
   
  /* init the BMP stuff */
  if(bmp24_init(&cinfo, outfile, 160, 120))
  {
    fprintf(stderr, "Trouble initializing the BMP file.\n");
    exit(-1);
  }
  
  // process the jpeg data
  while (cinfo.next_scanline < cinfo.bmih.biHeight)
  {
    bmp24_write_scanlines(&cinfo, &lines[cinfo.next_scanline], 1);
  }

  // finish up
  bmp24_finish(&cinfo);
}

void write_ppm(FILE *outfile, unsigned char *scanlines)
{
  int y;
  
  /* write the header */
  fprintf(outfile, "P6\n");
  fprintf(outfile, "# Created by nicksnap\n");
  fprintf(outfile, "160\n120\n255\n");
  
  /* write the data */
  for(y=4;y<124;y++)
  {
    fwrite((scanlines+(y*164*3)+6), sizeof(unsigned char), (3*160), outfile);
  }
}



