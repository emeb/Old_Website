/* 
 * nicksnap.c - grab a jpeg image with the Nick Click camera
 * 08-06-00 E. Brombaugh Initial release
 * 08-12-00 E. Brombaugh Added Black Level adjustment and Unsharp Masking
 * 08-14-00 E. Brombaugh fix underflows in unsharp mask
 * 08-15-00 E. Brombaugh fix unshuffle and unsharp edges
 * 08-20-00 E. Brombaugh modularized, added bmp, ppm output
 * 09-02-00 E. Brombaugh updated defaults, removed diag msg, added verbose mode
 *                       and skip unsharp for raw mode.
 * 09-08-00 E. Brombaugh add text option
 */

#include <stdio.h>
#include <stdlib.h>
#include "mattcam.h"
#include "mattgfx.h"
#include "gfxfile.h"
#include "matttxt.h"

int main(int argc, char **argv)
{
  /* variables for getopt() */
  extern char *optarg;
  int opt;
  
  mc_struct mcs;
  int comm_err=0;
  int grab_result;
  char *inname = "/dev/ttyS0", *outname = "nick.jpg";
  unsigned char databuf[20680];
  unsigned char scanlines[126*3*164];
  unsigned char unsharp[126*3*164];
  unsigned char *outpic;
  char *text;
  int r;
  int v;
  int dmt;
  int quality;
  double C;
  
  /* defaults */
  text = NULL;
  dmt = 3;
  quality = 50;
  C = 2.0;
  r = 2;
  v = 0;
  
  /* parse options */
  while((opt = getopt(argc, argv, "c:d:m:o:q:r:t:vh")) != EOF)
  {
    switch(opt)
    {
      case 'c':
        /* Unsharp Coeff */
        C = atof(optarg);
        break;

      case 'd':
        /* input device */
        inname = optarg;
        break;

      case 'm':
        /* text string */
        text = optarg;
        break;

      case 'o':
        /* out filename */
        outname = optarg;
        break;

      case 'q':
        /* jpeg quality */
        quality = atoi(optarg);
        break;

      case 'r':
        /* Unsharp Radius */
        r = atoi(optarg);
        break;

      case 't':
        /* Demosaic type */
        dmt = atoi(optarg);
        break;

      case 'v':
        /* Verbose mode */
        v = 1;
        break;
        
      case 'h':
      case '?':
        fprintf(stderr, "USAGE: %s [options]\n", argv[0]);
        fprintf(stderr, "Options are: -c <Unsharp coeff>  Default: %f\n", C);
        fprintf(stderr, "             -d <device>         Default: %s\n", inname);
        fprintf(stderr, "             -m <text>           Default: none\n");
        fprintf(stderr, "             -o <out file>       Default: %s\n", outname);
        fprintf(stderr, "             -q <JPEG quality>   Default: %d\n", quality);
        fprintf(stderr, "             -r <Unsharp radius> Default: %d\n", r);
        fprintf(stderr, "             -t <demosaic type > Default: %d\n", dmt);
        fprintf(stderr, "             -v (verbose)        Default: off\n");
        exit(1);
    }
  }
  
  /* open up the camera I/O */
  if(init_mc(&mcs, inname, v))
  {
    fprintf(stderr, "Trouble opening the camera I/O.");
    exit(-1);
  }

  /* take a picture */
  if(mc_send_cmd(&mcs, ADDR_IMAGE, 0)==ERR_COMM)
    comm_err = 1;
  if(mc_send_cmd(&mcs, GRAB_IMAGE, 0)==ERR_COMM)
    comm_err |= 2;
  if((grab_result = mc_send_cmd(&mcs, GRAB_RESULT, 0))==ERR_COMM)
    comm_err |= 4;

  if(v)
    fprintf(stderr, "Grab Result: %x\n", grab_result);
    
  if(mc_send_cmd(&mcs, ADDR_IMAGE, 0)==ERR_COMM)
    comm_err |= 8;
  
  /* get the picture */
  bzero(databuf, sizeof(databuf));
  if(mc_recv_pic(&mcs, databuf))
    comm_err |= 16;
  
  /* we're all done with the camera, so close it */
  close_mc(&mcs);

  /* check if everything worked */
  if(comm_err)
  {
    if(v)
      fprintf(stderr, "Communications Error %x: aborting.\n", comm_err);
    exit(ERR_COMM);
  }
  
  /* correct black level and parse camera data into rgb array */
  bayer_parse(databuf, scanlines);
  
  /* now do the bayer->normal magic */
  demosaic(dmt, scanlines);
  
  /* if rawtype, don't unsharp image */
  if(!dmt)
  {
    outpic = scanlines;
  }
  else
  {
    /* unsharp mask */
    unsharp_mask(C, r, scanlines, unsharp);
    outpic = unsharp;
  }
  
  /* if message, put it on the image */
  if(text)
    matt_text(outpic, text);
  
  /* output the image */
  if(write_gfx(outname, outpic, quality) && v)
    fprintf(stderr, "Couldn't save file.\n");
    
  return grab_result;
}

