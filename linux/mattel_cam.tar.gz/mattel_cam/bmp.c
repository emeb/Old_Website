/*
 *  bmp.c - create BMP graphics files
 *  based on info from the graphics file format website
 *  08-06-00 E. Brombaugh
 *  08-20-00 E. Brombaugh updated for RGB input order, fix padding
 */

#include <stdio.h>
#include <stdlib.h>
#include "bmp.h"

int bmp24_init(bmp_struct *bmps, FILE *bmoutfile, int width, int height)
{
  int size;
  
  /* calculate size */
  size = 3*width;                      // size of one line
  size += ((size&3) ? 4-(size&3) : 0); // adjust to 32-bit boundary
  bmps->rowsize = size;                // save that for later
  size *= height;                      // times number of lines;
  
  /*  load up the structures
   *  first, the fileheader
   */
  bmps->bmfh.bfType = 0x4d42;
  bmps->bmfh.bfSize = size+54;
  bmps->bmfh.bfReserved1 = 0;
  bmps->bmfh.bfReserved2 = 0;
  bmps->bmfh.bfOffBits = 54;
  
  /* second, the bitmapinfoheader */
  bmps->bmih.biSize = 40;
  bmps->bmih.biWidth = width;
  bmps->bmih.biHeight = height;
  bmps->bmih.biPlanes = 1;
  bmps->bmih.biBitCount = 24;
  bmps->bmih.biCompression = BI_RGB;
  bmps->bmih.biSizeImage = size;
  bmps->bmih.biXPelsPerMeter = 1;
  bmps->bmih.biYPelsPerMeter = 1;
  bmps->bmih.biClrUsed = 0;
  bmps->bmih.biClrImportant = 0;
  
  /* set the file pointer */
  bmps->bmoutfile = bmoutfile;
  
  /* allocate memory for the bitmap */
  bmps->bmdata = malloc(size);
  if(bmps->bmdata == NULL)
  {
    fprintf(stderr, "bmp24_init: Couldn't allocate %d bytes.\n", size);
    return -1;
  }
  bmps->size = size;

  /* init scanline count */
  bmps->next_scanline = 0;
  
  /* point to last row (Stupid bottom up DIB!) */
  bmps->bmptr = bmps->bmdata + bmps->size - bmps->rowsize;
  return 0;
}

int bmp24_write_scanlines(bmp_struct *bmps, BMPARRAY scanlines, int count)
{
  int l;
  int b;
  BMPSAMPLE *data;
  BYTE *bmptr;
  
  /* check that we haven't exceeded the data size */
  if((bmps->next_scanline + count) > bmps->bmih.biHeight)
  {
    fprintf(stderr, "bmp24_write_scanlines: max scanlines exceeded.\n");
    return -1;
  }
  
  /* save current start of line */
  bmptr = bmps->bmptr;
  
  /* write rows */
  for(l=0;l<count;l++)
  {
    /* get pointer to beginning of row */
    data = *scanlines++;
    
    /* copy data to bitmap */
    for(b=0;b<bmps->bmih.biWidth;b++)
    {
      /* BMP color order is BGR */
      *(bmps->bmptr++) = *(data+2);
      *(bmps->bmptr++) = *(data+1);
      *(bmps->bmptr++) = *data;
      data+=3;
    }
    
    /* pad out the rest of the line */
    b*=3;
    while(b<bmps->rowsize)
    {
      *(bmps->bmptr++) = 0;
      b++;
    }
    
    /* backup to beginning of next line */
    bmps->bmptr = bmptr - (bmps->rowsize);
  }
           
  /* update counters/pointers */
  bmps->next_scanline += count;

  return 0;
}

int bmp24_finish(bmp_struct *bmps)
{
  /* write the fileheader */
  fwrite(&bmps->bmfh, sizeof(BITMAPFILEHEADER), 1, bmps->bmoutfile);
  
  /* write the infoheader */
  fwrite(&bmps->bmih, sizeof(BITMAPINFOHEADER), 1, bmps->bmoutfile);

  /* write the bitmap memory */
  fwrite(bmps->bmdata, sizeof(BYTE), bmps->size, bmps->bmoutfile);
  
  /* free the bitmap memory */
  free(bmps->bmdata);
  
  return 0;
}

