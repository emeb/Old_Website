/* matttxt.h - add text to the mattel camera output
 * Blatantly stolen from webcam.c in the xawtv-3.12 distribution
 * 09-08-00 E. Brombaugh
 */


int matt_text(unsigned char *scanlines, char *text);
