/*
 *  gfxfile.h - write graphics files
 *  08-20-00 E. Brombaugh
 */

#ifndef _gfxfile_
#define _gfxfile_

#include <string.h>
#include <jpeglib.h>
#include "bmp.h"

int write_gfx(char *outname, unsigned char *scanlines, int quality);
int gfxtype(char *name);
void write_jpeg(FILE *outfile, unsigned char *scanlines, int quality);
void write_bmp(FILE *outfile, unsigned char *scanlines);
void write_ppm(FILE *outfile, unsigned char *scanlines);

#endif
