/* matttxt.c - add text to the mattel camera output
 * Blatantly stolen from webcam.c in the xawtv-3.12 distribution
 * 09-08-00 E. Brombaugh
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "font_8x8.h"
#define CHAR_HEIGHT  8
#define CHAR_WIDTH   8
#define CHAR_START   1

/* put text into the image */
int matt_text(unsigned char *scanlines, char *text)
{
  char *ptr;
  int i,x,y,f,len;

  len = strlen(text);

  if(len > 20)
    return -1;
  
  for (y = 0; y < CHAR_HEIGHT; y++)
  {
    ptr = scanlines + 3 * 164 * (124-CHAR_HEIGHT+y) + 9;
    for (x = 0; x < len; x++)
    {
      f = fontdata[text[x] * CHAR_HEIGHT + y];
      for(i = CHAR_WIDTH-1; i >= 0; i--)
      {
        if (f & (CHAR_START << i))
        {
          /* White pixel */
          ptr[0] = 255;
          ptr[1] = 255;
          ptr[2] = 255;
        }
        else
        {
          /* Dim/gray pixel */
          ptr[0] = (ptr[0] >> 1) + 64;
          ptr[1] = (ptr[1] >> 1) + 64;
          ptr[2] = (ptr[2] >> 1) + 64;
        }
        ptr += 3;
      }
    }
  }
  
  return 0;
}

