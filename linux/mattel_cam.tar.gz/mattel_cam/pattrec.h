/*
 *  pattrec.h - demosaic by Y/Cr/Cb with pattern recognition
 *  09-02-00 E. Brombaugh
 */

#ifndef _pattrec_
#define _pattrec_

void pattrec(unsigned char *gfx);

#endif
