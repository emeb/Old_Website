/*
 *  mattgfx.c - mattel camera graphics routines
 *  graphic manipulations of camera graphics
 *  08-19-00 E. Brombaugh
 */

#include "mattgfx.h"
#include "pattrec.h"

#define ISEVEN(a) (((a)&1)!=1)
#define GETADD(x, y) ((3*(x))+(164*3*(y)))

void nneighbor(unsigned char *scanlines);
void bilinear(unsigned char *scanlines);
int avg2(int a, int b);
int avg4(int a, int b, int c, int d);
int sat(int a);
int fsat(double a);
int rnd_div(int a, int div);

void bayer_parse(unsigned char *camera_data, unsigned char *scanlines)
{
  int i, nx, x, y;
  int black;
  int pixel;
  int color;
  int bayer;
  double gain;
  
  /* find black level and gain correction*/
  black = 255;
  for(y=0;y<2;y++)
  {
    for(x=0;x<164;x++)
    {
      pixel = camera_data[y*164+x];
      black = (black < pixel) ? black : pixel;
    }
  }
  gain = 255.0/(255.0-(double)black);
  
  /* parse the Bayer camera data into the RGB bmp scanlines */
  /* subtract black level and correct gain */
  for(y=0;y<126;y++)
  {
    for(x=0;x<164;x++)
    {
      /* get the pixel data in unshuffled form */
      nx = ISEVEN(x) ? 84+(x>>1) : (x>>1);
      
      /* Argh! Array is really 168 pixels, so shuffle centers on 84
         but Mattel Camera only gives us 164.  This means we ignore
         pixels 82 & 83 and duplicate pixel 162 for 163 and 164  */
      nx = (nx > 163) ? nx-2 : nx;
      
      pixel = camera_data[y*164+nx];
      
      /* get the scanline address */
      i = GETADD(x,y);
      
      /* compute bayer pixel number 0:g1, 1:r, 2:b, 3:g2 */
      bayer = ((ISEVEN(y)) ? 0 : 2) + ((ISEVEN(x)) ? 0 : 1);

      switch(bayer)
      {
        case 0: color = GREEN; break;
        case 1: color = RED; break;
        case 2: color = BLUE; break;
        case 3: color = GREEN; break;
      }  
      
      /* assign the color */
      scanlines[i+RED] = 0;
      scanlines[i+GREEN] = 0;
      scanlines[i+BLUE] = 0;
      scanlines[i+color] = sat((double)(pixel-black)*gain);
    }
  }
}

void demosaic(int type, unsigned char *scanlines)
{
  switch(type)
  {
    case 0:  /* none */
      break;
      
    case 1:  /* nearest neighbor */
      nneighbor(scanlines);
      break;
      
    case 2:  /* bilinear */
      bilinear(scanlines);
      break;
      
    case 3:  /* pattern recognition */
      pattrec(scanlines);
      break;
      
    default: /* others? */
  }     
}

void nneighbor(unsigned char *scanlines)
{
  int i, x, y;
  int bayer;
  
  for(y=4;y<124;y++)
  {
    for(x=2;x<162;x++)
    {      
      /* get the scanline address */
      i = GETADD(x,y);
      
      /* compute bayer pixel number 0:g1, 1:r, 2:b, 3:g2 */
      bayer = ((ISEVEN(y)) ? 0 : 2) + ((ISEVEN(x)) ? 0 : 1);
      
      switch(bayer)
      {
        case 0: // GREEN 1
          scanlines[i+RED] = scanlines[GETADD(x+1,y)+RED];
          scanlines[i+BLUE] = scanlines[GETADD(x,y+1)+BLUE];
          break;
        case 1: // RED
          scanlines[i+GREEN] = scanlines[GETADD(x-1,y)+GREEN];
          scanlines[i+BLUE] = scanlines[GETADD(x-1,y+1)+BLUE];
          break;
        case 2: // BLUE
          scanlines[i+GREEN] = scanlines[GETADD(x+1,y)+GREEN];
          scanlines[i+RED] = scanlines[GETADD(x+1,y-1)+RED];
          break;
        case 3: // GREEN 2
          scanlines[i+RED] = scanlines[GETADD(x,y-1)+RED];
          scanlines[i+BLUE] = scanlines[GETADD(x-1,y)+BLUE];
          break;
      }
    }
  }
}

void bilinear(unsigned char *scanlines)
{
  int i, x, y;
  int bayer;
  
  for(y=4;y<124;y++)
  {
    for(x=2;x<162;x++)
    {      
      /* get the scanline address */
      i = GETADD(x,y);
      
      /* compute bayer pixel number 0:g1, 1:r, 2:b, 3:g2 */
      bayer = ((ISEVEN(y)) ? 0 : 2) + ((ISEVEN(x)) ? 0 : 1);
      
      switch(bayer)
      {
        case 0: /* GREEN 1 */
          /* average blues */
          scanlines[i+BLUE] = avg2(scanlines[GETADD(x,y-1)+BLUE],
                                   scanlines[GETADD(x,y+1)+BLUE]);
          /* average reds */
          scanlines[i+RED] = avg2(scanlines[GETADD(x-1,y)+RED],
                                  scanlines[GETADD(x+1,y)+RED]);
          break;
          
        case 1: /* RED */
          /* avg blue and green */
          scanlines[i+BLUE] = avg4(scanlines[GETADD(x-1,y-1)+BLUE],
                                   scanlines[GETADD(x+1,y-1)+BLUE],
                                   scanlines[GETADD(x-1,y+1)+BLUE],
                                   scanlines[GETADD(x+1,y+1)+BLUE]);
          scanlines[i+GREEN] = avg4(scanlines[GETADD(x-1,y)+GREEN],
                                    scanlines[GETADD(x,y-1)+GREEN],
                                    scanlines[GETADD(x,y+1)+GREEN],
                                    scanlines[GETADD(x-1,y)+GREEN]);
          break;
          
        case 2: /* BLUE */
          /* avg red, avg green */
          scanlines[i+RED] = avg4(scanlines[GETADD(x-1,y-1)+RED],
                                  scanlines[GETADD(x+1,y-1)+RED],
                                  scanlines[GETADD(x-1,y+1)+RED],
                                  scanlines[GETADD(x+1,y+1)+RED]);
          scanlines[i+GREEN] = avg4(scanlines[GETADD(x-1,y)+GREEN],
                                    scanlines[GETADD(x,y-1)+GREEN],
                                    scanlines[GETADD(x,y+1)+GREEN],
                                    scanlines[GETADD(x-1,y)+GREEN]);
          break;
          
        case 3: /* GREEN 2 */
          /* average reds */
          scanlines[i+RED] = avg2(scanlines[GETADD(x,y-1)+RED],
                                  scanlines[GETADD(x,y+1)+RED]);
          /* average blues */
          scanlines[i+BLUE] = avg2(scanlines[GETADD(x-1,y)+BLUE],
                                   scanlines[GETADD(x+1,y)+BLUE]);
      }  
    }
  }
}

void unsharp_mask(double C, int r, unsigned char *scanlines, unsigned char *unsharp)
{
  int x, y, color, nx, u, j, n, i, m;
  double U;
  
  for(y=4;y<124;y++)
  {
    for(x=2;x<162;x++)
    {
      for(color=0;color<3;color++)
      {
        /* initialize pixel counter */
        nx = 0;
        
        /* compute local average */
        u=0;
        for(j=-r;j<=r;j++)
        {
          /* compute vertical pixel offset */
          n = y+j;
          
          /* skip if off image */
          if((n>=0)&&(n<124))
          {
            for(i=-r;i<=r;i++)
            {
              /* compute horizontal pixel offset */
              m = x+i;
              
              /* skip if off image */
              if((m>=0)&&(m<164))
              {
                u += scanlines[GETADD(x+i,y+j)+color];
                nx++;
              }
            }
          }
        }
        
        /* compute unsharp mask */
        U = C*(double)scanlines[GETADD(x,y)+color] - 
           (C - 1.0) * ((double)u/(double)nx);
        
        /* save to new buffer */
        unsharp[GETADD(x,y)+color] = fsat(U+0.5);
      }
    }
  }
}

int avg2(int a, int b)
{
  return sat(rnd_div(a+b,2));
}

int avg4(int a, int b, int c, int d)
{
  return sat(rnd_div(a+b+c+d,4));
}

int fsat(double a)
{
  int out;
  out = a<0 ? 0 : a;
  return out>255 ? 255 : out;
}

int sat(int a)
{
  return a>255 ? 255 : a;
}

int rnd_div(int a, int div)
{
  double out = (double)a;
  
  out = (out / (double)div) + 0.5;
  
  return out;
}


  
