/*
 *  mattgfx.h - mattel camera graphics routines
 *  graphic manipulations of camera graphics
 *  08-19-00 E. Brombaugh
 */

#ifndef _mattgfx_
#define _mattgfx_

#define RED 0
#define GREEN 1
#define BLUE 2

void bayer_parse(unsigned char *camera_data, unsigned char *scanlines);
void demosaic(int type, unsigned char *scanlines);
void unsharp_mask(double C, int r, unsigned char *scanlines, unsigned char *unsharp);

#endif
