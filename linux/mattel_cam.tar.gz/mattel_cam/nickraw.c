/* 
 * nickraw.c - upload a raw image from the Nick Click camera
 * 09-03-00 E. Brombaugh forked from nickctl.c.
 */

#include <stdio.h>
#include <stdlib.h>
#include "mattcam.h"

#define GETADD(x, y) ((3*(x))+(164*3*(y)))
#define ISEVEN(a) (((a)&1)!=1)
#define RED 0
#define GREEN 1
#define BLUE 2

int sat(int a)
{
  return a>255 ? 255 : a;
}

void bayer_parse(unsigned char *camera_data, unsigned char *scanlines)
{
  int i, nx, x, y;
  int black;
  int pixel;
  int color;
  int bayer;
  double gain;
  
  /* find black level and gain correction*/
  black = 255;
  for(y=0;y<2;y++)
  {
    for(x=0;x<164;x++)
    {
      pixel = camera_data[y*164+x];
      black = (black < pixel) ? black : pixel;
    }
  }
  gain = 255.0/(255.0-(double)black);
  
  /* parse the Bayer camera data into the RGB bmp scanlines */
  /* subtract black level and correct gain */
  for(y=0;y<126;y++)
  {
    for(x=0;x<164;x++)
    {
      /* get the pixel data in unshuffled form */
      nx = ISEVEN(x) ? 84+(x>>1) : (x>>1);
      
      /* Argh! Array is really 168 pixels, so shuffle centers on 84
         but Mattel Camera only gives us 164.  This means we ignore
         pixels 82 & 83 and duplicate pixel 162 for 163 and 164  */
      nx = (nx > 163) ? nx-2 : nx;
      
      pixel = camera_data[y*164+nx];
      
      /* get the scanline address */
      i = GETADD(x,y);
      
      /* compute bayer pixel number 0:g1, 1:r, 2:b, 3:g2 */
      bayer = ((ISEVEN(y)) ? 0 : 2) + ((ISEVEN(x)) ? 0 : 1);

      switch(bayer)
      {
        case 0: color = GREEN; break;
        case 1: color = RED; break;
        case 2: color = BLUE; break;
        case 3: color = GREEN; break;
      }  
      
      /* assign the color */
      scanlines[i+RED] = 0;
      scanlines[i+GREEN] = 0;
      scanlines[i+BLUE] = 0;
      scanlines[i+color] = sat((double)(pixel-black)*gain);
    }
  }
}

void write_raw_ppm(FILE *outfile, unsigned char *scanlines)
{
  int y;
  
  /* write the header */
  fprintf(outfile, "P6\n");
  fprintf(outfile, "# Created by nickctl\n");
  fprintf(outfile, "164\n126\n255\n");
  
  /* write the data */
  for(y=0;y<126;y++)
  {
    fwrite((scanlines+(y*164*3)), sizeof(unsigned char), (3*164), outfile);
  }
}

int main(int argc, char **argv)
{
  /* variables for getopt() */
  extern char *optarg;
  int opt;
  
  mc_struct mcs;
  int comm_err=0;
  char *inname = "/dev/ttyS0", *outname = "nick.jpg";
  unsigned char databuf[20680];
  unsigned char scanlines[126*3*164];
  int v;
  int u;
  FILE *outfile;
  
  /* defaults */
  u = 0;
  v = 0;
  
  /* parse options */
  while((opt = getopt(argc, argv, "d:o:u:vh")) != EOF)
  {
    switch(opt)
    {
      case 'd':
        /* input device */
        inname = optarg;
        break;

      case 'o':
        /* out filename */
        outname = optarg;
        break;

      case 'u':
        /* upload image */
        u = atoi(optarg);
        break;

      case 'v':
        /* Verbose mode */
        v = 1;
        break;
        
      case 'h':
      case '?':
        fprintf(stderr, "USAGE: %s [options]\n", argv[0]);
        fprintf(stderr, "Options are: -d <device>         Default: %s\n", inname);
        fprintf(stderr, "             -o <out file>       Default: %s\n", outname);
        fprintf(stderr, "             -u <image #>        Default: %d\n", u);
        fprintf(stderr, "             -v (verbose)        Default: off\n");
        exit(1);
    }
  }
  
  /* open up the camera I/O */
  if(init_mc(&mcs, inname, v))
  {
    fprintf(stderr, "Trouble opening the camera I/O.");
    exit(-1);
  }

  if(mc_send_cmd(&mcs, ADDR_IMAGE, u)==ERR_COMM)
    comm_err |= 8;
  
  /* get the picture */
  bzero(databuf, sizeof(databuf));
  if(mc_recv_pic(&mcs, databuf)==ERR_COMM)
    comm_err |= 16;
  
  /* we're all done with the camera, so close it */
  close_mc(&mcs);

  /* check if everything worked */
  if(comm_err)
  {
    if(v)
      fprintf(stderr, "Communications Error %x: aborting.\n", comm_err);
    exit(ERR_COMM);
  }
  
  /* correct black level and parse camera data into rgb array */
  bayer_parse(databuf, scanlines);
  
  /* open the output file */
  if(!(outfile = fopen(outname, "wb")))
  {
    if(v)
      fprintf(stderr, "Couldn't open %s for output.\n", outname);
    exit(-1);
  }
  
  write_raw_ppm(outfile, scanlines);
  
  fclose(outfile);
  
  return 0;
}

