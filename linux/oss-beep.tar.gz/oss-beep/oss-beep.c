/* oss-beep.c : beep through the OSS audio device */
/* 10-13-01 : E. Brombaugh */

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>
#include <math.h>

/*
 * Mandatory variables.
 */

#define BUF_SIZE    4096

int audio_fd;  
unsigned char audio_buffer[BUF_SIZE], *audio_bufptr;  

/* 16 sample 16-bit sinewave table */
int sintab[16] =
{0,  12540,  23170,  30273,  32767,  30273,  23170,  12540,
 0, -12540, -23170, -30273, -32767, -30273, -23170, -12540}; 

int main(int argc, char **argv)
{
  // variables for getopt()
  extern char *optarg;
  int opt;

  // rest of vars...
  int chl = 0;                  // channel 0=mono, 1=left, 2=right, 3=stereo
  int freq = 440;               // frequency
  int vol = 255;                // volume
  int verbose = 0;              // 
  int dur = 1000;               // duration (ms)
  int format_in = AFMT_U8, format_out;    // width
  int stereo_in = 0, stereo_out;    // derived from channel
  int rate_in, rate_out;        // derived from frequency
  char *outname = "/dev/dsp";	// output filename
  int i, wsample, t, bps, samples, len;
  char bsample;
  
  // parse options
  while((opt = getopt(argc, argv, "w:o:f:v:Vd:c:h")) != EOF)
  {
    switch(opt)
    {
      case 'w':
        /* width */
        switch(atoi(optarg))
        {
          case 8:
            format_in = AFMT_U8;
            break;
            
          case 16:
            format_in = AFMT_S16_LE;
            break;
          
          default:
            fprintf(stderr, "Unknown width (use 8 or 16)\n");
            exit(-1);
        }
        break;
                
      case 'o':
        /* output file */
        outname = optarg;
        break;

      case 'f':
        /* freq */
        freq = atoi(optarg);
        if((freq < 0) || (freq > 3000))
        {
          fprintf(stderr, "Frequency out of range: 0 - 3000\n");
          exit(-1);
        }
        break;

      case 'v':
        /* volume */
        vol = atoi(optarg);
        if((vol < 0) || (vol > 255))
        {
          fprintf(stderr, "Volume out of range: 0 - 255\n");
          exit(-1);
        }
        break;
      
      case 'V':
        verbose = 1;
        break;
        
      case 'd':
        /* duration */
        dur = atoi(optarg);
        if((dur < 1) || (dur > 10000))
        {
          fprintf(stderr, "Duration out of range: 1 - 10000\n");
          exit(-1);
        }
        break;

      case 'c':
        /* channels */
        switch(optarg[0])
        {
          case 'm':
            stereo_in = 0;
            chl = 0;
            break;
          
          case 'r':
            stereo_in = 1;
            chl = 1;
            break;
          
          case 'l':  
            stereo_in = 1;
            chl = 2;
            break;
          
          case 's':
            stereo_in = 1;
            chl = 3;
            break;
        }
        break;

      case 'h':
      case '?':
        fprintf(stderr, "USAGE: %s [options]\n", argv[0]);
        fprintf(stderr, "Options:\n");
        fprintf(stderr, " -w <bits> (8 | 16)        Default: %d\n", format_in);
        fprintf(stderr, " -o <output file>          Default: %s\n", outname);
        fprintf(stderr, " -f <freq> (0 - 3000)      Default: %d\n", freq);
        fprintf(stderr, " -v <vol> (0 - 255)        Default: %d\n", vol);
        fprintf(stderr, " -V (verbose)              Default: off\n");
        fprintf(stderr, " -d <dur> (1 - 10000)      Default: %d\n", dur);
        fprintf(stderr, " -c <chl> (m | l | r | s)  Default: m\n");
        fprintf(stderr, " -h (this message)\n");
        exit(1);
    }
  }
  
  /* open up the sound device for output */
  if((audio_fd = open(outname, O_WRONLY, 0)) == -1)  
  {
    fprintf(stderr, "Can't open %s for output!\n", outname);
    exit(-1);
  }

  /* set to desired format */
  format_out = format_in;
  if(ioctl(audio_fd, SNDCTL_DSP_SETFMT, &format_out)==-1)  
  {
    /* Fatal error */  
    perror("SNDCTL_DSP_SETFMT");  
    exit(-1);  
  }
  
  if(format_out != format_in)
    fprintf(stderr, "Format Mismatch: requested %d, reports %d)\n", format_in, format_out);
  
  /* set stereo */
  stereo_out = stereo_in;     /* 0=mono, 1=stereo */
  if(ioctl(audio_fd, SNDCTL_DSP_STEREO, &stereo_out)==-1)
  { /* Fatal error */
    perror("SNDCTL_DSP_STEREO");
    exit(-1);
  }

  if (stereo_out != stereo_in)
    fprintf(stderr, "Stereo Mismatch: requested %d, reports %d)\n", stereo_in, stereo_out);
  
  /* set sample rate */
  rate_out = rate_in = freq * 16;
  if(ioctl(audio_fd, SNDCTL_DSP_SPEED, &rate_out)==-1)  
  { /* Fatal error */  
    perror("SNDCTL_DSP_SPEED");  
    exit(-1);  
  }  

  if(abs(rate_out - rate_in) > rate_in/100)
    fprintf(stderr, "Rate Mismatch: requested %d, reports %d\n", rate_in, rate_out);

  /* load the buffer with correctly formatted sine data */
  i=0;
  t=0;
  while(i<BUF_SIZE)
  {
    /* compute the next sample of data */
    wsample = (sintab[t] * vol) / 256;
    t = (t+1)&15;
    
    if(format_out == AFMT_S16_LE)
    {
      /* 16-bit audio data */
      switch(chl)
      {
        case 0: /* mono */
          audio_buffer[i++] = wsample&0xff;
          audio_buffer[i++] = (wsample>>8)&0xff;
          break;
        
        case 1: /* right stereo */
          audio_buffer[i++] = wsample&0xff;
          audio_buffer[i++] = (wsample>>8)&0xff;
          audio_buffer[i++] = 0;
          audio_buffer[i++] = 0;
          break;
          
        case 2: /* left stereo */
          audio_buffer[i++] = 0;
          audio_buffer[i++] = 0;
          audio_buffer[i++] = wsample&0xff;
          audio_buffer[i++] = (wsample>>8)&0xff;
          break;
          
        case 3: /* both stereo */
          audio_buffer[i++] = wsample&0xff;
          audio_buffer[i++] = (wsample>>8)&0xff;
          audio_buffer[i++] = wsample&0xff;
          audio_buffer[i++] = (wsample>>8)&0xff;
          break;
      }
    } /* 16-bit */ 
    else
    {
      /* 8-bit audio */
      bsample = 128 + (wsample >> 8);
      
      switch(chl)
      {
        case 0: /* mono */
          audio_buffer[i++] = bsample;
          break;
        
        case 1: /* left stereo */
          audio_buffer[i++] = bsample;
          audio_buffer[i++] = 0;
          break;
          
        case 2: /* right stereo */
          audio_buffer[i++] = 0;
          audio_buffer[i++] = bsample;
          break;
          
        case 3: /* both stereo */
          audio_buffer[i++] = bsample;
          audio_buffer[i++] = bsample;
          break;
      }
    } /* 8-bit */ 
  } /* while */
  
  /* compute duration in samples */
  samples = rate_out * dur / 1000;
  
  /* compute bytes per sample */
  bps = ((format_out == AFMT_S16_LE) ? 2 : 1) * ((chl == 0) ? 1 : 2);
  
  /* verbose output */
  if(verbose)
  {
    fprintf(stdout, "frequency: %d -> rate: %d\n", freq, rate_out);
    fprintf(stdout, "width: %d, channel: %d\n", format_out, chl);
    fprintf(stdout, "duration: %d -> samples: %d\n", dur, samples);
  }
  
  /* generate samples of sound */
  while((samples * bps) >= BUF_SIZE)
  {
    if ((len = write(audio_fd, audio_buffer, BUF_SIZE)) == -1)  
    {  
      perror("audio write");  
      exit(-1);  
    }
      
    if(len != BUF_SIZE)
    {
      fprintf(stderr, "Intermediate Buffer length mismatch\n");
      exit(-1);
    }
    
    samples -= BUF_SIZE/bps;
  }
  
  /* final partial buffer */
  if ((len = write(audio_fd, audio_buffer, samples*bps)) == -1)  
  {  
    perror("audio write");
    exit(-1);  
  }
  
  if(len != samples*bps)
  {
    fprintf(stderr, "Final Buffer length mismatch\n");
    exit(-1);
  }
      
  close(audio_fd);
  
  return 0;
}

       
