/*
 *  gfxfile.h - write graphics files
 *  08-20-00 E. Brombaugh
 *  02-15-03 E. Brombaugh - made image size variable
 *
 * Copyright (C) 2000, 2003 Eric Brombaugh
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _gfxfile_
#define _gfxfile_

#include <stdlib.h>
#include <string.h>
#include <jpeglib.h>
#include "bmp.h"
#include "image.h"

int write_gfx(char *outname, image *im, int quality);
int gfxtype(char *name);
void write_jpeg(FILE *outfile, image *im, int quality);
void write_bmp(FILE *outfile, image *im);
void write_ppm(FILE *outfile, image *im);

#endif
