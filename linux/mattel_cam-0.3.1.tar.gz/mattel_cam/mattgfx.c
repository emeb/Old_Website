/*
 *  mattgfx.c - mattel camera graphics routines
 *  graphic manipulations of camera graphics
 *  08-19-00 E. Brombaugh
 *  02-15-03 E. Brombaugh - convert to use image structure
 *  02-17-03 E. Brombaugh - added Kurt Garloff's alg from libgphoto
 *
 * Copyright (C) 2000, 2003 Eric Brombaugh
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mattgfx.h"
#include "pattrec.h"
#include "demosaic_sharpen.h"

#define RED 0
#define GRN 1
#define BLU 2
#define ISEVEN(a) (((a)&1)!=1)
#define ADDRS(x, y, w) (3*((x)+((w)*(y))))

/* unsigned saturation */
int sat(int a)
{
  return a>255 ? 255 : a;
}

/* divide and round */
int rnd_div(int a, int div)
{
  double out = (double)a;
  
  out = (out / (double)div) + 0.5;
  
  return out;
}

/* average two values */
int avg2(int a, int b)
{
  return sat(rnd_div(a+b,2));
}

/* average four values */
int avg4(int a, int b, int c, int d)
{
  return sat(rnd_div(a+b+c+d,4));
}

/* parse the camera data into an image */
image  *bayer_parse(unsigned char *camera_data)
{
  image *im;
  int i, nx, x, y;
  int black;
  int pixel;
  int color;
  int bayer;
  double gain;
  
  /* create a new image */
  if(!(im = create_image(164, 124)))
    return NULL;
  
  /* find black level and gain correction*/
  black = 255;
  for(y=0;y<2;y++)
  {
    for(x=0;x<164;x++)
    {
      pixel = camera_data[y*164+x];
      black = (black < pixel) ? black : pixel;
    }
  }
  gain = 255.0/(255.0-(double)black);
  
  /* parse the Bayer camera data into the image scanlines */
  /* subtract black level and correct gain */
  for(y=0;y<124;y++)
  {
    for(x=0;x<164;x++)
    {
      /* get the pixel data in unshuffled form */
      nx = ISEVEN(x) ? 84+(x>>1) : (x>>1);
      
      /* Argh! Array is really 168 pixels, so shuffle centers on 84
         but Mattel Camera only gives us 164.  This means we ignore
         pixels 82 & 83 and duplicate pixel 162 for 163 and 164  */
      nx = (nx > 163) ? nx-2 : nx;
      
      pixel = camera_data[(y+2)*164+nx];
      
      /* get the scanline address */
      i = ADDRS(x,y,164);
      
      /* compute bayer pixel number 0:g1, 1:r, 2:b, 3:g2 */
      bayer = ((ISEVEN(y)) ? 0 : 2) + ((ISEVEN(x)) ? 0 : 1);

      switch(bayer)
      {
        case 0: color = GRN; break;
        case 1: color = RED; break;
        case 2: color = BLU; break;
        case 3: color = GRN; break;
      }  
      
      /* assign the color */
      im->scanlines[i+RED] = 0;
      im->scanlines[i+GRN] = 0;
      im->scanlines[i+BLU] = 0;
      im->scanlines[i+color] = sat((double)(pixel-black)*gain);
    }
  }
  
  return im;
}


/* nearest neighbor demosaic */
void nneighbor(image *im)
{
  int i, x, y;
  int bayer;
  
  for(y=0;y<im->ys;y++)
  {
    for(x=0;x<im->xs;x++)
    {      
      /* get the scanline address */
      i = ADDRS(x,y,im->xs);
      
      /* compute bayer pixel number 0:g1, 1:r, 2:b, 3:g2 */
      bayer = ((ISEVEN(y)) ? 0 : 2) + ((ISEVEN(x)) ? 0 : 1);
      
      switch(bayer)
      {
        case 0: // GRN 1
          im->scanlines[i+RED] = im->scanlines[ADDRS(x+1,y,im->xs)+RED];
          im->scanlines[i+BLU] = im->scanlines[ADDRS(x,y+1,im->xs)+BLU];
          break;
        case 1: // RED
          im->scanlines[i+GRN] = im->scanlines[ADDRS(x-1,y,im->xs)+GRN];
          im->scanlines[i+BLU] = im->scanlines[ADDRS(x-1,y+1,im->xs)+BLU];
          break;
        case 2: // BLU
          im->scanlines[i+GRN] = im->scanlines[ADDRS(x+1,y,im->xs)+GRN];
          im->scanlines[i+RED] = im->scanlines[ADDRS(x+1,y-1,im->xs)+RED];
          break;
        case 3: // GRN 2
          im->scanlines[i+RED] = im->scanlines[ADDRS(x,y-1,im->xs)+RED];
          im->scanlines[i+BLU] = im->scanlines[ADDRS(x-1,y,im->xs)+BLU];
          break;
      }
    }
  }
}

/* bilinear interpolation demosaic */
void bilinear(image *im)
{
  int i, x, y;
  int bayer;
  
  for(y=0;y<im->ys;y++)
  {
    for(x=0;x<im->xs;x++)
    {      
      /* get the scanline address */
      i = ADDRS(x,y,im->xs);
      
      /* compute bayer pixel number 0:g1, 1:r, 2:b, 3:g2 */
      bayer = ((ISEVEN(y)) ? 0 : 2) + ((ISEVEN(x)) ? 0 : 1);
      
      switch(bayer)
      {
        case 0: /* GRN 1 */
          /* average blues */
          im->scanlines[i+BLU] = avg2(im->scanlines[ADDRS(x,y-1,im->xs)+BLU],
                                      im->scanlines[ADDRS(x,y+1,im->xs)+BLU]);
          /* average reds */
          im->scanlines[i+RED] = avg2(im->scanlines[ADDRS(x-1,y,im->xs)+RED],
                                      im->scanlines[ADDRS(x+1,y,im->xs)+RED]);
          break;
          
        case 1: /* RED */
          /* avg blue and green */
          im->scanlines[i+BLU] = avg4(im->scanlines[ADDRS(x-1,y-1,im->xs)+BLU],
                                      im->scanlines[ADDRS(x+1,y-1,im->xs)+BLU],
                                      im->scanlines[ADDRS(x-1,y+1,im->xs)+BLU],
                                      im->scanlines[ADDRS(x+1,y+1,im->xs)+BLU]);
          im->scanlines[i+GRN] = avg4(im->scanlines[ADDRS(x-1,y,im->xs)+GRN],
                                      im->scanlines[ADDRS(x,y-1,im->xs)+GRN],
                                      im->scanlines[ADDRS(x,y+1,im->xs)+GRN],
                                      im->scanlines[ADDRS(x-1,y,im->xs)+GRN]);
          break;
          
        case 2: /* BLU */
          /* avg red, avg green */
          im->scanlines[i+RED] = avg4(im->scanlines[ADDRS(x-1,y-1,im->xs)+RED],
                                      im->scanlines[ADDRS(x+1,y-1,im->xs)+RED],
                                      im->scanlines[ADDRS(x-1,y+1,im->xs)+RED],
                                      im->scanlines[ADDRS(x+1,y+1,im->xs)+RED]);
          im->scanlines[i+GRN] = avg4(im->scanlines[ADDRS(x-1,y,im->xs)+GRN],
                                      im->scanlines[ADDRS(x,y-1,im->xs)+GRN],
                                      im->scanlines[ADDRS(x,y+1,im->xs)+GRN],
                                      im->scanlines[ADDRS(x-1,y,im->xs)+GRN]);
          break;
          
        case 3: /* GRN 2 */
          /* average reds */
          im->scanlines[i+RED] = avg2(im->scanlines[ADDRS(x,y-1,im->xs)+RED],
                                      im->scanlines[ADDRS(x,y+1,im->xs)+RED]);
          /* average blues */
          im->scanlines[i+BLU] = avg2(im->scanlines[ADDRS(x-1,y,im->xs)+BLU],
                                      im->scanlines[ADDRS(x+1,y,im->xs)+BLU]);
      }  
    }
  }
}

/* wrapper for Kurt Garloff's algorithm from the libgphoto stv0680 driver */
void garloff(image *src)
{
  image *dst;
  
  /* make a destination for the result */
  if(!(dst = create_image(src->xs, src->ys)))
    return;
  
  /* run Kurt's alg */
  demosaic_sharpen(src->xs, src->ys,
		         src->scanlines, 
		         dst->scanlines, 
		         2, BAYER_TILE_GBRG_INTERLACED);
  
  /* now copy it back to src */
  memcpy(src->scanlines, dst->scanlines, src->xs*src->ys*3);
  
  /* free up the dst image */
  destroy_image(dst);
}

/* demosaic the image */
void demosaic(int type, image *im)
{
  switch(type)
  {
    case 0:  /* none */
      break;
      
    case 1:  /* nearest neighbor */
      nneighbor(im);
      break;
      
    case 2:  /* bilinear */
      bilinear(im);
      break;
      
    case 3:  /* pattern recognition */
      pattrec(im);
      break;
    
    case 4: /* Kurt's method */
      garloff(im);
      break;
      
    //default: /* others? */
  }     
}

