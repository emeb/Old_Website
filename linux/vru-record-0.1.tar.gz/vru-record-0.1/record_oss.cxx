// record_oss.cxx
// source file for record OSS interface class
//
// Copyright (C) 2003 Eric Brombaugh
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>

#include "record_oss.h"
#include "wav_funcs.h"

// constructor
record_oss::record_oss(char *device_name) {
	strcpy(devname, device_name);
	state = 0;	// idle
}

// destructor
record_oss::~record_oss() {
	// free the buffer memory
	if(buffer)
		free(buffer);
		
	// close the audio device if it's still open
	if(audio_fd)
		close(audio_fd);
	
	// close the audio file if it's still open
	if(file)
		fclose(file);
}

int record_oss::config_audio(char *devname, int mode, int fmt, int chl, int *rate, int *frag_size) {
	int audio_fd;
	int fmt_in, fmt_out;		// AFMT_U8 = 8bit, AFMT_S16_LE = 16bit signed
	int rate_in, rate_out;		// sample rate
	int stereo_in, stereo_out;	// 0=mono, 1=stereo

	// open up the audio device
	if((audio_fd = open(devname, mode, 0)) == -1) {
		fprintf(stderr, "Can't open audio %s for output!\n");
		goto open_error;
	}
	
	// set audio data format
	fmt_out = fmt_in = (fmt == 8) ? AFMT_U8 : AFMT_S16_LE;
	if(ioctl(audio_fd, SNDCTL_DSP_SETFMT, &fmt_out)==-1)  
	{
		fprintf(stderr, "Can't set audio format!\n");
		goto device_error;  
	}
	if(fmt_out != fmt_in) {
		fprintf(stderr, "Format Mismatch: requested %d, reports %d\n", fmt_in, fmt_out);
		goto device_error;  
	}
		
	// set channels
	stereo_out = stereo_in = (chl == 2) ? 1 : 0;
	if(ioctl(audio_fd, SNDCTL_DSP_STEREO, &stereo_out)==-1) {
		fprintf(stderr, "Can't set stereo!\n");
		goto device_error;  
	}
	if(stereo_out != stereo_in) {
		fprintf(stderr, "Stereo Mismatch: requested %d, reports %d\n", stereo_in, stereo_out);
		goto device_error;  
	}
	
	// set audio sample rate
	rate_out = rate_in = *rate;
	if(ioctl(audio_fd, SNDCTL_DSP_SPEED, &rate_out)==-1) {
		fprintf(stderr, "Can't set audio rate!\n");
		goto device_error;  
	}  
	if(abs(rate_out - rate_in) > rate_in/100) {
		fprintf(stderr, "Rate Mismatch: requested %d, reports %d\n", rate_in, rate_out);
		goto device_error;  
	}
	*rate = rate_out;
	
	// get buffer size
	if (ioctl(audio_fd, SNDCTL_DSP_GETBLKSIZE, frag_size) == -1) {
		fprintf(stderr, "Can't get audio buffer size!\n");
		goto device_error;  
	}
	
	return audio_fd;
	
	device_error:
	close(audio_fd);
	audio_fd = 0;
		
	open_error:
	return -1;
}

// open a file for read and start playing
bool record_oss::start_play(char *name) {
	strcpy(fullname, name);
	
	// open up the file
	if(!(file = fopen(fullname, "r"))) {
		fprintf(stderr, "record_oss::start_play() - fopen('%s', 'r') failed\n", fullname);
		goto open_error;
	}
	
	// get the header info
	if(!read_wavhdr(file, &bytes, &rate, &fmt, &chl, &bps)) {
		fprintf(stderr, "record_oss::start_play() - read_wavhdr failed\n");
		goto file_error;
	}
	
	if((audio_fd = config_audio(devname, O_WRONLY, fmt, chl, &rate, &frag_size)) == -1) {
		fprintf(stderr, "Couldn't open/configure audio device\n");
		goto file_error;
	}
	
	// allocate a fragsize buffer
	if((buffer = (char *)malloc(frag_size)) == NULL) {
		fprintf(stderr, "Can't allocate %d bytes memory!\n", frag_size);
		goto mem_error;
	}

	// Now it should be safe to start writing data out
	used = 0;
	state = 1;	// play
	
	return true;
	
	mem_error:
	close(audio_fd);
	audio_fd = 0;
	
	file_error:
	fclose(file);
	file = NULL;
	
	open_error:
	return false;  
}

// callback for playing
// returns: 0-100 for updated file position
//          -1 for idle (no update)
//          -2 for end of file
int record_oss::play_cb(void *data) {
	int result = -1;
	record_oss* o = static_cast<record_oss*>(data);
	fd_set wfds;
	struct timeval tv;
	int num, len;
	audio_buf_info info;

	if(o->state == 1) {
#if(0)
		// use GETOSPACE to avoid blocking
		// This makes the us appear to hog the processor
		if(ioctl(o->audio_fd, SNDCTL_DSP_GETOSPACE, &info) == -1) {
			fprintf(stderr, "GETOSPACE failed\n");
		}		
		if(info.bytes > o->frag_size) {
#else
		// Allow blocking to free up the processor
		// This doesn't appear to hurt latency because we limit the
		// amount of data written to one fragment
		if(1) {
#endif
			// Grab data from the file
			num = fread(o->buffer, 1, o->frag_size, o->file);
			
			// write data to the audio device			
			if((len = write(o->audio_fd, o->buffer, num)) == -1) {  
				fprintf(stderr, "record_oss::play_cb - write failed\n");  
      				return -1;
			}
			if(len != num) {
				fprintf(stderr, "record_oss::play_cb - Buffer length mismatch\n");
				return -1;
    			}
			
			// update sent value
			o->used += num;
		
			// compute 100*sent/total for return value, or done
			result = 100 * o->used/(int)o->bytes;
			if(o->used >= o->bytes) {
				result = -2;
			}
		}
	}
	
	return result;
}

// stop playing and close the file
bool record_oss::stop_play() {
	if(state == 1) {
		state = 0;		// idle
		free(buffer);
		buffer = NULL;
		close(audio_fd);
		audio_fd = 0;
		fclose(file);
		file = NULL;
		return true;
	} else {
		fprintf(stderr, "record_oss::stop_play() - called while not playing\n");
		return false;
	}
}

// open a file for write and start recording
bool record_oss::start_record(char *name, int a_bytes, int a_fmt, int a_rate, int a_rgain) {
	strcpy(fullname, name);
	bytes = a_bytes;
	fmt = a_fmt;
	chl = 1;
	bps = (fmt/8)*chl;
	rate = a_rate;
	rgain = a_rgain;
	
	if((audio_fd = config_audio(devname, O_RDONLY, fmt, chl, &rate, &frag_size)) == -1) {
		fprintf(stderr, "Couldn't open/configure audio device\n");
		goto open_error;
	}
		
	// allocate a fragsize buffer
	if((buffer = (char *)malloc(bytes)) == NULL) {
		fprintf(stderr, "Can't allocate %d bytes memory!\n", bytes);
		goto mem_error;
	}

	// Now it should be safe to start writing data out
	used = 0;
	state = 2;	// record
	
	return true;
	
	mem_error:
	close(audio_fd);
	audio_fd = 0;
		
	open_error:
	return false;
}

// callback for recording
int record_oss::record_cb(void *data) {
	int result = -1;
	int size, num;
	record_oss* o = static_cast<record_oss*>(data);
	
	if(o->state == 2) {
		// Allow blocking to free up the processor
		// This doesn't appear to hurt latency because we limit the
		// amount of data read to one fragment
		if(1) {
			// Grab data from the audio device
			size = ((o->bytes - o->used) > o->frag_size) ? o->frag_size : (o->bytes - o->used);
			if((num = read(o->audio_fd, &(o->buffer[o->used]), size)) == -1) {
				fprintf(stderr, "record_oss::record_cb - read failed\n");
				return -1;
			}
						
			// update sent value
			o->used += num;
		
			// compute 100*sent/total for return value, or done
			result = 100 * o->used/(int)o->bytes;
			if(o->used >= o->bytes) {
				result = -2;
			}
		}
	}
	
	return result;
}

// stop recording and close the file
bool record_oss::stop_record() {
	bool result;
	int i;
	
	if(state == 2) {
		// apply the record gain
		if(rgain != 0) {
			switch(fmt) {
				case 8:
					for(i=0;i<used;i++) {
						if(rgain < 0)
							buffer[i] >>= -rgain;
						else
							buffer[i] <<= rgain;
					}
					break;
				
				case 16:
					for(i=0;i<(used/2);i++) {
						if(rgain < 0)
							(short)buffer[i] >>= -rgain;
						else
							(short)buffer[i] <<= rgain;
					}
					break;
			}
		}
		
		// open up the file
		if(!(file = fopen(fullname, "w"))) {
			fprintf(stderr, "record_oss::stop_record() - fopen('%s', 'w') failed\n", fullname);
			result = false;
			goto open_error;
		}
	
		// put the header info
		if(!write_wavhdr(file, used, rate, fmt, chl)) {
			fprintf(stderr, "record_oss::stop_record() - write_wavhdr failed\n");
			result = false;
			goto file_error;
		}
		
		// put the data
		if(fwrite(buffer, sizeof(char), used, file) != used) {
			fprintf(stderr, "record_oss::stop_record() - write data failed\n");
			result = false;
			goto file_error;
		}
		
		result = true;
		
		file_error:
		fclose(file);
		file = NULL;
		
		open_error:
		free(buffer);
		buffer = NULL;
		close(audio_fd);
		audio_fd = 0;
		state = 0;		// idle
		return result;
	} else {
		fprintf(stderr, "record_oss::stop_record() - called while not recording\n");
		return false;
	}
}
