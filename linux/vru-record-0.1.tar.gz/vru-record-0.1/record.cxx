// record.cxx
// source file for record class
//
// Copyright (C) 2003 Eric Brombaugh
//
// Based heavily on Network.cxx from the Agenda VR3 Network app
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

#include <stdio.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>

#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Box.H>
#include <FL/fl_ask.h>
#include <FL/filename.H>
#include <FL/Fl_Menu_Item.H>
#include <FL/Fl_Slider.H>
#include <Fl/fl_draw.h>

#include <flpda/Widget_Factory.h>

#include "record.h"
#include "record_prefs.h"
#include "wav_funcs.h"
#include "record_oss.h"

// my custom label to get around the bugs in FL_SYMBOL_LABEL
#define SQCIR_LABEL FL_FREE_LABELTYPE

void sqcir_draw(const Fl_Label *label, int x, int y,
			int w, int h, Fl_Align align) {
	int ulx, uly;
	
	ulx = x + w/2 - 5;
	uly = y + h/2 - 5;
	
	fl_color(FL_BLACK);
	
	if(label->value[0] == 's') {
  			fl_rectf(ulx, uly, 10, 10);
	} else if(label->value[0] == 'c') {		
			fl_pie(ulx, uly, 10, 10, 0, 360);
	}
}

void sqcir_measure(const Fl_Label *label, int &w, int &h) {
	w = 10;
	h = 10;
}

// Idle callback for play
void record::play_idle(void* data) {
	record* r = static_cast<record*>(data);
	int pos;
	
	pos = r->oss->play_cb(r->oss);
	if(pos >= 0) {
		// update slider
		r->pos_slider->scrollvalue(pos, 0, 0, 100);
	} else if(pos == -2) {
		// done, reset buttons
		r->stop_cb(r->stop_button, r);
		r->pos_slider->scrollvalue(100, 0, 0, 100);
	}
}

// Idle callback for record
void record::record_idle(void* data) {
	record* r = static_cast<record*>(data);
	int pos;
	
	pos = r->oss->record_cb(r->oss);
	if(pos >= 0) {
		// update slider
		r->pos_slider->scrollvalue(pos, 0, 0, 100);
	} else if(pos == -2) {
		// done, reset buttons
		r->stop_cb(r->stop_button, r);
	}
}
	
// Stop button callback
void record::stop_cb(Fl_Widget*, void* data) {
	record* r = static_cast<record*>(data);
	
	// make sure we're playing/recording
	if(r->play_button->value() == 1) {
		// release the button
		r->play_button->value(0);
		
		// stop playing
		r->oss->stop_play();
		
		// remove the play idle function
		Fl::remove_idle(r->play_idle, r);
		
	} else if(r->record_button->value() == 1) {
		// configure the buttons
		r->record_button->value(0);
		
		// stop recording
		r->oss->stop_record();
		
		// remove the record idle function
		Fl::remove_idle(r->record_idle, r);
		
		// Refresh the display in case we've got a new file
		r->refresh();
	}
	
	// activate the widgets
	r->record_button->activate();
	r->play_button->activate();
	r->browser->activate();
}

// Play button callback
void record::play_cb(Fl_Widget*, void* data) {
	record* r = static_cast<record*>(data);
	char *filename, dirname[1024], fullname[1024];
	
	// make sure we're not already playing/recording
	if(r->play_button->value() == 1 ||
	   r->record_button->value() == 1)
		return;
	
	// is there a filename at the selected point?
	filename = (char *)r->browser->text(r->browser->value());
	if(filename) {	
		// expand the filename
		filename_expand(dirname, r->pref->dir);
		sprintf(fullname, "%s/%s", dirname, filename);
		
		// install the play idle function
		Fl::add_idle(r->play_idle, r);
		
		// start playing
		if(!r->oss->start_play(fullname)) {
			// remove the play idle function
			Fl::remove_idle(r->play_idle, r);
			
			fl_message("Couldn't play %s.\n", fullname);
			return;
		}
			
		// configure the buttons
		r->play_button->value(1);
		r->play_button->deactivate();
		r->record_button->deactivate();
		r->browser->deactivate();
	}
}

// Record button callback
void record::record_cb(Fl_Widget*, void* data) {
	record* r = static_cast<record*>(data);
	char dirname[1024], fullname[1024];
	int i;
	struct stat buf;
	FILE *testfile;

	// make sure we're not already playing/recording
	if(r->play_button->value() == 1 ||
	   r->record_button->value() == 1)
		return;
		
	// think up a unique filename
	filename_expand(dirname, r->pref->dir);	
	i = 1;
	while(1) {
		sprintf(fullname, "%s/Recording%d.wav", dirname, i++);
		if(stat(fullname, &buf))
			break;
	}
	
	// install the record idle function
	Fl::add_idle(r->record_idle, r);

	// start recording
	if(!r->oss->start_record(fullname, r->pref->bsize,
							r->pref->bits, r->pref->rate, r->pref->rgain)) {
		// remove the record idle function
		Fl::remove_idle(r->record_idle, r);
		
		fl_message("Couldnt' record %s.\n", fullname);
		return;
	}
	
	// configure the buttons
	r->record_button->value(1);
	r->play_button->deactivate();
	r->record_button->deactivate();
	r->browser->deactivate();
		
	r->refresh();
}

// Position slider callback
void record::pos_cb(Fl_Widget*, void* data) {
	printf("position\n");
}

// Done button callback
void record::close_cb(Fl_Widget*, void* data) {
	record* r = static_cast<record*>(data);
	if(r->window != 0)
		r->window->hide();
}

// Select browser callback
void record::browser_cb(Fl_Widget* widget, void* data) {
	record* r = static_cast<record*>(data);

	if(((Fl_Select_Browser*)widget)->text(((Fl_Select_Browser*)widget)->value()) == 0)
		return;
	
	// reset the slider
	r->pos_slider->scrollvalue(0, 0, 0, 100);
}

// Refresh the Select browser
bool record::refresh() {
	DIR *directory;
	struct dirent *entry;
	char dirname[1024], fullname[1024];
	
	// expand the filename
	filename_expand(dirname, pref->dir);
	
	if(!(directory = opendir(dirname))) {
		fl_message("Couldn't open directory %s\n", dirname);
		return false;
	}
	
	browser->clear();
	
	// check directory entries for valid WAV
	while((entry = readdir(directory))) {
		sprintf(fullname, "%s/%s", dirname, entry->d_name);
		if(chk_wavfile(fullname)) {
			browser->add(entry->d_name, this);
		}
	}
	
	closedir(directory);
	return true;
}

// Info menu item callback
void record::info_cb(Fl_Widget* widget, void* data) {
	record* r = static_cast<record*>(data);
	size_t bytes;
	int rate, fmt, chl, bps;
	char *filename, dirname[1024], fullname[1024];
	
	// is there a filename at the selected point?
	filename = (char *)r->browser->text(r->browser->value());
	if(filename) {	
		// expand the filename
		filename_expand(dirname, r->pref->dir);
		sprintf(fullname, "%s/%s", dirname, filename);
	
		// report the file info
		if(get_wavfmt(fullname, &bytes, &rate, &fmt, &chl, &bps)) {
			fl_message("%s\n Valid .WAV file size:%d\n bits:%d rate:%d Hz\n %s %d seconds",
				filename,
				bytes+44,
				fmt,
				rate,
				(chl == 1?"mono":"stereo"),
				bytes/bps/rate);
		} else {
			fl_message("%s\n is not a valid .WAV file\n", filename);
		}
	}
}

// Rename menu item callback
void record::rename_cb(Fl_Widget* widget, void* data) {
	record* r = static_cast<record*>(data);
	const char *oldname;
	char *newname, dirname[1024], old_fullname[1024], new_fullname[1024];
	
	// is there a filename at the selected point?
	oldname = r->browser->text(r->browser->value());
	if(oldname) {
		
		if((newname = (char *)fl_input("Rename File", oldname))) {
			filename_expand(dirname, r->pref->dir);
			sprintf(old_fullname, "%s/%s", dirname, oldname);
			sprintf(new_fullname, "%s/%s", dirname, newname);
			rename(old_fullname, new_fullname);
			r->refresh();
		} 
	}
}

// delete menu item callback
void record::delete_cb(Fl_Widget*, void* data) {
	record* r = static_cast<record*>(data);
	const char *oldname;
	char dirname[1024], fullname[1024];
	
	// is there a filename at the selected point?
	oldname = r->browser->text(r->browser->value());
	if(oldname) {
		if(fl_ask("Really delete %s?\n", oldname)) {
			filename_expand(dirname, r->pref->dir);
			sprintf(fullname, "%s/%s", dirname, oldname);
			unlink(fullname);
			r->refresh();
		} 
	}
}

// prefs menu item callback
void record::prefs_cb(Fl_Widget*, void* data) {
	record* r = static_cast<record*>(data);
	r->pref->dialog();
	r->refresh();
}

// about menu item callback
void record::about_cb(Fl_Widget*, void* data) {
	fl_message("Record\n Audio Playback and Record for the VR3\n (C) 2003 Eric Brombaugh");
}

// Main constructor for record - build the GUI and show it.
record::record() {
	int dummy;
	
	// install my custom labeltype
	Fl::set_labeltype(SQCIR_LABEL, sqcir_draw, sqcir_measure);
	
	window = WidgetFactory::new_window("record");

	// Record button
	record_button = new Fl_Button(0, 0, 20, 20, "R");
	record_button->down_box(FL_DOWN_BOX);
	record_button->callback((Fl_Callback*)record_cb, this);
	// this is what I really wanted but it crashes the VR3
	//record_button->label(FL_SYMBOL_LABEL, "@-5circle");
	// custom label type
	record_button->label(SQCIR_LABEL, "c");
	
	// Stop button
	stop_button = new Fl_Button(20, 0, 20, 20, "S");
	stop_button->down_box(FL_DOWN_BOX);
	stop_button->callback((Fl_Callback*)stop_cb, this);
	// this is what I really wanted
	//stop_button->label(FL_SYMBOL_LABEL, "@-5square");
	// this works and gets the idea across
	//stop_button->label(FL_SYMBOL_LABEL, "@-53+");
	// custom label type
	stop_button->label(SQCIR_LABEL, "s");
	
	// Play button    
	play_button = new Fl_Button(40, 0, 20, 20, "P");
	play_button->down_box(FL_DOWN_BOX);
	play_button->callback((Fl_Callback*)play_cb, this);
	play_button->label(FL_SYMBOL_LABEL, "@>");

	// Position slider
	pos_slider = new Fl_Slider(60, 0, Fl_Group::current()->w()-60, 20, "");
	pos_slider->type(FL_HOR_FILL_SLIDER);
	pos_slider->slider_size(1);
	pos_slider->scrollvalue(0, 0, 0, 100);
	pos_slider->callback((Fl_Callback*)pos_cb, this);
	
	// File Select Browser
 	browser = WidgetFactory::new_paged_select_browser(0, 20,
		Fl_Group::current()->w(), Fl_Group::current()->h()-20);
	browser->callback(browser_cb, this);
	Fl_Group::current()->resizable(browser);

	window->end();
		
	// Toolbar on bottom
	Fl_Dockable_Window* toolbar = WidgetFactory::new_toolbar();
	
	// Done button in toolbar
	Fl_Button* b = WidgetFactory::new_button("Done", close_cb, this);

	// Menu button in toolbar
	Fl_Menu_Button* m = Widget_Factory::new_menu_button("Menu");
	m->add("Info", 0, info_cb, this, 0);
	m->add("Rename", 0, rename_cb, this, 0);
	m->add("Delete", 0, delete_cb, this, FL_MENU_DIVIDER);
	m->add("Preferences", 0, prefs_cb, this, FL_MENU_DIVIDER);
	m->add("About", 0, about_cb, this, 0);
	// Empty box to fill space between menu button an pagekey
	Fl_Box* i = new Fl_Box(0, 0, 10, toolbar->h());
	
	// Pagekey for select widget
	Fl_Page_UpDown_Button* p = WidgetFactory::new_pagekey();
	i->size(toolbar->w() - b->w() * 2 - p->w(), i->h());

	browser->page_updown_button(p);
	
	toolbar->end();

	window->add_dockable(toolbar, 1);
	
	// load the prefs
	pref = new record_prefs;	
	
	// create an oss object
	oss = new record_oss("/dev/dsp");
	
	refresh();
	window->show();
}

record::~record() {
	delete oss;
	delete pref;
}
