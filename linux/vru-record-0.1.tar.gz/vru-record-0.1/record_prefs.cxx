// record_prefs.cxx
// source file for record_prefs functions
//
// Copyright (C) 2003 Eric Brombaugh
//
// Based heavily on Network.cxx from the Agenda VR3 Network app
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

#include <stdio.h>
#include <string.h>

#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Pack.H>
#include <FL/Fl_Round_Button.H>
#include <FL/Fl_Box.H>
#include <FL/filename.H>
#include <FL/fl_ask.h>
#include <flpda/Widget_Factory.h>
#include <flpda/pref.h>

#include "record_prefs.h"

// this returns the name of the prefs file
std::string record_preferences_file() {
	char temp[1024];
	filename_expand(temp, "~/.record_pref");
	return temp;
}

// this returns the default preferences
std::map<std::string, std::string> defaults() {
	std::map<std::string, std::string> pref;
	pref["dir"] = ".";
	pref["rate"] = "8000";
	pref["bits"] = "8";
	pref["rgain"] = "0";
	pref["bsize"] = "65536";
	return pref;
}

// Callback for dialog Done button
void record_prefs::done_cb(Fl_Widget* widget, void* data) {
	record_prefs *p = static_cast<record_prefs*>(data);
	char dirname[1024];
	
	if(p->d != 0) {
		filename_expand(dirname, p->dir_widget->value());
		if(filename_isdir(dirname)) {
			p->d->hide();
			p->result = 1;
		} else {
			fl_message("'%s' is not a valid directory. Please try again",
				dirname);
		}
	}
}

// Callback for dialog Cancel button
void record_prefs::cancel_cb(Fl_Widget* widget, void* data) {
	record_prefs *p = static_cast<record_prefs*>(data);
	if(p->d != 0) {
		p->d->hide();
		p->result = 0;
	}
}

// constructor loads prefs & creates prefs file if it doesn't exist
record_prefs::record_prefs() {
	std::map<std::string, std::string> pref_map;
	
	// load the prefs or default
	if(preference_read(record_preferences_file(), &pref_map) == 1) {
		fl_message("No prefs file found - using defaults to create one\n");
		pref_map = defaults();
		if(preference_write(record_preferences_file(), &pref_map)==1) {
			fl_message("Write default prefs failed\n");
		}
	}
	
	// copy from the map to our vars		
	strcpy(dir, pref_map["dir"].c_str());
	rate = atoi(pref_map["rate"].c_str());
	bits = atoi(pref_map["bits"].c_str());
	rgain = atoi(pref_map["rgain"].c_str());
	bsize = atoi(pref_map["bsize"].c_str());
}

// destructor saves prefs if they've changed
record_prefs::~record_prefs() {
	std::map<std::string, std::string> old_pref, curr_pref;
	char v[256];
	
	// build the current prefs map
	curr_pref["dir"] = dir;
	sprintf(v, "%d", rate);
	curr_pref["rate"] = v;
	sprintf(v, "%d", bits);
	curr_pref["bits"] = v;
	sprintf(v, "%d", rgain);
	curr_pref["rgain"] = v;
	sprintf(v, "%d", bsize);
	curr_pref["bsize"] = v;
	
	// load the old prefs map (or defaults)
	if(preference_read(record_preferences_file(), &old_pref) == 1) {
		old_pref = defaults();
	}
	
	// compare the maps
	if(old_pref["dir"] != curr_pref["dir"] ||
	   old_pref["rate"] != curr_pref["rate"] ||
	   old_pref["bits"] != curr_pref["bits"] ||
	   old_pref["rgain"] != curr_pref["rgain"] ||
	   old_pref["bsize"] != curr_pref["bsize"]) {
		if(preference_write(record_preferences_file(), &curr_pref) == 1) {
			// what to do if it fails?
			fl_message("~record_prefs: Write prefs failed\n");
		} 
	}
}

// open a diaglog to query for new preferences
bool record_prefs::dialog() {	
	int row[8];	

	//create a modal dialog window
	d = WidgetFactory::new_window("record preferences");
	d->set_modal();
	
	// precalculate the GUI object row spacing
	row[0] = Fl_Group::current()->y()+TOPBORDER;
	for(int i = 1; i < 8; i++) {
		row[i] = row[i-1] + WIDGET_HEIGHT + SPACING;
	}		
	
	// put a wrapper around everything
	Fl_Pack* p0 = new Fl_Pack(0, 0, Fl_Group::current()->w(), Fl_Group::current()->h(), 0);
 	p0->type(Fl_Pack::VERTICAL);
	
	// put in a text input widget for the directory
	Fl_Group* g0 = new Fl_Group(0, 0, Fl_Group::current()->w(), WIDGET_HEIGHT+2*SPACING, 0);
 	g0->box(FL_BORDER_FRAME);
	dir_widget = WidgetFactory::new_input(
		Fl_Group::current()->x()+LEFTBORDER+LABEL_WIDTH,
		row[0],
		Fl_Group::current()->w()-LEFTBORDER-RIGHTBORDER-LABEL_WIDTH,
		INPUT_HEIGHT,
		"Directory:");
	dir_widget->value(dir);
	g0->end();
	
	// a wrapper for the two horizontal sets of radio buttons
	Fl_Pack* p1 = new Fl_Pack(0, row[1], Fl_Group::current()->w(), 4*WIDGET_HEIGHT, 0);
 	p1->type(Fl_Pack::HORIZONTAL);

	// put in a 3-position radio button for the rate
	Fl_Pack* p2 = new Fl_Pack(0, 0, Fl_Group::current()->w()/2, 4*WIDGET_HEIGHT, "label");
 	p2->type(Fl_Pack::VERTICAL);
 	p2->box(FL_BORDER_FRAME);
 	Fl_Box *rbox = new Fl_Box(0, 0, Fl_Group::current()->w(), WIDGET_HEIGHT, "Sample Rate");
 	rbox->labelsize(WidgetFactory::textsize());
 	Fl_Round_Button *r8button = new Fl_Round_Button(0, WIDGET_HEIGHT,
 		Fl_Group::current()->w(), WIDGET_HEIGHT, "8k");
 	r8button->labelsize(WidgetFactory::textsize());
 	r8button->type(FL_RADIO_BUTTON);
 	Fl_Round_Button *r11button = new Fl_Round_Button(0, 2*WIDGET_HEIGHT,
 		Fl_Group::current()->w(), WIDGET_HEIGHT, "11k");
 	r11button->labelsize(WidgetFactory::textsize());
 	r11button->type(FL_RADIO_BUTTON);
 	Fl_Round_Button *r22button = new Fl_Round_Button(0, 3*WIDGET_HEIGHT,
 		Fl_Group::current()->w(), WIDGET_HEIGHT, "22k");
 	r22button->labelsize(WidgetFactory::textsize());
 	r22button->type(FL_RADIO_BUTTON);
 	switch(rate) {
 		default:
 			rate = 8000;
 		case 8000:
 			r8button->setonly();
 			break;
 		case 11025:
 			r11button->setonly();
 			break;
 		case 22050:
 			r22button->setonly();
 	}
	p2->end();

	// put in a 2-position radio button for the size
	Fl_Pack* p3 = new Fl_Pack(0, Fl_Group::current()->w()/2,
		Fl_Group::current()->w()/2, 4*WIDGET_HEIGHT, 0);
 	p3->type(Fl_Pack::VERTICAL);
 	p3->box(FL_BORDER_FRAME);
 	Fl_Box *wbox = new Fl_Box(0, 0, Fl_Group::current()->w(), WIDGET_HEIGHT, "Sample Size");
 	wbox->labelsize(WidgetFactory::textsize());
 	Fl_Round_Button *w8button = new Fl_Round_Button(0, WIDGET_HEIGHT,
 		Fl_Group::current()->w(), WIDGET_HEIGHT, "8 bit");
 	w8button->labelsize(WidgetFactory::textsize());
 	w8button->type(FL_RADIO_BUTTON);
 	Fl_Round_Button *w16button = new Fl_Round_Button(0, 2*WIDGET_HEIGHT,
 		Fl_Group::current()->w(), WIDGET_HEIGHT, "16 bit");
 	w16button->labelsize(WidgetFactory::textsize());
 	w16button->type(FL_RADIO_BUTTON);
 	switch(bits) {
 		default:
 			bits = 8;
 		case 8:
 			w8button->setonly();
 			break;
 		case 16:
 			w16button->setonly();
 	}
 	Fl_Box *webox = new Fl_Box(0, 2*WIDGET_HEIGHT, Fl_Group::current()->w(), WIDGET_HEIGHT, 0);
	p3->end();
	p1->end();
	
	// put in a 4-position radio button for the gain
	Fl_Pack* p4 = new Fl_Pack(0, 5*(WIDGET_HEIGHT+SPACING),
		Fl_Group::current()->w(), 2*WIDGET_HEIGHT, 0);
 	p4->type(Fl_Pack::VERTICAL);
 	p4->box(FL_BORDER_FRAME);
 	Fl_Box *gbox = new Fl_Box(0, 0, Fl_Group::current()->w(), WIDGET_HEIGHT, "Record Gain");
 	gbox->labelsize(WidgetFactory::textsize());
	Fl_Pack* p5 = new Fl_Pack(0, WIDGET_HEIGHT, Fl_Group::current()->w(), WIDGET_HEIGHT, 0);
 	p5->type(Fl_Pack::HORIZONTAL);
	Fl_Round_Button *g0button = new Fl_Round_Button(0, 0,
 		Fl_Group::current()->w()/4, WIDGET_HEIGHT, "0.5");
 	g0button->labelsize(WidgetFactory::textsize());
 	g0button->type(FL_RADIO_BUTTON);
 	Fl_Round_Button *g1button = new Fl_Round_Button(0, Fl_Group::current()->w()/4,
 		Fl_Group::current()->w()/4, WIDGET_HEIGHT, "1.0");
 	g1button->labelsize(WidgetFactory::textsize());
 	g1button->type(FL_RADIO_BUTTON);
 	Fl_Round_Button *g2button = new Fl_Round_Button(0, 2*Fl_Group::current()->w()/4,
 		Fl_Group::current()->w()/4, WIDGET_HEIGHT, "2.0");
 	g2button->labelsize(WidgetFactory::textsize());
 	g2button->type(FL_RADIO_BUTTON);
 	Fl_Round_Button *g3button = new Fl_Round_Button(0, 3*Fl_Group::current()->w()/4,
 		Fl_Group::current()->w()/4, WIDGET_HEIGHT, "4.0");
 	g3button->labelsize(WidgetFactory::textsize());
 	g3button->type(FL_RADIO_BUTTON);
 	p5->end();
 	switch(rgain) {
 		case -1:
 			g0button->setonly();
 			break;
 		default:
 			rgain = 0;
 		case 0:
 			g1button->setonly();
 			break;
 		case 1:
 			g2button->setonly();
 			break;
 		case 2:
 			g3button->setonly();
 	}
	p4->end();
	
	// put in a 4-position radio button for the buffer size
	Fl_Pack* p6 = new Fl_Pack(0, 7*(WIDGET_HEIGHT+SPACING),
		Fl_Group::current()->w(), 2*WIDGET_HEIGHT, 0);
 	p6->type(Fl_Pack::VERTICAL);
 	p6->box(FL_BORDER_FRAME);
 	Fl_Box *bbox = new Fl_Box(0, 0, Fl_Group::current()->w(), WIDGET_HEIGHT, "Buffer Size");
 	bbox->labelsize(WidgetFactory::textsize());
	Fl_Pack* p7 = new Fl_Pack(0, WIDGET_HEIGHT, Fl_Group::current()->w(), WIDGET_HEIGHT, 0);
 	p7->type(Fl_Pack::HORIZONTAL);
	Fl_Round_Button *b0button = new Fl_Round_Button(0, 0,
 		Fl_Group::current()->w()/4, WIDGET_HEIGHT, "64k");
 	b0button->labelsize(WidgetFactory::textsize());
 	b0button->type(FL_RADIO_BUTTON);
 	Fl_Round_Button *b1button = new Fl_Round_Button(0, Fl_Group::current()->w()/4,
 		Fl_Group::current()->w()/4, WIDGET_HEIGHT, "128k");
 	b1button->labelsize(WidgetFactory::textsize());
 	b1button->type(FL_RADIO_BUTTON);
 	Fl_Round_Button *b2button = new Fl_Round_Button(0, 2*Fl_Group::current()->w()/4,
 		Fl_Group::current()->w()/4, WIDGET_HEIGHT, "256k");
 	b2button->labelsize(WidgetFactory::textsize());
 	b2button->type(FL_RADIO_BUTTON);
 	Fl_Round_Button *b3button = new Fl_Round_Button(0, 3*Fl_Group::current()->w()/4,
 		Fl_Group::current()->w()/4, WIDGET_HEIGHT, "512k");
 	b3button->labelsize(WidgetFactory::textsize());
 	b3button->type(FL_RADIO_BUTTON);
 	p7->end();
 	switch(bsize) {
 		default:
 			bsize = (1<<16);
 		case (1<<16):
 			b0button->setonly();
 			break;
 		case (1<<17):
 			b1button->setonly();
 			break;
 		case (1<<18):
 			b2button->setonly();
 			break;
 		case (1<<19):
 			b3button->setonly();
 	}
	p6->end();
	// fill in the rest with a box
	Fl_Box* b1 = new Fl_Box(0, row[8], Fl_Group::current()->w(), 2*WIDGET_HEIGHT, 0);
	g0->end();
	d->end();
	
	// tack a toolbar on the bottom for the responses
	Fl_Dockable_Window* toolbar = WidgetFactory::new_toolbar();
	WidgetFactory::new_button("Done", done_cb, this);
	WidgetFactory::new_button("Cancel", cancel_cb, this);
	toolbar->end();
	d->add_dockable(toolbar, 1);
	
	// show the dialog and wait for it to disappear
	d->show();
	while(d->shown())
		Fl::wait();
	
	// delete the toolbar when the dialog closes
	if(!toolbar->parent())
		delete toolbar;
	
	// Update the preferences if the Done button was hit
	if(result) {
		strncpy(dir, dir_widget->value(), 256);
		if(r22button->value())
			rate = 22050;
		else if(r11button->value())
			rate = 11025;
		else
			rate = 8000;
		if(w16button->value())
			bits = 16;
		else
			bits = 8;
		if(g0button->value())
			rgain = -1;
		else if(g1button->value())
			rgain = 0;
		else if(g2button->value())
			rgain = 1;
		else
			rgain = 2;
		if(b0button->value())
			bsize = (1<<16);
		else if(b1button->value())
			bsize = (1<<17);
		else if(b2button->value())
			bsize = (1<<18);
		else
			bsize = (1<<19);
	}
	
	// remove the dialog
	delete d;
	
	return result ? true : false;
}
