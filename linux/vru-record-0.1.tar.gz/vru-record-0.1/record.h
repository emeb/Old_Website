// record.h
// Header file for record class
//
// Copyright (C) 2003 Eric Brombaugh
//
// Based heavily on Network.h from the Agenda VR3 Network app
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

#ifndef _RECORD_H_
#define _RECORD_H_

#include <flpda/Widget_Factory.h>

#include "record_prefs.h"
#include "record_oss.h"

class record {
private:
	Fl_App_Window* window;
	Fl_Button *record_button;
	Fl_Button *stop_button;
	Fl_Button *play_button;
	Fl_Paged_Select_Browser* browser;
	Fl_Slider *pos_slider;
	record_prefs *pref;
	record_oss *oss;
	
	static void play_idle(void* data);
	static void record_idle(void* data);	
	static void stop_cb(Fl_Widget*, void* data);
	static void play_cb(Fl_Widget*, void* data);
	static void record_cb(Fl_Widget*, void* data);
	static void pos_cb(Fl_Widget*, void* data);
	static void close_cb(Fl_Widget *widget, void *data);
	static void browser_cb(Fl_Widget* widget, void* data);
	bool refresh();
	static void info_cb(Fl_Widget *widget, void* data);
	static void rename_cb(Fl_Widget *widget, void* data);
	static void delete_cb(Fl_Widget *widget, void* data);
	static void prefs_cb(Fl_Widget *widget, void* data);
	static void about_cb(Fl_Widget *widget, void* data);
public:
	record();
	~record();
};

#endif
