// record_prefs.h
// Header file for record_prefs class
//
// Copyright (C) 2003 Eric Brombaugh
//
// Based heavily on Network.h from the Agenda VR3 Network app
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

#ifndef _RECORD_PREFS_H_
#define _RECORD_PREFS_H_

class record_prefs {
private:
	Fl_App_Window *d;		// dialog window
	Fl_Input *dir_widget;	// directory text input
 	int result;				// result from the dialog
 	
 	// some GUI layout constants from NetworkWidget.h
	static const int BORDER = 5;
	static const int TOPBORDER = BORDER;
	static const int LEFTBORDER = BORDER;
	static const int RIGHTBORDER = BORDER;
	static const int BOTTOMBORDER = BORDER;
	static const int WIDGET_HEIGHT = 18;
	static const int INPUT_HEIGHT = WIDGET_HEIGHT;
	static const int BUTTON_HEIGHT = WIDGET_HEIGHT;
	static const int SPACING = 4;
	static const int LABEL_WIDTH = 50;
	static const int DATA_FONT_SIZE = 12;

	static void done_cb(Fl_Widget *widget, void *data);
	static void cancel_cb(Fl_Widget *widget, void *data);
public:
	char dir[256];	// the directory where we store our files
	int rate;		// the record sample rate (8000/11025/22050)
	int bits;		// the record wordsize (8/16)
	int rgain;		// the record gain 2^(-1/0/1/2)
	int bsize;		// the record buffer size
	
	record_prefs();	// create the prefs object and load from disk
	~record_prefs();// save prefs to disk and destroy object
	bool dialog();	// query the user for preferences
};

#endif
