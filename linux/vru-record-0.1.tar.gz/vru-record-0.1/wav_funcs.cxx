// wav_funcs.cxx
// Source file for .WAV read/write functions
//
// Copyright (C) 2003 Eric Brombaugh
//
// Based heavily on Network.h from the Agenda VR3 Network app
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct waveformat 
{
  unsigned short formatTag;      /* format category  */
  unsigned short nChannels;      /* # of channels    */
  unsigned int nSamplesPerSec;   /* Sample rate      */
  unsigned int nAvgBytesPerSec;  /* for buffering    */
  unsigned short nBlockAlign;    /* Block Alignments */
  unsigned short nBitsPerSample; /* word size        */
};

// check a RIFF tag
int readtag(FILE *file, char *tag)
{
	char buff[5];

	/* get a 32-bit chunk */
	if(fread(buff, sizeof(char), 4, file) != 4)
		return -1;

	buff[4] = 0;

	return strncmp(buff, tag, 4);
}

// read in a .WAV header
bool read_wavhdr(FILE *infile, size_t *bytes, int *rate, int *fmt, int *chl, int *bps)
{
	unsigned long temp;
	struct waveformat wfmt;

	/* read the RIFF header*/
	if(readtag(infile, "RIFF"))
		return false;

	/* read a dummy - we won't key off of it */
	if(!fread(&temp, sizeof(long), 1, infile))
		return false;

	/* grab the next few tags */
	if(readtag(infile, "WAVE"))
		return false;
	if(readtag(infile, "fmt "))
		return false;

	/* This should be the size of a waveformat */
	if(!fread(&temp, sizeof(long), 1, infile))
		return false;
	if(temp != sizeof(struct waveformat))
		return false;

	/* grab the waveformat stucture */
	if(!fread(&wfmt, sizeof(struct waveformat), 1, infile))
		return false;
	if(wfmt.formatTag != 1)
		return false;

	/* parse the data & return */
	*chl = wfmt.nChannels;
	*rate = wfmt.nSamplesPerSec;
	*fmt = wfmt.nBitsPerSample;
	*bps = wfmt.nBlockAlign;

	/* check the data tag */
	if(readtag(infile, "data"))
		return false;
  
	/* get the size of the data */
	if(!fread(&temp, sizeof(long), 1, infile))
		return false;
	*bytes = temp;

	return true;
}

// get a .WAV header
bool get_wavfmt(const char *filename, size_t *bytes, int *rate, int *fmt, int *chl, int *bps)
{
	FILE *infile;
	bool result=false;
	
	if((infile = fopen(filename, "r"))) {
		if(read_wavhdr(infile, bytes, rate, fmt, chl, bps)) {
			result = true;
		}
		fclose(infile);
	}
	
	return result;
}

// check to see if a file is a .WAV
bool chk_wavfile(const char *filename)
{
	size_t bytes;
	int rate, fmt, chl, bps;
	
	return get_wavfmt(filename, &bytes, &rate, &fmt, &chl, &bps);
}

// write a RIFF tag
int writetag(FILE *file, char *tag)
{
	/* put a 32-bit chunk */
	if(fwrite(tag, sizeof(char), 4, file) != 4)
		return -1;

	return 0;
}

// write out a .WAV header
bool write_wavhdr(FILE *outfile, size_t bytes, int rate, int fmt, int chl)
{
	int result;
	unsigned long temp;
	struct waveformat wfmt;

	/* write the RIFF header*/
	result = writetag(outfile, "RIFF");
	temp = 4 + 4 + 4 + sizeof(struct waveformat) + 4 + 4 + (unsigned long)bytes;
	if(fwrite(&temp, 1, sizeof(long), outfile) != sizeof(long))
		result++;
	result += writetag(outfile, "WAVE");
	result += writetag(outfile, "fmt ");
	temp = sizeof(struct waveformat);
	if(fwrite(&temp, 1, sizeof(long), outfile) != sizeof(long))
		result++;
	wfmt.formatTag = 1;
	wfmt.nChannels = (unsigned long)chl;
	wfmt.nSamplesPerSec = (unsigned long)rate;
	wfmt.nAvgBytesPerSec = (unsigned long)((fmt/8)*rate*chl);
	wfmt.nBlockAlign = (unsigned long)((fmt/8)*chl);
	wfmt.nBitsPerSample = (unsigned long)fmt;
	if(fwrite(&wfmt, 1, sizeof(struct waveformat), outfile) != sizeof(struct waveformat))
		result++;
	result += writetag(outfile, "data");
 	temp = (unsigned long)bytes;
	if(fwrite(&temp, 1, sizeof(long), outfile) != sizeof(long))
		result++;
	
	if(result == 0)
		return true;
	else
		return false;
}
