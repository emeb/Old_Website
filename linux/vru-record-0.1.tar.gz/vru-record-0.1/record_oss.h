// record_oss.h
// header file for record OSS interface class
//
// Copyright (C) 2003 Eric Brombaugh
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

#ifndef _RECORD_OSS_H_
#define _RECORD_OSS_H_

#include <stdio.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>

class record_oss {
private:
	char devname[1024];		// the name of the audio device
	int audio_fd;			// the audio device filehandle
	
	int state;				// idle/play/record
	size_t bytes;			// total bytes (read or write)
	int rate;				// sample rate
	int fmt;				// format (bits)
	int chl;				// channels
	int bps;				// bytes per sample
	int frag_size;			// audio device fragment size
	int rgain;				// post-processing gain for record
	char *buffer;			// pointer to audio data buffer
	int used;				// bytes of total read/written
	char fullname[1024];	// fully rooted name of the audio I/O data file
	FILE *file;				// audio data filehandle
	
	int config_audio(char *devname, int mode, int fmt, int chl, int *rate, int *frag_size);
	
public:
	record_oss(char *device_name);
	~record_oss();
	bool start_play(char *name);
	static int play_cb(void *data);
	bool stop_play();
	bool start_record(char *name, int a_bytes, int a_fmt, int a_rate, int a_rgain);
	static int record_cb(void *data);
	bool stop_record();
};

#endif
