#!/usr/bin/perl -w
# zaurus2agenda.pl - convert Sharp Zaurus contact file to a GnomeCard file
# Copyright 2003-02-10 E.Brombaugh
# Licensed under the GPL

package Elinfo;

sub new
{
    my $class = shift;
    my $self = [0, undef, 0, 0, 1, {}, {}, {}];

    bless $self, $class;
}

package main;

# These should be above. But I can't seem to import
# them reliably without
# Elinfo being in a separate file.

sub CHARS () {3;}
sub EMPTY () {4;}
use English;
use XML::Parser;

my $file = shift;

die "Can't find file \"$file\""
  unless -f $file;

my $parser = new XML::Parser(ErrorContext => 2);
$parser->setHandlers(Start => \&start_handler,
		     Char  => \&char_handler);

$parser->parsefile($file);


sub start_handler
{
  my $p = shift;
  my $el = shift;
  my %contact;
    
  while (@_)
  {
    my $att = shift;
    my $value = shift;
    $contact{$att} = $value;
  }
  
  if($el eq 'Contact') {
    # dump it out
    print "\nBEGIN:VCARD\n";
    if (defined($contact{'FileAs'})) {
      print "FN:$contact{'FileAs'}\n";
    }
    if (defined($contact{'LastName'})) {
      print "N:$contact{'LastName'}";
    }
    if (defined($contact{'FirstName'})) {
      print ";$contact{'FirstName'}\n";
    } else {
      print "\n";
    }
    if(defined($contact{'BusinessStreet'}) || 
       defined($contact{'BusinessCity'}) ||
       defined($contact{'BusinessState'})||
       defined($contact{'BusinessZip'})) {
      print "ADR;POSTAL;PARCEL:;;";
      if(defined($contact{'BusinessStreet'})) {
        print "$contact{'BusinessStreet'};";
      } else {
        print ";";
      }
      if(defined($contact{'BusinessCity'})) {
        print "$contact{'BusinessCity'};";
      } else {
        print ";";
      }
      if(defined($contact{'BusinessState'})) {
        print "$contact{'BusinessState'};"
      } else {
        print ";";
      }
      if(defined($contact{'BusinessZip'})) {
        print "$contact{'BusinessZip'}\n";
      } else {
        print "\n";
      }
    }
    if(defined($contact{'HomeStreet'}) || 
       defined($contact{'HomeBusinessCity'}) ||
       defined($contact{'HomeBusinessState'})||
       defined($contact{'HomeBusinessZip'})) {
      print "ADR;POSTAL;PARCEL:;;";
      if(defined($contact{'HomeStreet'})) {
        print "$contact{'HomeStreet'};";
      } else {
        print ";";
      }
      if(defined($contact{'HomeCity'})) {
        print "$contact{'HomeCity'};";
      } else {
        print ";";
      }
      if(defined($contact{'HomeState'})) {
        print "$contact{'HomeState'};"
      } else {
        print ";";
      }
      if(defined($contact{'HomeZip'})) {
        print "$contact{'HomeZip'}\n";
      } else {
        print "\n";
      }
    }
    if (defined($contact{'BusinessPhone'})) {
      print "TEL;WORK:$contact{'BusinessPhone'}\n";
    }
    if (defined($contact{'BusinessFax'})) {
      print "TEL;WORK;FAX:$contact{'BusinessFax'}\n";
    }
    if (defined($contact{'HomePhone'})) {
      print "TEL;PREF;HOME:$contact{'HomePhone'}\n";
    }
    if (defined($contact{'HomeMobile'})) {
      print "TEL;CELL:$contact{'HomeMobile'}\n";
    }
    if (defined($contact{'Company'})) {
      print "ORG:$contact{'Company'}\n";
    }
    if (defined($contact{'Emails'})) {
      print "EMAIL;INTERNET:$contact{'Emails'}\n";
    }
    print "CATEGORIES;QUOTED-PRINTABLE:Others\n";
    if (defined($contact{'Uid'})) {
      print "UID:Contacts$contact{'Uid'}\n";
    }
    print "END:VCARD\n";
  
}  # End start_handler

sub char_handler
{
    my ($p, $data) = @_;

    $inf->[EMPTY] = 0;
    if ($data =~ /\S/)
    {
	$inf->[CHARS] += length($data);
    }
}  # End char_handler
}