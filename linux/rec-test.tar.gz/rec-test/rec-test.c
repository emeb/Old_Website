/* rec-test.c : try to read the OSS audio device */
/* 12-03-02 : E. Brombaugh                       */

#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>

#define BUF_SIZE    4096

int audio_fd;  
unsigned char audio_buffer[BUF_SIZE], *audio_bufptr;

int main(int argc, char **argv)
{
  char *inname = "/dev/dsp";	// output filename
  int len, i, j, reqsize, count, fmt;
  
  /* get args or default */
  if(argc > 1)
    reqsize = atoi(argv[1]);
  else
    reqsize = BUF_SIZE;
    
  if(argc > 2)
    switch(atoi(argv[2]))
    {
      case 8:
        fmt = AFMT_U8;
        break;
            
      case 16:
        fmt = AFMT_S16_LE;
        break;
        
      default:
        fmt = 8;
    }
  else
    fmt = 8;
   
  /* open up the sound device for input */
  if((audio_fd = open(inname, O_RDONLY, 0)) == -1)  
  {
    fprintf(stderr, "Can't open %s for input!\n", inname);
    exit(-1);
  }
  
  /* set to desired format */
  if(ioctl(audio_fd, SNDCTL_DSP_SETFMT, &fmt)==-1)  
  {
    /* Fatal error */  
    perror("SNDCTL_DSP_SETFMT");  
    exit(-1);  
  }

  audio_bufptr = audio_buffer;
  count = BUF_SIZE;
  while(count > 0)
  {
    fprintf(stdout, "count %d\n", count);
    if ((len = read(audio_fd, audio_bufptr, reqsize)) == -1)  
    {  
      perror("audio read");  
      exit(-1);  
    }
    count -= len;
    audio_bufptr += len;
  }
  
  // wait a bit
  usleep(250);
  
  // close 'er down
  close(audio_fd);
      
  if(len != reqsize)
    fprintf(stdout, "Buffer length mismatch (ask %d, got %d)\n", len, reqsize);
  else
    fprintf(stdout, "Buffer length OK\n");
    
  for(i=0;i<BUF_SIZE;i+=16)
  {
    fprintf(stdout, "% 4x : ", i);
    switch(fmt)
    {
      case AFMT_U8:
        for(j=0;j<16;j++)
          fprintf(stdout, "% 2x ", audio_buffer[i+j]);
        break;
        
      case AFMT_S16_LE:
        for(j=0;j<16;j+=2)
          fprintf(stdout, "% 4x ", (short)((short)audio_buffer[i+j]+((short)audio_buffer[i+j+1]<<8))&0xffff);
        break;
    }
    fprintf(stdout, "\n");
  }
}

