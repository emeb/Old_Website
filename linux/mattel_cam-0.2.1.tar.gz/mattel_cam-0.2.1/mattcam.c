/* 
 *  mattcam.c - mattel camera I/O routines
 *  derived from the linux serial i/o howto
 *  08-19-00 E. Brombaugh
 *  09-02-00 E. Brombaugh - added grab result capability, verbose mode,
 *                          sync I/O flag
 *
 * Copyright (C) 2000, 2003 Eric Brombaugh
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

/*
 * TODO - Figure out why receive routine fails so often.
 *      - Combine redundant code into common routine.
 *      - Add more camera commands.
 */
 
 
#include <stdio.h>
#include "mattcam.h"

int init_mc(mc_struct *mcs, char *serdev, int v)
{
  /* save the device name */
  strncpy(mcs->serdev, serdev, 256);
  
  /* set verbose flag */
  mcs->v = v;
  
  /* open the Serial device */
  mcs->fd = open(serdev, O_RDWR | O_NOCTTY | O_SYNC );
  if(mcs->fd <0)
  {
    if(mcs->v)
    {
      fprintf(stderr, "Couldn't open: ");
      perror(mcs->serdev);
    }
    return ERR_COMM;
  }

  /* save current port settings */
  tcgetattr(mcs->fd, &mcs->oldtio);

  /* init the new settings */
  bzero(&mcs->newtio, sizeof(mcs->newtio));
  mcs->newtio.c_cflag = BAUDRATE | CS8 | CLOCAL | CREAD;
  mcs->newtio.c_iflag = 0;
  mcs->newtio.c_lflag = 0;
  mcs->newtio.c_oflag = 0;

  /* set input mode (non-canonical, no echo,...) */
  mcs->newtio.c_lflag = 0;

  mcs->newtio.c_cc[VTIME] = 10;   /* inter-character timer: 1 sec */
  mcs->newtio.c_cc[VMIN]  = 0;    /* blocking read til 1 chars received,
                                   * or timeout
                                   */

  tcflush(mcs->fd, TCIFLUSH);
  tcsetattr(mcs->fd, TCSANOW, &mcs->newtio);
  
  return 0;
}

void close_mc(mc_struct *mcs)
{
  /* restore old settings */
  tcsetattr(mcs->fd, TCSANOW, &mcs->oldtio);
  
  /* close the Serial device */
  close(mcs->fd);
}

int mc_send_cmd(mc_struct *mcs, char cmd, char data)
{
  char txbuf[5], rxbuf[10];
  int res;
  int retries = 0;
  int count;
  int result;
  
  /* AUGH! A _Goto_!  EEEEeeewww! */
  retry:
  count = 0;
  
  /* flush IO */
  tcflush(mcs->fd, TCIOFLUSH);

  /* set up send command */
  txbuf[0] = ACK;
  txbuf[1] = STX;
  txbuf[2] = cmd;
  txbuf[3] = data;
  txbuf[4] = ETX;
  
  /* send it w/o the ACK in front*/
  res = write(mcs->fd, &txbuf[1], 4);
  if(res <0)
  {
    if(mcs->v)
    {
      fprintf(stderr, "send_cmd: write: ");
      perror(mcs->serdev);
    }
    return ERR_COMM;
  }
  
  if(res != 4)
  {
    if(mcs->v)
      fprintf(stderr, "send_cmd: didn't send 4 bytes\n");
    return ERR_COMM;
  }
  
  /* change the expected command to lower case */
  txbuf[2] |= 0x20;
  
  /* change the expected data to 0 */
  txbuf[3] = 0x00;

  /* receive the reply */
  while(count < 5)
  {
    res = read(mcs->fd, rxbuf, 1);
    if(res < 0)
    {
      if(mcs->v)
      {
        fprintf(stderr, "send_cmd: read: ");
        perror(mcs->serdev);
      }
      return ERR_COMM;
    }
    
    if(res != 1)
    {
      if(mcs->v)
        fprintf(stderr, "send_cmd: didn't receive 1 byte\n");
      return ERR_COMM;
    }
    
    /* did the camera report an error? */
    if((count == 2) && (rxbuf[0] == 0x21))
    {
      if(retries++ < 100)
        goto retry;
      else
      {
        if(mcs->v)
          fprintf(stderr, "send_cmd: command %c: max retries exceeded.\n", cmd);
        return ERR_COMM;
      }
    }
    
    /* return result */
    if(count == 3)
    {
      result = rxbuf[0];
      count++;
    }
    else if(rxbuf[0] != txbuf[count++])
    {
      if(mcs->v)
        fprintf(stderr, "send_cmd: unexpected receive byte %d: 0x%2.2x\n", count-1, rxbuf[0]);
      return ERR_COMM;
    }
  }
  
  return result;
}     

int mc_recv_pic(mc_struct *mcs, unsigned char *databuf)
{
  char txbuf[7], rxbuf[10];
  int res;
  int count, bytes;
  int retries = 0;
  
  /* AUGH! A _Goto_!  EEEEeeewww! */
  retry:
  count = 0;

  /* flush IO */
  tcflush(mcs->fd, TCIOFLUSH);

  /* set up send command */
  txbuf[0] = ACK;
  txbuf[1] = STX;
  txbuf[2] = UPLD_IMAGE;
  txbuf[3] = 0;
  txbuf[4] = ETX;
  
  /* send it w/o the ACK in front*/
  res = write(mcs->fd, &txbuf[1], 4);
  if(res <0)
  {
    if(mcs->v)
    {
      fprintf(stderr, "recv_pic: write: ");
      perror(mcs->serdev);
    }
    return ERR_COMM;
  }
  
  if(res != 4)
  {
    if(mcs->v)
      fprintf(stderr, "recv_pic: didn't send 4 bytes\n");
    return -1;
  }
  
  /* change the expected command to lower case */
  txbuf[2] |= 0x20;
  /* tack on the expected parameters */
  txbuf[3] = 164;
  txbuf[4] = 2;
  txbuf[5] = 124;
  txbuf[6] = 16;
  
  /* receive the header */
  while(count < 7)
  {
    res = read(mcs->fd, rxbuf, 1);
    if(res < 0)
    {
      if(mcs->v)      
      {
        fprintf(stderr, "recv_pic: read: ");
        perror(mcs->serdev);
      }
      return ERR_COMM;
    }
    
    if(res != 1)
    {
      if(mcs->v)      
        fprintf(stderr, "recv_pic: didn't receive 1 byte (HEADER)\n");
      return ERR_COMM;
    }
    
    // did the camera report an error?
    if((count == 2) && (rxbuf[0] == 0x21))
    {
      if(retries++ < 100)
        goto retry;
      else
      {
        if(mcs->v)      
          fprintf(stderr, "recv_pic: max retries exceeded.\n");
        return ERR_COMM;
      }
    }
    
    if(rxbuf[0] != txbuf[count++])
    {
      if(mcs->v)      
        fprintf(stderr, "recv_pic: unexpected receive byte %d: 0x%2.2x\n", count-1, rxbuf[0]);
      return ERR_COMM;
    }
  }
  
  /* receive the data */
  count = 0;
  while(count < 20680)
  {
    bytes = 1;
    res = read(mcs->fd, &databuf[count], bytes);
    if(res < 0)
    {
      if(mcs->v)
      {
        fprintf(stderr, "recv_pic: read: ");
        perror(mcs->serdev);
      }
      return ERR_COMM;
    }
    
    if(res != bytes)
    {
      if(mcs->v)
        fprintf(stderr, "recv_pic: didn't receive %d bytes data @ count %d\n", bytes, count);
      return ERR_COMM;
    }
    
    count += bytes;
  }
  
  /* get the final ETX */
  res = read(mcs->fd, rxbuf, 1);
  if(res < 0)
  {
    if(mcs->v)
    {
      fprintf(stderr, "recv_pic: read: ");
      perror(mcs->serdev);
    }
    return ERR_COMM;
  }
    
  if(res != 1)
  {
    if(mcs->v)
      fprintf(stderr, "recv_pic: didn't receive 1 byte (ETX)\n");
    return ERR_COMM;
  }

  if(rxbuf[0] != ETX)
  {
    if(mcs->v)
      fprintf(stderr, "recv_pic: didn't receive ETX\n");
    return ERR_COMM;
  }
  
  return 0;
}

