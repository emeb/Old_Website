/* 
 *  mattcam.h - mattel camera I/O routines
 *  derived from the linux serial i/o howto
 *  08-19-00 E. Brombaugh
 *  09-02-00 E. Brombaugh - added grab result capability, verbose mode,
 *                          sync/nonblock I/O
 *
 * Copyright (C) 2000, 2003 Eric Brombaugh
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
#ifndef _matcam_
#define _matcam_

#include <termios.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/* various things we need to know */
#define BAUDRATE B57600
#define _POSIX_SOURCE 1 /* POSIX compliant source */
#define FALSE 0
#define TRUE 1
#define STX 0x02
#define ETX 0x03
#define ACK 0x06
#define NAK 0x15
#define ADDR_IMAGE 'A'
#define GRAB_IMAGE 'G'
#define UPLD_IMAGE 'U'
#define GRAB_RESULT 'Y'
#define ERR_COMM 1
#define ERR_EXPOSURE 0xffffff80
#define ERR_MEMORY 0xffffff81

/* the mattel camera control structure */
typedef struct
{
  char serdev[256];              /* the name of the serial device */
  int fd;                        /* the serial device filehandle */
  struct termios oldtio, newtio; /* info about the device */
  int v;                         /* allow verbose error reporting */
} mc_struct;

int init_mc(mc_struct *mcs, char *serdev, int v);
void close_mc(mc_struct *mcs);
int mc_send_cmd(mc_struct *mcs, char cmd, char data);
int mc_recv_pic(mc_struct *mcs, unsigned char *databuf);

#endif

