/*
 *  bmp.h - info needed to create BMP graphics files
 *  based on info from the graphics file format website
 *  08-06-00 E. Brombaugh
 *
 * Copyright (C) 2000, 2003 Eric Brombaugh
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
/*
 *  this doesn't support the full capabilities - it's only for simple 24-bit RGB
 *  which requires the following structures/data:
 *  BITMAPFILEHEADER bmfh;				// the file header
 *  BITMAPINFOHEADER bmih;				// the info header
 *  BYTE             aBitmapBits[];		// the data
 */
 
#ifndef _bmp_
#define _bmp_

/* damn MS types */
typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned int DWORD;
typedef int LONG;

/* BMP definitions */
#define BI_RGB 0

typedef struct tagBITMAPFILEHEADER {    /* bmfh */
  WORD    bfType __attribute__ ((packed));		/* type of file. (0x4d42).     */
  DWORD   bfSize __attribute__ ((packed));		/* size of the file, in bytes. */ 
  WORD    bfReserved1 __attribute__ ((packed));	/* Reserved; set to zero.      */
  WORD    bfReserved2 __attribute__ ((packed));	/* Reserved; set to zero.      */
  DWORD   bfOffBits __attribute__ ((packed));	/* byte offset of bitmap data  */
} BITMAPFILEHEADER;

typedef struct tagBITMAPINFOHEADER {    /* bmih */
  DWORD   biSize __attribute__ ((packed));		/* size in bytes (40)*/
  LONG    biWidth __attribute__ ((packed));		/* width of the bitmap in pixels */ 
  LONG    biHeight __attribute__ ((packed));	/* height of the bitmap in pixels*/ 
  WORD    biPlanes __attribute__ ((packed));	/* number of bitplanes. set to 1 */
  WORD    biBitCount __attribute__ ((packed));	/* bits per pixel. 1, 4, 8, or 24*/
  DWORD   biCompression __attribute__ ((packed));	/* BI_RGB, BI_RLE8, BI_RLE4  */
  DWORD   biSizeImage __attribute__ ((packed));	/* size in bytes of the image    */
  LONG    biXPelsPerMeter __attribute__ ((packed));	/* horizontal resolution     */
  LONG    biYPelsPerMeter __attribute__ ((packed));	/* vertical resolution       */
  DWORD   biClrUsed __attribute__ ((packed));	/* color indexes in the table    */
										/* 0 for 24-bit                  */
  DWORD   biClrImportant __attribute__ ((packed));	/*  0                        */
} BITMAPINFOHEADER;


/* my stuff */
typedef struct tagbmp_struct {
  BITMAPFILEHEADER bmfh;				/* the file header */
  BITMAPINFOHEADER bmih;				/* the info header */
  BYTE             *bmdata;				/* the data        */
  FILE             *bmoutfile;			/* the output file */
  int              size;				/* size of data    */
  int              next_scanline;		/* index to next scanline    */
  int              rowsize;				/* bytes per row   */
  BYTE             *bmptr;				/* next byte       */
} bmp_struct;

/* to simulate the jpeglib semantics */
typedef BYTE BMPSAMPLE;
typedef BMPSAMPLE *BMPSAMPROW;
typedef BMPSAMPROW *BMPARRAY;

/* prototypes */
int bmp24_init(bmp_struct *bmps, FILE *bmoutfile, int width, int height);
int bmp24_write_scanlines(bmp_struct *bmps, BMPARRAY scanlines, int count);
int bmp24_finish(bmp_struct *bmps);

#endif

