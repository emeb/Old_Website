/*
 *  gfxfile.c - write graphics files
 *  08-20-00 E. Brombaugh
 *  09-02-00 E. Brombaugh - fixed no filetype segfault
 *  02-15-03 E. Brombaugh - made image size variable
 *
 * Copyright (C) 2000, 2003 Eric Brombaugh
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdio.h>
#include "gfxfile.h"

int write_gfx(char *outname, image *im, int quality)
{
  int out = 0;
  FILE *outfile;
  
  /* open the output file */
  if(!(outfile = fopen(outname, "wb")))
  {
    fprintf(stderr, "Couldn't open %s for output.\n", outname);
    exit(-1);
  }
  
  /* figure out what type of file it's going to be */
  switch(gfxtype(outname))
  {
    case 0:
      /* write data as a jpg */
      /* fprintf(stderr, "writing jpg file %s\n", outname); */
      write_jpeg(outfile, im, quality);
      break;
    
    case 1:
      /* write data as a BMP */
      /* fprintf(stderr, "writing bmp file %s\n", outname); */
      write_bmp(outfile, im);
      break;
    
    case 2:
      /* write data as a PPM */
      /* fprintf(stderr, "writing ppm file %s\n", outname); */
      write_ppm(outfile, im);
      break;
    
    default:
      /* unknown file type */
      fprintf(stderr, "Unknown file type - use only .jpg, .bmp or .ppm\n");
      out = -1;
      break;
  }
  
  fclose(outfile);
  
  return out;
}

int gfxtype(char *name)
{
  char *typ;
  
  /* find period - default to jpeg if none */
  if((typ = strchr(name, '.')) == NULL)
    return 0;
    
  /* point to start of filetype */
  typ ++;
  
  if(strncmp(typ, "jpg", 3) == 0)
    return0;
  else if(strncmp(typ, "bmp", 3) == 0)
    return 1;
  else if(strncmp(typ, "ppm", 3) == 0)
    return 2;
  else
    return -1;
}

void write_jpeg(FILE *outfile, image *im, int quality)
{
  int y;
  JSAMPROW *lines;
  struct jpeg_compress_struct cinfo;
  struct jpeg_error_mgr jerr;
  
  /* allocate memory for the samprows */
  if(!(lines = malloc((im->ys)*sizeof(JSAMPROW))))
  {
  	fprintf(stderr, "Couldn't allocate mem for JPG write\n");
  	exit(-1);
  }
  	
  /* set up the pointers */
  for(y=0;y<im->ys;y++)
    lines[y] = (JSAMPROW)&(im->scanlines[y*im->xs*3]);
  
  /* init the jpeg stuff */
  cinfo.err = jpeg_std_error(&jerr);
  jpeg_create_compress(&cinfo);
  jpeg_stdio_dest(&cinfo, outfile);
  
  cinfo.image_width = im->xs; 	/* image width and height, in pixels */
  cinfo.image_height = im->ys;
  cinfo.input_components = 3;	/* # of color components per pixel */
  cinfo.in_color_space = JCS_RGB; /* colorspace of input image */
  jpeg_set_defaults(&cinfo);
  
  /* set quality */
  jpeg_set_quality (&cinfo, quality, FALSE);
  
  /* process the jpeg data */
  jpeg_start_compress(&cinfo, TRUE);
  
  while (cinfo.next_scanline < cinfo.image_height)
  {
    jpeg_write_scanlines(&cinfo, &lines[cinfo.next_scanline], 1);
  }

  /* finish up */
  jpeg_finish_compress(&cinfo);
  jpeg_destroy_compress(&cinfo);
  free(lines);
}

void write_bmp(FILE *outfile, image *im)
{
  int y;
  BMPSAMPROW *lines;
  bmp_struct cinfo;  
  
  /* allocate memory for the samprows */
  if(!(lines = malloc(im->ys*sizeof(BMPSAMPROW))))
  {
  	fprintf(stderr, "Couldn't allocate mem for BMP write\n");
  	exit(-1);
  }
  	
  /* set up the pointers */
  for(y=0;y<im->ys;y++)
    lines[y] = (BMPSAMPROW)&(im->scanlines[y*im->xs*3]);
   
  /* init the BMP stuff */
  if(bmp24_init(&cinfo, outfile, im->xs, im->ys))
  {
    fprintf(stderr, "Trouble initializing the BMP file.\n");
    exit(-1);
  }
  
  /* process the jpeg data */
  while (cinfo.next_scanline < cinfo.bmih.biHeight)
  {
    bmp24_write_scanlines(&cinfo, &lines[cinfo.next_scanline], 1);
  }

  /* finish up */
  bmp24_finish(&cinfo);
  
  free(lines);
}

void write_ppm(FILE *outfile, image *im)
{
  int y;
  
  /* write the header */
  fprintf(outfile, "P6\n");
  fprintf(outfile, "# Created by nicksnap\n");
  fprintf(outfile, "%d\n%d\n255\n",im->xs, im->ys);
  
  /* write the data */
  for(y=0;y<im->ys;y++)
  {
    fwrite((im->scanlines+y*im->xs*3), sizeof(unsigned char), (3*im->xs), outfile);
  }
}



