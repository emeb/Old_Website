/*
 *  image.c - operations on the image structure
 *  02-15-03 E. Brombaugh
 *
 * Copyright (C) 2003 Eric Brombaugh
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdlib.h>
#include <string.h>
#include "image.h"
#include "font_8x8.h"

#define ADDRS(x, y, w) (3*((x)+(w*(y))))

/* create a new image */
image *create_image(int xs, int ys)
{
  image *im;
  
  /* create an image on the heap */
  if(!(im = malloc(sizeof(image))))
    return NULL;
      
  /* set it up */
  im->xs = xs;
  im->ys = ys;
  
  /* allocate space for the scanlines */
  if(!(im->scanlines = malloc(xs*ys*3*sizeof(unsigned char))))
  {
    free(im);
    return NULL;
  }
  
  return im;
}

/* crop an image to a new image */
image *crop_image(image *src, int cx, int cy, int cw, int ch)
{
  image *im;
  int x, y;
  char *d, *s;
  
  /* create a new image to crop into */
  if(!(im = create_image(cw, ch)))
    return NULL;
  
  /* copy scanlines from source to new image */
  for(y=0;y<ch;y++)
  {
    d = im->scanlines + im->xs*y*3;
    s = src->scanlines + src->xs*(y+cy)*3 + cx*3;
    memcpy(d, s, cw*3);
  }

  return im;
}


#define CHAR_HEIGHT  8
#define CHAR_WIDTH   8
#define CHAR_START   1

/* put text into image */
int text_image(image *im, int tx, int ty, char *text)
{
  unsigned char *ptr;
  int i,x,y,f,len, max;
  
  /* make sure that text position is within image */
  if((tx > im->xs) || (ty > im->ys) || (tx < 0) || (ty-CHAR_HEIGHT < 0))
    return -1;
  
  /* text length to avoid overflow */
  max = (im->xs - tx)/CHAR_WIDTH;
  len = strlen(text);
  len = len > max ? max : len;
  
  for (y=0;y<CHAR_HEIGHT;y++)
  {
    ptr = im->scanlines + ADDRS(tx,ty-CHAR_HEIGHT+y,im->xs);
    for (x = 0; x < len; x++)
    {
      f = fontdata[text[x] * CHAR_HEIGHT + y];
      for(i = CHAR_WIDTH-1; i >= 0; i--)
      {
        if (f & (CHAR_START << i))
        {
          /* bright pixel */
          ptr[0] = ptr[0]/4 + 192;
          ptr[1] = ptr[1]/4 + 192;
          ptr[2] = ptr[2]/4 + 192;
        }
        else
        {
          /* dim pixel */
          ptr[0] = ptr[0]/4 + 32;
          ptr[1] = ptr[1]/4 + 32;
          ptr[2] = ptr[2]/4 + 32;
        }
        ptr += 3;
      }
    }
  }
  
  return 0;
}

/* saturate signed fp to unsigned int */
int fsat(double a)
{
  int out;
  out = a<0 ? 0 : a;
  return out>255 ? 255 : out;
}

/* unsharp mask operation */
image *unsharp_mask(image *im, double C, int r)
{
  image *unsharp;
  int x, y, color, npix, u, j, n, i, m;
  double U;
  
  /* create an image for the result */
  if(!(unsharp = create_image(im->xs, im->ys)))
    return NULL;
  
  /* run through the data y:x:c */
  for(y=0;y<im->ys;y++)
  {
    for(x=0;x<im->xs;x++)
    {
      for(color=0;color<3;color++)
      {
        /* initialize pixel counter */
        npix = 0;
        
        /* compute local average */
        u=0;
        for(j=-r;j<=r;j++)
        {
          /* compute vertical pixel offset */
          n = y+j;
          
          /* skip if off image */
          if((n>=0)&&(n<im->ys))
          {
            for(i=-r;i<=r;i++)
            {
              /* compute horizontal pixel offset */
              m = x+i;
              
              /* skip if off image */
              if((m>=0)&&(m<im->xs))
              {
                u += im->scanlines[ADDRS(x+i,y+j,im->xs)+color];
                npix++;
              }
            }
          }
        }
        
        /* compute unsharp mask */
        U = C*(double)im->scanlines[ADDRS(x,y,im->xs)+color] - 
           (C - 1.0) * ((double)u/(double)npix);
        
        /* save to new image */
        unsharp->scanlines[ADDRS(x,y,unsharp->xs)+color] = fsat(U+0.5);
      }
    }
  }
  
  return unsharp;
}

/* smooth to 2x image */
image *smooth_image(image *im)
{
  image *out;
  int x, y, c, i, j, sum;
  
  /* create an image for the result */
  if(!(out = create_image(im->xs*2, im->ys*2)))
    return NULL;

  /* copy small->large with zero stuffing */
  for(y=0;y<im->ys;y++)
  {
    for(x=0;x<im->xs;x++)
    {
      for(c=0;c<3;c++)
      {
        /* this point isn't interpolated */
        out->scanlines[ADDRS(x*2,y*2,out->xs)+c] =
            im->scanlines[ADDRS(x,y,im->xs)+c];
        
        /* watch out for edge conditions on the new ones */
        if(x<im->xs-1)
          out->scanlines[ADDRS(x*2+1,y*2,out->xs)+c] =
              (im->scanlines[ADDRS(x,y,im->xs)+c] +
               im->scanlines[ADDRS(x+1,y,im->xs)+c])/2;
        else
          out->scanlines[ADDRS(x*2+1,y*2,out->xs)+c] =
               im->scanlines[ADDRS(x,y,im->xs)+c];
               
        if(y<im->ys-1)
          out->scanlines[ADDRS(x*2,y*2+1,out->xs)+c] =
              (im->scanlines[ADDRS(x,y,im->xs)+c] +
               im->scanlines[ADDRS(x,y+1,im->xs)+c])/2;
        else
          out->scanlines[ADDRS(x*2,y*2+1,out->xs)+c] =
               im->scanlines[ADDRS(x,y,im->xs)+c];
  
        if((x<im->xs-1) && (y<im->ys-1))
          out->scanlines[ADDRS(x*2+1,y*2+1,out->xs)+c] =
              (im->scanlines[ADDRS(x,y,im->xs)+c] +
               im->scanlines[ADDRS(x+1,y,im->xs)+c] +
               im->scanlines[ADDRS(x,y+1,im->xs)+c] +
               im->scanlines[ADDRS(x+1,y+1,im->xs)+c])/4;
        else
          out->scanlines[ADDRS(x*2+1,y*2+1,out->xs)+c] =
               im->scanlines[ADDRS(x,y,im->xs)+c];
        
      }
    }
  }
  
  return out;
}

/* interpolate to a large image */
image *interp_image(image *im, int m)
{
  image *out;
  int x, y, c, d, i, j;
  double d0, d1, d2, d3, s, e;
  
  /* special case - use smooth_image() if m == 2 */
  if(m==2)
    return smooth_image(im);
  
  /* create an image for the result */
  if(!(out = create_image(im->xs*m, im->ys*m)))
    return NULL;

  /* run through the data y:x:c */
  for(y=0;y<im->ys;y++)
  {
    for(x=0;x<im->xs;x++)
    {
      for(c=0;c<3;c++)
      {
        /* get the corners for linear interp */
        d0 = im->scanlines[ADDRS(x,y,im->xs)+c];
        
        /* at max x edge we extrapolate */
        if(x<im->xs-1)
          d1 = im->scanlines[ADDRS(x+1,y,im->xs)+c];
        else
          d1 = d0 + d0 - im->scanlines[ADDRS(x-1,y,im->xs)+c];
        
        /* at max y edge we extrapolate */
        if(y<im->ys-1)
          d2 = im->scanlines[ADDRS(x,y+1,im->xs)+c];
        else
          d2 = d0 - d0 + im->scanlines[ADDRS(x,y-1,im->xs)+c];
        
        /* at max x/y edge we extrapolate */
        if((x<im->xs-1) && (y<im->ys-1))
          d3 = im->scanlines[ADDRS(x+1,y+1,im->xs)+c];
        else if((x==im->xs-1) && (y<im->ys-1))
          d3 = d2 - d2 + im->scanlines[ADDRS(x-1,y+1,im->xs)+c];
        else if((x<im->xs-1) && (y==im->ys-1))
          d3 = d1 - d1 + im->scanlines[ADDRS(x+1,y-1,im->xs)+c];
        else
          d3 = d0 - d0 + im->scanlines[ADDRS(x-1,y-1,im->xs)+c];
        
        /* linear interpolation across the four corners */
        for(i=0;i<m;i++)
        {
          /* pick start and end values */
          s = (double)i * (d1 - d0) / (double)m + d0;
          e = (double)i * (d3 - d2) / (double)m + d0;
          for(j=0;j<m;j++)
          {
            d = fsat((double)j * (e - s) / (double)m + s);
            out->scanlines[ADDRS(x*m+i,y*m+j,out->xs)+c] = d;
          }
        }
      }
    }
  }
  
  return out;
}



/* destroy an image gracefully */
void destroy_image(image *im)
{
  
  /* free the scanline memory */
  if(im->scanlines)
    free(im->scanlines);
  
  /* free the image structure itself */
  free(im);
}

