/* 
 * rawproc.c - process raw mattel camera files from rawdump
 * 02-25-03 E. Brombaugh forked from nickctl.c
 *
 * Copyright (C) 2000, 2003 Eric Brombaugh
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include "mattgfx.h"
#include "gfxfile.h"

int main(int argc, char **argv)
{
  /* variables for getopt() */
  extern char *optarg;
  int opt;
  
  FILE *infile;
  char *inname = "nick.raw", *outname = "nick.jpg";
  unsigned char databuf[20680];
  image *im, *cp, *unsharp, *scale, *outpic;
  char *text;
  int r;
  int v;
  int dmt;
  int quality;
  int g;
  int u;
  double C;
  int m;
  
  /* defaults */
  text = NULL;
  dmt = 3;
  quality = 50;
  C = 2.0;
  r = 2;
  g = -1;
  u = -1;
  v = 0;
  m = 1;
  
  /* parse options */
  while((opt = getopt(argc, argv, "c:i:m:o:q:r:t:vx:h")) != EOF)
  {
    switch(opt)
    {
      case 'c':
        /* Unsharp Coeff */
        C = atof(optarg);
        break;

      case 'i':
        /* input file */
        inname = optarg;
        break;

      case 'm':
        /* rendered text */
        text = optarg;
        break;

      case 'o':
        /* out filename */
        outname = optarg;
        break;

      case 'q':
        /* jpeg quality */
        quality = atoi(optarg);
        break;

      case 'r':
        /* Unsharp Radius */
        r = atoi(optarg);
        break;

      case 't':
        /* Demosaic type */
        dmt = atoi(optarg);
        break;

      case 'v':
        /* Verbose mode */
        v = 1;
        break;
        
      case 'x':
        /* interpolate */
        m = atoi(optarg);
        break;
        
      case 'h':
      case '?':
        fprintf(stderr, "USAGE: %s [options]\n", argv[0]);
        fprintf(stderr, "Version 0.1, February 25, 2003\n");
        fprintf(stderr, "Options: -c <Unsharp coeff>  Default: %f\n", C);
        fprintf(stderr, "         -i <file>           Default: %s\n", inname);
        fprintf(stderr, "         -m <text>           Default: none\n");
        fprintf(stderr, "         -o <out file>       Default: %s\n", outname);
        fprintf(stderr, "         -q <JPEG quality>   Default: %d\n", quality);
        fprintf(stderr, "         -r <Unsharp radius> Default: %d\n", r);
        fprintf(stderr, "         -t <demosaic type > Default: %d\n", dmt);
        fprintf(stderr, "         -v (verbose)        Default: off\n");
        fprintf(stderr, "         -x <scale>          Default: %d\n", m);
        exit(1);
    }
  }
  
  /* open up the input file */
  if(!(infile = fopen(inname, "r")))
  {
    if(v)
      fprintf(stderr, "Trouble opening the raw file %s\n", inname);
    exit(-1);
  }
    
  /* get the picture */
  if(fread(databuf, sizeof(unsigned char), 20680, infile) != 20680)
  {
    if(v)
      fprintf(stderr, "Couldn't read the raw data.\n");
    fclose(infile);
    exit(-1);
  }
  
  /* we're done with the file so close it */
  fclose(infile);
  
  /* correct black level and parse camera data into image */
  if(!(im = bayer_parse(databuf)))
  {
    if(v)
      fprintf(stderr, "Couldn't parse camera data: aborting\n");
    exit(-1);
  }
  
  /* now do the bayer->normal magic */
  demosaic(dmt, im);
  
  /* crop off the edges */
  cp = crop_image(im, 2, 4, 160, 120);
  
  /* don't need this anymore */
  destroy_image(im);
  
  /* if rawtype, don't unsharp image */
  if(!dmt || (r == 0))
  {
    outpic = cp;
  }
  else
  {
    /* unsharp mask */
    if(!(unsharp = unsharp_mask(cp, C, r)))
    {
      if(v)
        fprintf(stderr, "Couldn't process unsharp mask\n");
      goto image_error;
    }
    outpic = unsharp;
    
    /* don't need this anymore */
    destroy_image(cp);
  }
  
  /* scale if required */
  if(m > 1)
  {
    if(!(scale = interp_image(outpic, m)))
    {
      if(v)
        fprintf(stderr, "Couldn't scale image\n");
      goto image_error;
    }
    
    /* don't need this */
    destroy_image(outpic);
    
    outpic = scale;
  }

  /* if message, put it on the image */
  if(text)
    text_image(outpic, 0, outpic->ys, text);
  
  /* output the image */
  if(write_gfx(outname, outpic, quality) && v)
    fprintf(stderr, "Couldn't save file.\n");
  
  /*cleanup*/
  image_error:
  destroy_image(outpic);
  
}

