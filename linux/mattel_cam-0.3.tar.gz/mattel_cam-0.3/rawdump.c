/* 
 * rawdump.c - dump raw data from the Nick Click camera
 * 02-24-03 E. Brombaugh forked from nickctl.c
 *
 * Copyright (C) 2000, 2003 Eric Brombaugh
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include "mattcam.h"

/* write a raw camera buffer */
int write_raw(char *outname, unsigned char *data)
{
  int out = 0;
  FILE *outfile;
  
  /* open the output file */
  if(!(outfile = fopen(outname, "wb")))
  {
    fprintf(stderr, "Couldn't open %s for output.\n", outname);
    out = 1;
    goto error;
  }
  
  /* write the data */
  if(fwrite(data, sizeof(unsigned char), 20680, outfile) != 20680)
  {
    fprintf(stderr, "Trouble writing raw file\n");
    out = 1;
  }
  
  /* close the file */
  fclose(outfile);
  
  error:
  return out;
}

int main(int argc, char **argv)
{
  /* variables for getopt() */
  extern char *optarg;
  int opt;
  
  mc_struct mcs;
  int comm_err=0, grab_result = 0;
  char *inname = "/dev/ttyS0", *outname = "nick.raw";
  unsigned char databuf[20680];
  char *text;
  int r;
  int v;
  int dmt;
  int quality;
  int g;
  int u;
  double C;
  int m;
  
  /* defaults */
  text = NULL;
  g = -1;
  u = -1;
  v = 0;
  
  /* parse options */
  while((opt = getopt(argc, argv, "d:g:o:u:vh")) != EOF)
  {
    switch(opt)
    {
      case 'd':
        /* input device */
        inname = optarg;
        break;

      case 'g':
        /* grab image */
        g = atoi(optarg);
        break;

      case 'o':
        /* out filename */
        outname = optarg;
        break;

      case 'u':
        /* upload image */
        u = atoi(optarg);
        break;

      case 'v':
        /* Verbose mode */
        v = 1;
        break;
        
      case 'h':
      case '?':
        fprintf(stderr, "USAGE: %s [options]\n", argv[0]);
        fprintf(stderr, "Version 0.2.1, February 17, 2003\n");
        fprintf(stderr, "Options: -d <device>         Default: %s\n", inname);
        fprintf(stderr, "         -g <image #>        Default: %d\n", g);
        fprintf(stderr, "         -o <out file>       Default: %s\n", outname);
        fprintf(stderr, "         -u <image #>        Default: %d\n", u);
        fprintf(stderr, "         -v (verbose)        Default: off\n");
        exit(1);
    }
  }
  
  if((g==-1) && (u==-1))
  {
    fprintf(stderr, "Nothing to do!\n");
    exit(-1);
  }
  
  /* open up the camera I/O */
  if(init_mc(&mcs, inname, v))
  {
    fprintf(stderr, "Trouble opening the camera I/O.");
    exit(-1);
  }

  /* take a picture */
  if((g>=0) && (g<6))
  {
    if(mc_send_cmd(&mcs, ADDR_IMAGE, g)==ERR_COMM)
      comm_err = 1;
    if(mc_send_cmd(&mcs, GRAB_IMAGE, 0)==ERR_COMM)
      comm_err |= 2;
    if((grab_result = mc_send_cmd(&mcs, GRAB_RESULT, 0))==ERR_COMM)
      comm_err |= 4;
    
    if(v)
      fprintf(stderr, "Grab_result: %x\n", grab_result);
  }
  
  if((u>=0) && (u<6))
  {
    if(mc_send_cmd(&mcs, ADDR_IMAGE, u)==ERR_COMM)
      comm_err |= 8;
  
    /* get the picture */
    bzero(databuf, sizeof(databuf));
    if(mc_recv_pic(&mcs, databuf)==ERR_COMM)
      comm_err |= 16;
  
    /* check if everything worked */
    if(comm_err)
    {
      if(v)
        fprintf(stderr, "Communications Error %x: aborting.\n", comm_err);
      exit(ERR_COMM);
    }
  
    /* output the image */
    if(write_raw(outname, databuf) && v)
      fprintf(stderr, "Couldn't save file.\n");
  }
  
  return grab_result;
}

