/*****************************************************************************
 *
 *      IO Space Dump stub for Linux 2.[23].x
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *    (c) Copyright 2000 Eric Brombaugh <emeb@goodnet.com>
 *
 * History
 *  v0.01 - Oct 26 2000 - Eric Brombaugh
 *   first pass derivation from maestro3.c
 *
 */

/*****************************************************************************/

#include <linux/version.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,3,0)
 #include <linux/module.h>
 #if defined(MODULE) && defined(MODVERSIONS)
   #include <linux/modversions.h>
 #endif
 //#define DECLARE_WAITQUEUE(QUEUE,INIT) struct wait_queue QUEUE = {INIT, NULL}
 //#define wait_queue_head_t struct wait_queue *
 #define SILLY_PCI_BASE_ADDRESS(PCIDEV) (PCIDEV->base_address[0] & PCI_BASE_ADDRESS_IO_MASK)
 #define SILLY_INIT_SEM(SEM) SEM=MUTEX;
 //#define init_waitqueue_head init_waitqueue
 #define SILLY_MAKE_INIT(FUNC) __initfunc(FUNC)
 #define SILLY_OFFSET(VMA) ((VMA)->vm_offset)
#else
 #define SILLY_PCI_BASE_ADDRESS(PCIDEV) (PCIDEV->resource[0].start)
 #define SILLY_INIT_SEM(SEM) init_MUTEX(&SEM)
 #define SILLY_MAKE_INIT(FUNC) __init FUNC
 #define SILLY_OFFSET(VMA) ((VMA)->vm_pgoff)
#endif

#include <linux/string.h>
#include <linux/ctype.h>
#include <linux/ioport.h>
#include <linux/sched.h>
#include <linux/delay.h>
#include <linux/sound.h>
#include <linux/malloc.h>
#include <linux/soundcard.h>
#include <linux/pci.h>
#include <asm/io.h>
#include <asm/dma.h>
#include <linux/init.h>
#include <linux/poll.h>
#include <linux/reboot.h>
#include <asm/uaccess.h>
#include <asm/hardirq.h>
#include <asm/spinlock.h>

#define M_DEBUG 1

#define DRIVER_VERSION      "0.01"
#define PFX                 "iodump: "

#ifdef M_DEBUG
static int debug=1;
#define DPMOD   1   /* per module load */
#define DPSTR   2   /* per 'stream' */
#define DPSYS   3   /* per syscall */
#define DPCRAP  4   /* stuff the user shouldn't see unless they're really debuggin */
#define DPINT   5   /* per interrupt, LOTS */
#define DPRINTK(DP, args...) {if (debug >= (DP)) printk(KERN_DEBUG PFX args);}
#else
#define DPRINTK(x)
#endif

int addr_start = 0x6100;
int addr_len = 0xff;

#ifdef MODULE
int init_module(void)
#else
int SILLY_MAKE_INIT(init_iodump(void))
#endif
{
    int i;

    printk(KERN_INFO PFX "version " DRIVER_VERSION " time " __TIME__ " " __DATE__ "\n");

    for(i = 0; i < addr_len; i+=8)
    {
       printk(KERN_INFO "%4.4x: %2.2x %2.2x %2.2x %2.2x %2.2x %2.2x %2.2x %2.2x\n",
       (addr_start+i)&0xffff, inb(i+addr_start), inb(i+addr_start+1), inb(i+addr_start+2),
       inb(i+addr_start+3), inb(i+addr_start+4), inb(i+addr_start+5), inb(i+addr_start+6),
       inb(i+addr_start+7));
    }
    
    printk(KERN_INFO PFX "dump complete.\n");
    return -ENODEV;
}

/* --------------------------------------------------------------------- */

#ifdef MODULE
MODULE_AUTHOR("Eric Brombaugh <emeb@goodnet.com>");
MODULE_DESCRIPTION("IO Space dump stub module");
#ifdef M_DEBUG
MODULE_PARM(debug,"i");
#endif
MODULE_PARM(addr_start,"i");
MODULE_PARM(addr_len,"i");

void cleanup_module(void) {
    DPRINTK(DPMOD,"unloading\n");
}

#endif /* MODULE */
