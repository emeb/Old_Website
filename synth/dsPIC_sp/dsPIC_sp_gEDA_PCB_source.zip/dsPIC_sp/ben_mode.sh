 # photorealistic PCB rendering
 pcb -x png --ben-mode --dpi 450 dsPIC_sp.pcb
 pngtopnm dsPIC_sp.png | pamscale 0.333333 | cjpeg -q 90 > dsPIC_sp.jpg