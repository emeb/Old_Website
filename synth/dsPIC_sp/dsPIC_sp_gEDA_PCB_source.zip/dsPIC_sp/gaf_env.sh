#!/bin/sh
# set env vars to run new gEDA tools
export LD_LIBRARY_PATH=/home/ericb/geda/lib:$LD_LIBRARY_PATH
export PATH=/home/ericb/geda/bin:${PATH}
