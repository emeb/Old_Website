gnetlist -g bom dsPIC_sp_pg?.sch -o bom.txt
