/*...........................................................................*/
/* spi.c - interface routines for spi driver                                 */
/* 06/07/2009 E. Brombaugh                                                   */
/*...........................................................................*/

#include <p33FJ32GP302.h>
#include "spi.h"

#define SPI_MAXLOOP 300

void init_spi()
{
	/* Setup access to 23k256 SRAM on SPI1 */
	/* GPIO for /CS pin on dsPIC */
	/* /CS = RB3 */
	TRISBbits.TRISB3 = 0;	// /CS Output on B3
	LATBbits.LATB3 = 1;		// Active low

	/* Setup Peripheral Pin Select for SPI */
	/*  SO = RB2 */
	/* SCK = RB5 */
	/*  SI = RB6 */
	__builtin_write_OSCCONL(OSCCON & ~(1<<6));	// Unlock access to RP registers
	RPOR1 = 0x0007;		// SDO1 on RP2	
	RPOR2 = 0x0008;		// SCK1 on RP5	
	RPINR20 = 0x1F06;	// SDI1 on RP6	
	__builtin_write_OSCCONL(OSCCON | (1<<6));	// Lock access to RP registers

	/* Setup SPI port to talk to SRAM */
	SPI1CON1 = 0x0533;	// 16-bit, data chg fall, ck act high, Master, 4:1, 1:1
						// 5.88MHz SPI clock, 16-bit: 1 xfers = ~2.8us
	SPI1CON2 = 0;				// no framing	
	SPI1STATbits.SPIROV = 0;	// 
	SPI1STATbits.SPIEN = 1;		// Enable SPI1 port
}

int write_spi(unsigned int data)
{
	unsigned int dummy, lpcnt;

	// Drop CSB
	LATBbits.LATB6 = 0;

	// Dummy read to clear SPI read buffer flag
	dummy = SPI1BUF;

	// Send data via SPI1
	SPI1BUF = data;
	
	// Wait for SPI TX done
	lpcnt = 0;
	while(!SPI1STATbits.SPIRBF)
	{
		if(lpcnt++ > SPI_MAXLOOP)
			goto wrt_spi_err;
	}
	LATBbits.LATB6 = 1;			// de-assert CSB
	
	// return success
	return 0;
	
	// Error condition
wrt_spi_err:
	LATBbits.LATB6 = 1;			// de-assert CSB
	return -1;
}

int read_spi(unsigned int *data)
{
	// Not implemented now - W8731 doesn't need it.
	return -1;
}

