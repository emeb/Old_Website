/*...........................................................................*/
/* w8731.h - header file for codec driver                                    */
/* 06/07/2009 E. Brombaugh                                                   */
/*...........................................................................*/

#ifndef __w8731__
#define __w8731__

void init_w8731();
void reset_w8731();
void write_w8731(unsigned char reg, unsigned int data);

#endif
