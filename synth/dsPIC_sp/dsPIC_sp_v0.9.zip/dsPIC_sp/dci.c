/*...........................................................................*/
/* dci.c - interface routines for dci driver                                 */
/* 05/30/2009 E. Brombaugh                                                   */
/*...........................................................................*/

#include <p33FJ32GP302.h>
#include "dci.h"

void init_dci()
{
	/* Setup RA3 for diagnostics */
	TRISAbits.TRISA3 = 0;	// Set port A bit 3 to output
	LATAbits.LATA3 = 0;		// Clear

	/* Setup Peripheral Pin Select for DCI and OC1 */
	__builtin_write_OSCCONL(OSCCON & ~(1<<6));	// Unlock access to RP registers
	RPOR2 = 0x0800;			// RP4 out = default, RP5 out = SPI1_CLK
	RPOR3 = 0x1207;			// RP6 out = SPI_MOSI, RP7 out = OC1
	RPOR6 = 0x0F00;			// RP12 out = default, RP13 out = DCI CSDO
	RPOR7 = 0x0E0D;			// RP14 out = DCI COFS, RP15 out = DCI CSCK
	RPINR20 = 0x0002;		// SPI_MISO on RB2/RP2
	RPINR24 = 0x000C;		// CSDI on RB12/RP12
	__builtin_write_OSCCONL(OSCCON | (1<<6));	// Lock access to RP registers
	
	/* Setup Timer 3 to divide processor clock by 2 */
	PR3 = 1;				// 23.031255MHZ/2 = 11.5MHz
	T3CONbits.TON = 1;		// Turn on Timer 3, 16-bit, sysclk
		
	/* Setup RP5 as OC1 MCLK output */
	OC1RS = 1;				// Pulse is 1 cycles wide
	OC1R = 1;				// Pulse is 1 cycles wide
	OC1CON = 14;			// PWM, no fault on T2

	/* Setup DCI port */
	DCICON1 = 0x0201;		// Rising edge sample, I2S
	DCICON2 = 0x042f;		// 2words/int, 2 words/frame, 16bit words
	DCICON3 = 0x0003;		// Bitclk per = Tcy*2*(3+1) (2.879MHz)
	TSCON = 0x0001;			// Transmit slot 0
	RSCON = 0x0001;			// Recieve slot 0
	TXBUF0 = 0;				// Clear the TX buffer
	TXBUF1 = 0;
	DCICON1bits.DCIEN = 1;	// Enable DCI
	IPC15bits.DCIIP1 = 1;	// Set priority of DCI irq to 6
	IEC3bits.DCIIE = 1;		// Enable DCI interrupt
}
