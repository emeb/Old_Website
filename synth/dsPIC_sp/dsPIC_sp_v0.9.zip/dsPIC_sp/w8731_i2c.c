/*...........................................................................*/
/* w8731.c - interface routines for codec driver                             */
/* 06/07/2009 E. Brombaugh                                                   */
/*...........................................................................*/

#include <p33FJ32GP302.h>
#include "w8731.h"
#include "i2c.h"

#define W8731_ADDR_0 0x1A
#define W8731_ADDR_1 0x1B
#define W8731_NUM_REGS 10

unsigned int w8731_init_data[] = 
{
	0x017,			// Reg 00: Left Line In (0dB, mute off)
	0x017,			// Reg 01: Right Line In (0dB, mute off)
	0x079,			// Reg 02: Left Headphone out (0dB)
	0x079,			// Reg 03: Right Headphone out (0dB)
	0x012,			// Reg 04: Analog Audio Path Control (DAC sel, Mute Mic)
	0x000,			// Reg 05: Digital Audio Path Control
	0x062,			// Reg 06: Power Down Control (Clkout, Osc, Mic Off)
	0x00E,			// Reg 07: Digital Audio Interface Format (i2s, 32-bit, slave)
	0x000,			// Reg 08: Sampling Control (Normal, 256x, 48k ADC/DAC)
	0x001			// Reg 09: Active Control
};

void init_w8731()
{
	int i;

	// Reset to known state
	reset_w8731();
	
	// Configure all registers
	for(i=0;i<W8731_NUM_REGS;i++)
	{
		write_w8731(i, w8731_init_data[i]);
	}
}

void reset_w8731()
{
	write_w8731(0x0F, 0);
}

void write_w8731(unsigned char reg, unsigned int data)
{
	unsigned char wdata[3];

	// stuff the output buffer
	wdata[0] = (W8731_ADDR_0 << 1) | 0;
	wdata[1] = ((reg<<1)&0xFE) | ((data>>8)&0x01);
	wdata[2] = data&0xff;

	// Send it
	write_i2c(wdata, 3);
}
