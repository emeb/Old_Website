/***********************************************************************
 *    Project:        dsPIC_sp                                         * 
 *    Author:         Eric Brombaugh                                   *
 *    Company:        KBADC                                            * 
 *    Filename:       main.c                                           *
 *    Date:           09/01/2010                                       *
 *    File Version:   0.9                                              *
 *    Other Files Required: traps.c                                    *
 *    Tools Used: MPLAB IDE -> 8.53                                    *
 *                Compiler  -> 3.24                                    *
 *                                                                     *
 *    Devices Supported:                                               *
 *                dsPIC33FJ32GP302                                     *
 *                                                                     *
 ***********************************************************************
 * History:                                                            *
 *                                                                     *
 * V0.0  05/28/2009                                                    *
 *   - Started based on previous M2CV_2 project                        *
 *     - Change to dsPIC33FJ64GP802                                    *
 *     - update for '802                                               *
 * V0.1  05/30/2009                                                    *
 *   - Cleanup ADC interface routines                                  *
 *   - Add DCI interface routines                                      *
 *   - Reduce ADC rate for longer integration time                     *
 * V0.2  06/01/2009                                                    *
 *     - Change to dsPIC33FJ32GP302                                    *
 * V0.3  06/03/2009                                                    *
 *     - Add option for FS Pedal pinmux, debug                         *
 * V0.4  06/07/2009                                                    *
 *     - remove FS Pedal, add I2C & W8731 stuff                        *
 * V0.5  06/09/2009                                                    *
 *     - Replace I2C with SPI - seems to work                          *
 * V0.6  06/10/2009                                                    *
 *     - more debugging on I2C                                         *
 * V0.7  07/14/2009                                                    *
 *     - Reallocate pins for PCB                                       *
 * V0.8  07/25/2010                                                    *
 *     - cleanup                                                       *
 *     - add gain ctl                                                  *
 *     - cut down ADC chls to 4                                        *
 * V0.9  09/01/2010                                                    *
 *     - cleanup old I2C stuff                                         *
 *     - start SPI code to talk to SRAM                                *
 *                                                                     *
 **********************************************************************/
#include <p33FJ32GP302.h>
#include "adc.h"
#include "dci.h"
#include "spi.h"
#include "i2c.h"
#include "w8731.h"

/************* Configuration Bits **********/
_FBS(BWRP_WRPROTECT_OFF)		// No Boot Protect
_FGS(GSS_OFF)					// No Code Protect
_FOSCSEL(FNOSC_FRCPLL)			// Fast RC and PLL
_FOSC(FCKSM_CSDCMD & OSCIOFNC_ON & IOL1WAY_OFF)
//Turn off clock switch & monitor, OSC2 is GPIO, allow multiple IOLOCKs
_FWDT(FWDTEN_OFF)				// Turn off Watchdog Timer
_FPOR(FPWRT_PWR16)				// Power-up Timer to 16msecs
_FICD(ICS_PGD2 & JTAGEN_OFF)	// Use PGC/D 2, no JTAG

/************* START OF GLOBAL DEFINITIONS **********/

/************** END OF GLOBAL DEFINITIONS ***********/

/* setup hardware */
void init_hw(void)
{
	/* Setup ADC & DMA */
	init_adc();

	/* Setup DCI */
	init_dci();

	/* Setup I2C */
	init_i2c();

	/* Setup SPI to talk to 23k256 SRAM */
	init_spi();

	/* Configure Codec */
	init_w8731();

}

/************* START OF MAIN FUNCTION ***************/

int main ( void )
{
//	int dcnt = 0;

	/* Initialize hardware */
	init_hw();

	/* Loop forever */
	while(1)
	{
		if(ADCRDY)
		{
			ADCRDY = 0;

			/* handle ADC */
			GAIN0 = CV[0];
			GAIN1 = CV[1];
		}

#if 0
		/* periodically send new data to I2C for test */
		if(dcnt++ > 64)
		{
			// test codec write
			write_w8731(0x08, 0x00);
			//reset_w8731();
			dcnt = 0;
		}
#endif
	}
	
	return 0;
}

/****** START OF INTERRUPT SERVICE ROUTINES *********/

/* DCI ISR is in Assembly - see file 'dci_isr.s' */

/* DMA0 ISR is in Assembly - see file 'adc_isr.s' */

/********* END OF INTERRUPT SERVICE ROUTINES ********/

