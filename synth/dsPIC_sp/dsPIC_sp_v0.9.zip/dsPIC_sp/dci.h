/*...........................................................................*/
/* dci.h - header file for dci driver                                        */
/* declares data structures and access routines used by DCI ISR              */
/* 05/30/2009 E. Brombaugh                                                   */
/*...........................................................................*/

#ifndef __dci__
#define __dci__

volatile extern int GAIN0;			// Chl 0 gain value
volatile extern int GAIN1;	 		// Chl 1 gain value

void init_dci();

#endif
