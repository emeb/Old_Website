/*...........................................................................*/
/* adc.h - header file for adc driver                                        */
/* declares data structures and access routines used by ADC ISR              */
/* 05/28/2009 E. Brombaugh                                                   */
/*...........................................................................*/

#ifndef __adc__
#define __adc__

volatile extern int CV[6];			// Array of Integrated ADC values
volatile extern int ADCCHL[6] __attribute__((space(dma)));	// Array of Raw ADC values
volatile extern int ADCRDY;	 		// ADC Ready flag

void init_adc();

#endif
