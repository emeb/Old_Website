/*...........................................................................*/
/* i2c.h - header file for i2c driver                                        */
/* 05/30/2009 E. Brombaugh                                                   */
/*...........................................................................*/

#ifndef __i2c__
#define __i2c__

void init_i2c(void);
int write_i2c(unsigned char *data, int DataSz);

#endif
