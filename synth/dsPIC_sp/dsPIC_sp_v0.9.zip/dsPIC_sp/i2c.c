/*...........................................................................*/
/* i2c.c - interface routines for i2c driver                                 */
/* 06/07/2009 E. Brombaugh                                                   */
/*...........................................................................*/

#include <p33FJ32GP302.h>
#include "i2c.h"

void init_i2c()
{
	// Configure Port B6 as diagnostic
	TRISBbits.TRISB6 = 0;
	LATBbits.LATB6 = 0;

	//I2C1CONbits.DISSLW = 1;		// No slew control
	I2C1CONbits.A10M = 0;		// 7-bit address
	I2C1CONbits.SCLREL = 1;		// No clock stretch
	I2C1BRG = 209;				// 209 for 100kHz @ Fcy = 23.03MHz

	I2C1ADD = 0;
	I2C1MSK = 0;
	
	I2C1CONbits.I2CEN = 1;		// Enable I2C
}

/*...........................................................................*/
/* a bunch of private functions used by the write_i2c() routine              */
/*...........................................................................*/
void StartI2C1(void)
{
     I2C1CONbits.SEN = 1;	/* initiate Start on SDA and SCL pins */
}

void IdleI2C1(void)
{
    /* Wait until I2C Bus is Inactive */
    while(I2C1CONbits.SEN || I2C1CONbits.PEN || I2C1CONbits.RCEN || 
          I2C1CONbits.ACKEN || I2C1STATbits.TRSTAT);	
}

char MasterWriteI2C1(unsigned char data_out)
{
    I2C1TRN = data_out;

    if(I2C1STATbits.IWCOL)        /* If write collision occurs,return -1 */
        return -1;
    else
    {
        return 0;
    }
}

void StopI2C1(void)
{
     I2C1CONbits.PEN = 1;	/* initiate Stop on SDA and SCL pins */
}

/*...........................................................................*/

int write_i2c(unsigned char *i2cData, int DataSz)
{
	int result = 0, Index = 0;
	
	// Raise Diagnostic
	LATBbits.LATB6 = 1;
	
	StartI2C1();	//Send the Start Bit
	IdleI2C1();		//Wait to complete
	
	// send 
	while( DataSz )
	{
		MasterWriteI2C1( i2cData[Index++] );
		IdleI2C1();		//Wait to complete
		
		DataSz--;

		//ACKSTAT is 0 when slave acknowledge. if 1 then slave has not acknowledge the data.
		if( I2C1STATbits.ACKSTAT )
		{
			result = -1;
			break;
		}
	}

	StopI2C1();	//Send the Stop condition
	IdleI2C1();	//Wait to complete

	LATBbits.LATB6 = 0;
	return result;
}

