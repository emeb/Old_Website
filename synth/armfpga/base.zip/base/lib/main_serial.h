void VCOM_init(void);
int VCOM_putchar(int c);
int VCOM_getchar(void);

int main_serial(void);
