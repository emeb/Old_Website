setup()	// not really a fn - just pseudo
{
	// initialize PINSEL0 & PINSEL1
	PINSEL0 = 0x00;
	PINSEL1 = 0x00;

	// set up I2C
	if ((IOPIN & 0x0C) == 0x0C) // SCL & SDA should be high, they will be pulled
	{							// down with jumpers when there is no I2C device
		NoI2CDevice = 0;
		VICVectCntl1 = 0x00000029; // select a priority spot for a given interrupt
		VICVectAddr1 = (unsigned long) I2CISR; // pass the address of the ISR
		VICIntEnable = 0x00000200; // enable interrupt
		PINSEL0 |= 0x50; // switch GPIO to I2C pins
		I2C_I2CONCLR = 0x6C; // clear all I2C settings
		I2C_I2CONSET = 0x40; // enable I2C interface
		I2C_I2SCLH = 300; // set bit rate to 58.9824 MHz / 100000
		I2C_I2SCLL = 300; // or about 600 -- 300 counts high, 300 low
	}
	else
		NoI2CDevice = 1;
}
	
void InitIOPorts(void)
{
	int i;
	unsigned char msg = 0xFF;

	for (i = 0; i < MAXINP; i++)
	{
		I2CMasterSend(inputports[i].address, 1, &msg);
	}

	for (i = 0; i < MAXOUT; i++)
	{
		I2CMasterSend(outputports[i].address, 1, &msg);
	}
}

void ReadInputPorts(void)
{
	int i;
	unsigned char buf[2];

	for (i = 0; i < MAXINP; i++)
	{
		I2CMasterReceive(inputports[i].address, 0, 1, buf);
		inputports[i].mirror = buf[0];
	}
}

void WriteOutputPorts(void)
{
	int i;

	for (i = 0; i < MAXOUT; i++)
	{
		I2CMasterSend(outputports[i].address, 1, &outputports[i].mirror);
	}
}
