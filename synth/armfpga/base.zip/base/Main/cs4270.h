/* cs4270.h - initialize CS4270 audio codec via I2S */
/* E. Brombaugh 2-25-2009                           */

#ifndef __cs4270__
#define __cs4270__

#define CS4270_I2CADDR 0x48
#define CS4270_REG_ID 0x01
#define CS4270_REG_PCTL 0x02
#define CS4270_REG_MODE 0x03
#define CS4270_REG_SFMT 0x04
#define CS4270_REG_TCTL 0x05
#define CS4270_REG_MUTE 0x06
#define CS4270_REG_VOLA 0x07
#define CS4270_REG_VOLB 0x08
#define CS4270_REG_INCR 0x80

int init_cs4270(void);

#endif
