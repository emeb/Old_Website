/* i2c.h - low level master send/receive routines for I2C interface */
/* E. Brombaugh 2-25-2009                                           */

#ifndef _I2C_H_
#define _I2C_H_

#include <setjmp.h>

extern jmp_buf i2cerror;

#define I2C_READADDR(x) (((x)<<1)|0x01)
#define I2C_WRITEADDR(x) ((x)<<1)

void InitI2C(void);
void SendI2CAddress(unsigned char Addr_S);
unsigned char ReadI2C(void);
void WriteI2C(unsigned char Data);
void StopI2C(void);

#endif //_I2C_H_
