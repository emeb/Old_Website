//*******************************************************
//				I/O Defines
//*******************************************************
#define LED (1<<24)
#define SD_CS		(1<<7)			//Define P0.7
#define SCLK_PINSEL		(1<<8)		//Select SPI Function for P0.4
#define MISO_PINSEL		(1<<10)		//Select SPI Function for P0.5
#define MOSI_PINSEL		(1<<12)		//Select SPI Function for P0.6

void delay_ms(int count);
