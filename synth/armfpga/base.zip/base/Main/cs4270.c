/* cs4270.c - initialize CS4270 audio codec via I2S */
/* E. Brombaugh 2-25-2009                           */

#include <stdio.h>
#include <stdlib.h>
#include "LPC214x.h"
#include "rprintf.h"
#include "i2c.h"
#include "cs4270.h"

extern void delay_ms(int count);

int init_cs4270(void)
{
	unsigned char i, err, r;

	/* Start up the I2C port 0 */
	InitI2C();
	if ((err=setjmp(i2cerror)))
	{
		rprintf("cs4270: I2C error %d\n", err);
		return 1;
	}
	rprintf("cs4270: I2C0 setup\n");
	
	/* Send Power Down command to CS4270 */
	SendI2CAddress(I2C_WRITEADDR(CS4270_I2CADDR));
	WriteI2C(CS4270_REG_PCTL);	// Reg Addr
	WriteI2C(0x00);				// data = power up
	StopI2C();
	rprintf("cs4270: Codec powered down \n");
	
	/* Wait 1ms */
	delay_ms(1);
	
	/* Send Power Up command to CS4270 */
	SendI2CAddress(I2C_WRITEADDR(CS4270_I2CADDR));
	WriteI2C(CS4270_REG_PCTL);	// Reg Addr
	WriteI2C(0x00);				// data = power up
	StopI2C();
	rprintf("cs4270: Codec powered up\n");
	
	/* Dump registers */
	SendI2CAddress(I2C_WRITEADDR(CS4270_I2CADDR));
	WriteI2C(CS4270_REG_INCR);	// Reg Addr (dummy w/ incr)
	StopI2C();
	SendI2CAddress(I2C_READADDR(CS4270_I2CADDR));
	for(i=0;i<9;i++)
	{
		r = ReadI2C();             // read the result
		rprintf("cs4270: Codec reg  %d = %d\n", i, r);
	}
	StopI2C();
	
	/* Initialize Regs */
	SendI2CAddress(I2C_WRITEADDR(CS4270_I2CADDR));
	WriteI2C(CS4270_REG_INCR|CS4270_REG_PCTL);	// Reg Addr (mode w/ incr)
	WriteI2C(0x20);				// 2 power = adc off
	WriteI2C(0x32);				// 3 mode = slave, div1.5 - default
	WriteI2C(0x09);				// 4 sfmt = I2S
	WriteI2C(0x60);				// 5 tctl = soft dac, zcdac - default
	WriteI2C(0x20);				// 6 mute = auto - default
	WriteI2C(0x00);				// 7 vola = full
	WriteI2C(0x00);				// 8 volb = full
	StopI2C();
	rprintf("cs4270: Codec initialized \n");
	
	/* Dump registers */
	SendI2CAddress(I2C_WRITEADDR(CS4270_I2CADDR));
	WriteI2C(CS4270_REG_INCR);	// Reg Addr (dummy w/ incr)
	StopI2C();
	SendI2CAddress(I2C_READADDR(CS4270_I2CADDR));
	for(i=0;i<9;i++)
	{
		r = ReadI2C();             // read the result
		rprintf("cs4270: Codec reg  %d = %d\n", i, r);
	}
	StopI2C();
	
	/* clean exit */
	return 0;
}

