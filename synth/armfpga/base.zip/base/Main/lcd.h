/* lcd.c : LCD driver code for LPC2148 ARM FPGA board */
/* 02-20-2009, E. Brombaugh                           */

#ifndef __lcd__
#define __lcd__

#define LCD_DATA_BITS (0xF<<16)	// LCD data bits on Port1.16-19
#define LCD_E_BIT (1<<20)		// LCD Enable bit on Port1.20
#define LCD_RS_BIT (1<<21)		// LCD Reg Sel bit on Port 1.21
#define LCD_RW_BIT (1<<22)		// LCD R/W bit on Port 1.22
#define LCD_BITS	(0x7F<<16)	// LCD output on Port 1.16-22

void init_lcd(void);

void write_lcd(char *src, int line);

void slc_lcd(int cnt);

#endif
