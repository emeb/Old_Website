/* lcd.c : LCD driver code for LPC2148 ARM FPGA */
/* 02-20-2009, E. Brombaugh                     */

#include "LPC214x.h"
#include "lcd.h"

/* LUT to swap upper bits of data nybble */
const int nyb_swap[] = 
{
	0, 1, 2, 3,
	8, 9, 10, 11,
	4, 5, 6, 7,
	12, 13, 14, 15
};

/* delay routine used to time LCD operations. Time in ns */
void delay_lcd(int time)
{
	int i;
	
	/* scale time for 100 ns/tick */
	time = time / 100;
	
	/* minimum 1 tick */
	time = time < 1 ? 1 : time;
	
	for (i = 0; i < time; i++)	//We are going to count to 10000 "time" number of times
		asm volatile ("nop");	//"nop" means no-operation.  We don't want to do anything during the delay
}

/* Send a nybble to the LCD */
void nybble_lcd(int data, int rs)
{
	int outdat;

	/* Clear E, RW */
	IOCLR1 = (LCD_E_BIT | LCD_RW_BIT);

	/* Set RS? */
	if(rs)
		IOSET1 = LCD_RS_BIT;
	else
		IOCLR1 = LCD_RS_BIT;
  
	/* Output data nybble */
	outdat = nyb_swap[data & 0xf];
	IOSET1 = outdat<<16;
	IOCLR1 = ((~outdat)&0xf)<<16;

	/* Raise enable */
	IOSET1 = LCD_E_BIT;

	/* Wait 250ns */
	delay_lcd(250);

	/* drop enable - no explicit delay needed */
	IOCLR1 = LCD_E_BIT;
}

/* Send a command byte to the LCD */
void cmd_lcd(int cmd)
{
	/* Upper 4 bits */
	nybble_lcd((cmd>>4)&0xf, 0);

	/* Wait 1us */
	delay_lcd(1000);

	/* Lower 4 bits */
	nybble_lcd(cmd&0xf, 0);
}

/* Send a data byte to the LCD */
void data_lcd(int data)
{
	/* Upper 4 bits */
	nybble_lcd((data>>4)&0xf, 1);

	/* Wait 1us */
	delay_lcd(1000);

	/* Lower 4 bits */
	nybble_lcd(data&0xf, 1);
}

/* initialize the LCD */
void init_lcd()
{
	/* Wait 15 ms or longer */
	delay_lcd(15000000);

	/* Write SF_D<11:8> = 0x3, pulse LCD_E High 240ns */
	nybble_lcd(3, 0);

	/* Wait 4.1ms or longer */
	delay_lcd(4100000);

	/* Write SF_D<11:8> = 0x3, pulse LCD_E High 240ns */
	nybble_lcd(3, 0);

	/* Wait 100us or longer */
	delay_lcd(100000);

	/* Write SF_D<11:8> = 0x3, pulse LCD_E High 240ns */
	nybble_lcd(3, 0);

	/* Wait 40us or longer */
	delay_lcd(40000);

	/* Write SF_D<11:8> = 0x2, pulse LCD_E High 240ns */
	nybble_lcd(2, 0);

	/* Wait 40us or longer */
	delay_lcd(40000);

	/* Function Set command */
	cmd_lcd(0x28);

	/* Wait 40us or longer */
	delay_lcd(40000);

	/* Entry mode command */
	cmd_lcd(0x06);

	/* Wait 40us or longer */
	delay_lcd(40000);

	/* Display on, cursor on */
	cmd_lcd(0x0E);

	/* Wait 40us or longer */
	delay_lcd(40000);
}

/* Send an ASCII string to the LCD */
void write_lcd(char *src, int line)
{
	int cnt = 20;

	switch(line&3)
	{
		/* DD Address 0 */
		case 0:
			cmd_lcd(0x80);
			break;
    
		/* DD Address 0x40 */
		case 1:
			cmd_lcd(0xC0);
			break;
    
		/* DD address 0x14 */
		case 2:
			cmd_lcd(0x94);
			break;
    
		/* DD address 0x54 */
		case 3:
			cmd_lcd(0xD4);
			break;
	}

	/* Wait 40us or longer */
	delay_lcd(40000);

	/* loop until end of string or 20 chars */
	while(cnt-- > 0)
	{
		if(*src!=0)
			data_lcd(*src++); /* send char */
		else
			data_lcd(0x20); /* send space */
    
		/* Wait 40 ?s or longer */
		delay_lcd(40000);
	}
}

/* Shift cursor left */
void slc_lcd(int cnt)
{
	while(cnt-- >0)
	{
		/* shift cursor left one char */
		cmd_lcd(0x10);

		/* Wait 40 ?s or longer */
		delay_lcd(40000);
	}
}
