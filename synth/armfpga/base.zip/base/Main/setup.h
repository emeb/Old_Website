//********************************************************************
//
//				MP3 Player Constant Values
//
//********************************************************************
#define MAXFILENAMELEN 		40		//Defines the number of characters allowed in a filename
#define MAXBUFFERSIZE 		32		//The amount of bytes buffered from the MP3 file.  The FIFO buffer of the MP3 player is 32 bytes
#define	NUMFILESBUFFERED	15		//Number of filenames to buffer from the SD card per read
#define MAXDISPLEN			22		//Number of characters that will fit in one row of the LCD
#define	NUMROWS				15		//Number of rows available on the LCD (doesn't include the title)

//********************************************************************
//
//				MP3 Player Structures
//
//********************************************************************
//SongStruct: The song struct is used to store information about the currently selected song.
typedef struct{
	char name[MAXDISPLEN];				//Filename with the .mp3 removed	
	char file_name[MAXFILENAMELEN];		//Filename retrieved from the SD card
	struct fat16_file_struct* handle;	//File Handle read from the SD card
	int size;							//Size of the file in bytes
	char extension;						//Indicates the file type
	unsigned char data[MAXBUFFERSIZE];	//Holds the data to be sent to the MP3 player
} SongStruct;

//Filestruct: 
typedef struct{
	char file_name[MAXFILENAMELEN];
} FileStruct;


//********************************************************************
//
//				MP3 Player Function Prototypes
//
//********************************************************************
void bootUp(void);
void reset(void);	
char getButton(void);
char loadNewSong(FileStruct *Files);
void closeSong(void);
