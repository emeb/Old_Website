/* i2c.c - low level master send/receive routines for I2C interface */
/* E. Brombaugh 2-25-2009                                           */

#include "LPC214x.h"
#include "i2c.h"

/* This is a modified I2C module based on the code by Pierre Seguin		    */
/* it tests the status of all transactions and returns any error codes      */
/* via a "longjmp"                                                          */
/* It is easily modified to directly return the status codes instead of     */
/* using the longjmps                                                       */
/* This code returns an error value of 1 for the most likley error:-        */
/*  - no device available. This is not a code that can be confused with the */
/* standard status values.                                                  */
/* A sample of its use is getBattery() using a PCF8591 A/D device           */
/* Owen Mooney                                                              */

jmp_buf i2cerror;

#define STA  0x20
#define SIC  0x08
#define SI   0x08
#define STO  0x10
#define STAC 0x20
#define AA   0x04

void InitI2C(void)
{
	I20CONCLR = 0xFF;
	PINSEL0 |= 0x50;	// Set pinouts as scl and sda
	I20SCLL = 350;		// speed at 85.7Khz for a VPB Clock Divider  = 1
	I20SCLH = 350;
	I20CONSET = 0x40;	// Active Master Mode on I2C bus
}

void SendI2CAddress(unsigned char Addr_S){
    unsigned char r;
    I20CONCLR = 0xFF;             // clear I2C - included if User forgot to "StopI2C()"
                                 // else this function would hang.
    I20CONSET = 0x40;             // Active Master Mode on I2C bus
    if((Addr_S & 0x01))          // test if it's reading
       I20CONSET = STA | AA;      // set STA - allow master to acknowlege slave;
    else
       I20CONSET = STA;           // set STA dont allow acknowledges;
    while(I20STAT!=0x08) ;        // Wait for start to be completed
    I20DAT    = Addr_S;           // Charge slave Address
    I20CONCLR = SIC | STAC;       // Clear i2c interrupt bit to send the data
    while( ! ( I20CONSET & SI)) ; // wait till status available
    r=I20STAT;                    // read Status. See standard error codes pdf (link in manual).
    if(!(Addr_S & 0x01)) {       // if we are doing a write
        if (r != 0x18) {             // look for "SLA+W has been transmitted; ACK has been received"
             if ( r==0x20 )          // check for "SLA+W has been transmitted; NOT ACK has been received"
                longjmp(i2cerror,1); // no acknowlege - probably no device there. Return a 1 in longjmp
             longjmp(i2cerror,r);    // other error - return status code in longjmp
        }
     } else {
        if (r != 0x40) {             // look for "SLA+R has been transmitted; ACK has been received"
             if ( r==0x48 )          // check for "SLA+R has been transmitted; NOT ACK has been received"
                longjmp(i2cerror,1); // no acknowlege - probably no device there. Return a 1 in longjmp
             longjmp(i2cerror,r);    // other error - return status code in longjmp
        }
     }
}

unsigned char ReadI2C(void) {
    unsigned char r;
    I20CONCLR = SIC;                  // clear SIC;
    while( ! (I20CONSET & 0x8));      // wait till status available
    r=I20STAT;                        // check for error
    if (r != 0x50){                  // look for "Data byte has been received; ACK has been returned"
       longjmp(i2cerror,r);          // read fail
    }
    return I20DAT;
}

void WriteI2C(unsigned char Data) {
    unsigned char r;
    I20DAT    = Data;                // Charge Data
    I20CONCLR = 0x8;                 // SIC; Clear i2c interrupt bit to send the data
    while( ! (I20CONSET & 0x8));     // wait till status available
    r=I20STAT;
    if (r != 0x28){                 // look for "Data byte in S1DAT has been transmitted; ACK has been received"
       longjmp(i2cerror,r);         // write fail
    }
}

void StopI2C(void){
    I20CONCLR = SIC;
    I20CONSET = STO;
    while((I20CONSET&STO)) ;         // wait for Stopped bus I2C
}

/* Usage example */
#if 0
float getBattery(void){     // Read the battery voltage with a PCF8591 A/D device
   unsigned char err,r;
   char mess[10];
   int x;
   InitI2C();
   if (err=setjmp(i2cerror)) {
       if (err==1)
          error("no A/D device found");
       else
          sprintf(mess,"I2C error %d",err);
          error(mess);
       return;
   }
   SendI2CAddress(0x90);    // PCF8591 A/D device address
   WriteI2C(0);             // Set the control port value
   WriteI2C(0);             // and the D/A output
   StopI2C();
   SendI2CAddress(0x91);    // Start the read
   ReadI2C();               // dummy read cycle to do the first conversion
   r=ReadI2C();             // read the result
   StopI2C();
   return r*12.15/118;      // return the battery voltage
}
#endif
