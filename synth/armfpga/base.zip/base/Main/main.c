//*******************************************************
//					ARM FPGA Base driver
//*******************************************************
#include <stdio.h>
#include <stdlib.h>
#include "LPC214x.h"
#include "setup.h"
#include "serial.h"
#include "rprintf.h"
#include "spi0.h"
#include "IO.h"

//*******************************************************
//				Filesystem Libraries
//*******************************************************
#include "rootdir.h"
#include "sd_raw.h"
#include "fat16.h"

//*******************************************************
//				USB Libraries
//*******************************************************
#include "main_msc.h"

//*******************************************************
//				External Hardware Libraries
//*******************************************************
#include "lcd.h"
#include "fpga.h"
#include "cs4270.h"

//*******************************************************
//					Interrupt Functions
//*******************************************************
static void timer0ISR(void);

//*******************************************************
//				Global Variables for Main
//*******************************************************
unsigned int timer0tick;

//The FPGA bitstream file name
#define BS_FILE "FPGA.BIT"

int main (void)
{
	int FPGA_LOADED = 0;
	
	// Initialize ARM I/O
	bootUp();
	
	/* Initialize the LCD display */
	init_lcd();
	write_lcd("ARMFPGA Base", 0);
	
	/* Initialize the FPGA I/O */
	init_fpga();
		
	// Startup msg
	rprintf("ARM FPGA Base Driver v0.1\n");
	
	// Init SD
	if(sd_raw_init())
	{
		// Open the root directory on the SD card
		openroot();
		rprintf("Root open\n");
		
		// Check to see if the bitstream file is in the root directory
		if(root_file_exists(BS_FILE))
		{
			//If we found the bitstream file, load it's contents into the FPGA.
			rprintf("Bitstream found\n");
			write_lcd("Loading FPGA", 1);
			
			/* Load & check for errors */
			if(load_fpga_bs(BS_FILE))
			{
				rprintf("Bitstream load failed\n");
				write_lcd("Load Failed", 1);
			}
			else
			{
				rprintf("Bitstream loaded\n");
				write_lcd("FPGA Ready", 1);
				FPGA_LOADED = 1;
			}
		}
		else
			write_lcd("No Bitstream", 1);
			
	}
	else{
		//Didn't find a card to initialize
		rprintf("No SD Card Detected\n");
		write_lcd("No SD Card", 1);
		delay_ms(250);
	}
	
	/* Setup Codec */
	if(FPGA_LOADED)
	{
		if(!init_cs4270())
		{
			rprintf("Codec initialized\n");
			write_lcd("Codec Ready", 1);
		}
		else
		{
			rprintf("Codec failed to initialize\n");
			write_lcd("Codec hosed", 1);
		}
	}
	
	// Loop forever
	while(1)
	{
		/* Blink LED */
		IOSET1 = LED;
		delay_ms(100);
		IOCLR1 = LED;
		delay_ms(400);
		
		rprintf("tick = %d\r", timer0tick);
		
		/* update LCD*/
		//buffer[0] = i++;
		//i = i > '9' ? '0' : i;
		//buffer[1] = 0;
		//write_lcd(buffer, 1);
	}
    return 0;
}

//Usage: delay_ms(1000);
//Inputs: int count: Number of milliseconds to delay
//The function will cause the firmware to delay for "count" milleseconds.
void delay_ms(int count)
{
    int i;
    count *= 10000;
    for (i = 0; i < count; i++)
        asm volatile ("nop");
}

//Usage: bootUp();
//Inputs: None
//This function initializes the serial port, the SD card, the I/O pins and the interrupts
void bootUp(void)
{
	// Init rprintf to UART 1
    rprintf_devopen(putc_serial1);
    delay_ms(10); //Delay for power to stablize

    //Bring up SD and FAT
    if(!sd_raw_init())
    {
        rprintf("SD Init Error\n");
    }
    if(openroot())
    {
        rprintf("SD OpenRoot Error\n");
    }
     
	//Setup the SD Card I/O Lines
	IODIR0 |= SD_CS;		//SD Card Outputs
		
	//Setup the LED
	IODIR1 |= LED;			//LED as output
	IOCLR1 |= LED;			//Initially off
	
	//Setup the LCD
	IODIR1 |= LCD_BITS;		//Set all LCD data/control as output
	IOCLR1 = LCD_BITS;		//Initially all 0
	
	/* FPGA I/O bits are setup in init_fpga() */
	
	/* CS4270 I2C ifc is setup in init_cs4270 */
	
	//Set the Vbus line as an input
	IODIR0 &= ~(1<<23);

    //Setup the Timer 0 Interrupt
	VPBDIV=1;										// Set PCLK equal to the System Clock	
	VICIntSelect = ~0x10; 							// Timer 0 interrupt is an IRQ interrupt
	VICVectCntl0= 0x24; 							// Use slot 0 for timer 0 interrupt
	VICVectAddr0 = (unsigned int)timer0ISR; 		// Set the address of ISR for slot 0		
	VICIntEnable = 0x10; 							// Enable Timer 0 Interrupts (Don't start sending song data with Timer 1)
	
	//reset tick counter
	timer0tick = 0;
	
	//Configure Timer0
	T0PR = 1000;									//Divide Clock(60MHz) by 1000 for 60kHz PS
	T0TCR |=0X01;									//Enable the clock
	T0CTCR=0;										//Timer Mode
	T0MCR=0x0003;									//Interrupt and Reset Timer on Match
	T0MR0=2400;										//Interrupt on 25Hz
	
	//Setup the SD SPI Port
    S0SPCCR = 64;              											// SCK = 1 MHz, counter > 8 and even
    S0SPCR  = 0x20;                										// Master, no interrupt enable, 8 bits	
	PINSEL0 &= ~((3<<8) | (3<<10) | (3<<12));
	PINSEL0 |= (SCLK_PINSEL | MISO_PINSEL | MOSI_PINSEL);
}

//Usage: None (Automatically Called by FW)
//Inputs: None
//This function is a global interrupt called by a match on the Timer 0 match.
static void timer0ISR(void)
{
	T0IR = 0xFF;			//Clear the timer interrupt
	VICVectAddr =0;			//Update the VIC priorities
	timer0tick++;
}

void reset(void)
{
    // Intentionally fault Watchdog to trigger a reset condition
    WDMOD |= 3;
    WDFEED = 0xAA;
    WDFEED = 0x55;
    WDFEED = 0xAA;
    WDFEED = 0x00;
}
