/* main.c - test fpga bitstream code in non-embedded environment */
/* E. Brombaugh 2-21-2009 */

#include <stdio.h>
#include <stdlib.h>
#include "fpga.h"

/* These are declarations of things that fpga.c uses and we provide stubs */
unsigned int IODIR0;
unsigned int IOSET0;
unsigned int IOCLR0;
unsigned int IOPIN0;

/* The main routine that calls fpga.c */
int main(int argc, char **argv)
{
	if(argc < 2)
	{
		printf("USAGE: %s <filename>\n", argv[0]);
		exit(-1);
	}
	
	load_fpga_bs(argv[1]);
}
