/* fpga.h : FPGA driver code for LPC2148 ARM FPGA board */
/* 02-21-2009, E. Brombaugh                             */

#include "LPC214x.h"
#include "fpga.h"
#include "fat16.h"
#include "rootdir.h"
#include "sd_raw.h"
#include "spi1.h"
#include "rprintf.h"

/* Uncomment this to use bit-bang configuration */
#define CFG_BITBANG

/* Uncomment this to test in Linux */
#define TEST

#define READBUFSIZE 512

/* readbuf MUST be on a word boundary */
unsigned char readbuf[READBUFSIZE];

/* .bit file header */
const unsigned char bit_hdr[] =
{
	0x00, 0x09, 0x0F, 0xF0, 0x0F, 0xF0, 0x0F, 0xF0, 0x0F, 0xF0, 0x00, 0x00, 0x01
};

const char *bit_hdr_strings[] =
{
	"filename",
	"device",
	"date",
	"time"
};

/* delay routine used to time FPGA operations. Time in ns */
void delay_fpga(int time)
{
	int i;
	
	/* scale time for 100 ns/tick */
	time = time / 100;
	
	/* minimum 1 tick */
	time = time < 1 ? 1 : time;
	
	for (i = 0; i < time; i++)	//We are going to count to 10000 "time" number of times
		asm volatile ("nop");	//"nop" means no-operation.  We don't want to do anything during the delay
}

/* set up the FPGA control bits for a 'benign' state */
void init_fpga(void)
{
	/* Leave all GPIO as inputs for now */
	
#ifdef CFG_BITBANG
	/* Set port 0.19 (MOSI) & 0.17 (SCLK) as GPIO output */
	IODIR0 |= (FPGA_MOSI_BIT | FPGA_SCLK_BIT);
	
	/* both data high, clk low at start */
	IOSET0 |= FPGA_MOSI_BIT;
	IOCLR0 |= FPGA_SCLK_BIT;
#else
	/* Hookup SPI1 to Port 0 20:17 */
	PINSEL1 &= ~((3<<2) | (3<<4) | (3<<6) | (3<<8));	// Clear
	PINSEL1 |=  ((2<<2) | (2<<4) | (2<<6) | (2<<8));	// Set to SSP

	/* Setup SSP to drive config data */
    SSPCR0 = 0x0807; // 1/8 (3MHz), CPOL=CPHA=0, SPI, 8-bit
	SSPCR1 = 0x0002; // Master, Enabled, no loopback
    SSPCPSR = 0x02;  // Prescale VPB by 1/2 (24MHz)
	
	/* Wait for SSP to init */
    int blah;
    blah = SSPDR; //GCC warning clear

    while( (SSPSR & (1<<1)) == 0 );
#endif
}

/* load a bitstream file into the FPGA */
int load_fpga_bs(char *bs_fname)
{
#ifdef TEST
	FILE * fd;
#else
    struct fat16_file_struct * fd;
#endif
    int read;
    int j, d, n, ct, header;
	unsigned char *cp, byte;
	
	/* open file or return error*/
	if(!(fd = root_open(bs_fname)))
	{
		rprintf("load_fpga_bs: open file %s failed\n", bs_fname);
		return 1;
	}

/* Write to FPGA or hexdump */
#if 1
	/* Read file & send bitstream via SPI1 */
	ct = 0;
	header = 1;
	rprintf("load_fpga_bs: parsing bitstream\n");
	while( (read=fat16_read_file(fd,(unsigned char*)readbuf,READBUFSIZE)) > 0 )
	{
		/* init pointer to keep track */
		cp = readbuf;
		
		/* are we parsing the header? */
		if(header)
		{
			/* check / skip .bit header */
			for(j=0;j<13;j++)
			{
				if(bit_hdr[j] != *cp++)
				{
					rprintf("load_fpga_bs: .bit header mismatch\n");
					sd_raw_sync();
					fat16_close_file(fd);
					return 1;
				}
			}
			rprintf("load_fpga_bs: found header\n");
		
			/* Skip File header chunks */
			for(j=0;j<4;j++)
			{
				/* get 1 byte chunk desginator (a,b,c,d) */
				d = *cp++;
				
				/* compute chunksize */
				n = *cp++ << 8;
				n += *cp++;
			
				/* print chunk */
				rprintf("load_fpga_bs: chunk %c length %d %s %s\n", d, n, bit_hdr_strings[j], cp);
			
				/* Check device type */
				if(j==1 && strcmp(cp, "3s250evq100"))
				{
					rprintf("load_fpga_bs: Device != 3s250evq100\n");
				}
			
				/* skip chunk */
				cp += n;
			}
	
			/* Skip final chunk designator */
			cp++;
		
			/* compute config data size */
			n =  *cp++ << 24;
			n += *cp++ << 16;
			n += *cp++ << 8;
			n += *cp++;
			rprintf("load_fpga_bs: config size = %d\n", n);
			
			/* no longer processing header */
			header = 0;
			
#ifndef TEST
			/* pulse PROG_B low min 500 ns */
			IODIR0 |= FPGA_PROG_BIT;	// set as output
			IOCLR0 |= FPGA_PROG_BIT;	// drive low
			delay_fpga(1000);			// wait a bit
	
			/* Wait for INIT low */
			rprintf("load_fpga_bs: PROG low, Waiting for INIT low\n");
			while((IOPIN0 & FPGA_INIT_BIT))
			{
				asm volatile ("nop");	//"nop" means no-operation.  We don't want to do anything during the delay
			}
	
			/* Release PROG */
			IODIR0 &= ~FPGA_PROG_BIT;	// set as input (hi-z)
	
			/* Wait for INIT high */
			rprintf("load_fpga_bs: PROG high, Waiting for INIT high\n");
			while(!(IOPIN0 & FPGA_INIT_BIT))
			{
				asm volatile ("nop");	//"nop" means no-operation.  We don't want to do anything during the delay
			}
	
			/* wait 5us */
			delay_fpga(5000);
#endif
		}

		/* Send bitstream */
		while(cp < (readbuf + read))
		{
			/* get next data byte */
			byte = *cp++;
			
#ifdef CFG_BITBANG
			/* Send byte via bit bang */
			for(j=7;j>=0;j--)
			//for(j=0;j<8;j++)
			{
				/* set data bit */
				if(((byte>>j)& 1))
					IOSET0 |= FPGA_MOSI_BIT;
				else
					IOCLR0 |= FPGA_MOSI_BIT;
				
				/* pulse clock */
				IOSET0 |= FPGA_SCLK_BIT;
				IOCLR0 |= FPGA_SCLK_BIT;
				
				/* check 1st 16 bytes of preamble */
				//if((ct==0) && (i<16))
				//{
				//	rprintf("%c", ((readbuf[i]>>j)& 1) ? '1' : '0');
				//	if(((ct+i)%4 == 3) && (j == 0))
				//		rprintf("\n");
				//}
			}
#else
			/* Send buffer via SPI1 */
			SPI1_send(byte);
#endif
			/* diagnostic - dump bitstream as hex */
			if(ct < 512)
			{
				if(ct%16 == 0)
				{
					rprintf("\n%06x : ", ct);
				}
				rprintf("%02x ", byte);
			}
			
			/* inc byte counter */
			ct++;
		}
		
		/* diagnostic to track buffers */
		rprintf(".");
		
#ifndef TEST
		/* Check INIT - if low then fail */
		if(!(IOPIN0 & FPGA_INIT_BIT))
		{
			rprintf("\nload_fpga_bs: INIT low during bitstream send\n");
			sd_raw_sync();
			fat16_close_file(fd);
			return 1;
		}
#endif
	}
	
	/* close file */
	rprintf("\nload_fpga_bs: sent %d of %d bytes\n", ct, n);
	rprintf("load_fpga_bs: bitstream sent, closing file\n");
	sd_raw_sync();
	fat16_close_file(fd);
	
	/* send dummy data while waiting for DONE or !INIT */
 	rprintf("load_fpga_bs: sending dummy clocks, waiting for DONE or fail\n");
	while(!(IOPIN0 & FPGA_DONE_BIT) && (IOPIN0 & FPGA_INIT_BIT))
	{
		/* Dummy - all ones */
#ifdef CFG_BITBANG
		/* set data bit high*/
		IOSET0 |= FPGA_MOSI_BIT;
		
		/* Pulse clock 8x */
		for(j=7;j>=0;j--)
		{
			/* pulse clock */
			IOSET0 |= FPGA_SCLK_BIT;
			IOCLR0 |= FPGA_SCLK_BIT;
		}
#else
		SPI1_send(0xff);
#endif
	}
	
	/* return status */
	if(!(IOPIN0 & FPGA_DONE_BIT))
	{
		rprintf("load_fpga_bs: cfg failed - DONE not high\n");
		return 1;	// Done = 0 - error
	}
	else	
	{
		rprintf("load_fpga_bs: success\n");
		return 0;	// Done = 1 - OK
	}
#else
	/* Hex Dump */
	ct = 0;
	rprintf("load_fpga_bs: INIT found, sending bitstream\n");
	while( (read=fat16_read_file(fd,(unsigned char*)readbuf,READBUFSIZE)) > 0 )
	{
		for(j=0;j<read;j++)
		{
			if(ct == 0)
			{
				if((ct+j)%16 == 0)
				{
					rprintf("\n%06x : ", ct+j);
				}
				rprintf("%02x ", readbuf[j]);
			}
		}
		
		/* count total sent */
		ct += read;
	}
	
	/* close file */
	rprintf("\nload_fpga_bs: read %d of %d bytes\n", ct, n);
	rprintf("load_fpga_bs: closing file\n");
	sd_raw_sync();
	fat16_close_file(fd);
#endif
}
