/* fpga.h : FPGA driver code for LPC2148 ARM FPGA board */
/* 02-21-2009, E. Brombaugh                             */

#ifndef __fat16__
#define __fat16__

#include <stdio.h>
#include <stdlib.h>

FILE *root_open(char* name);
unsigned int fat16_read_file(FILE *fd, unsigned char *buffer, unsigned int buffer_len);
void fat16_close_file(FILE *fd);
//void rprintf(char const *format, ...)
#define rprintf printf
unsigned char sd_raw_sync(void);

#endif
