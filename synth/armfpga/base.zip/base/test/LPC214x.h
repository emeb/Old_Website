/* LPC2148.h - dummy header file for test compiling of I/O routines */
/* 02-23-2009 E. Brombaugh                                          */

#ifndef __LPC2148__
#define __LPC2148__

extern unsigned int IODIR0;
extern unsigned int IOSET0;
extern unsigned int IOCLR0;
extern unsigned int IOPIN0;

#endif
