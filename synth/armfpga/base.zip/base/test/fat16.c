/* fat16.c : dummy file access routines for testing embedded code */
/* 02-21-2009, E. Brombaugh                             */

#include <stdio.h>
#include <stdlib.h>
#include "fat16.h"

/* same as fopen() */
FILE *root_open(char* name)
{
	return fopen(name, "rb");
}

/* same as fread() */
unsigned int fat16_read_file(FILE *fd, unsigned char *buffer, unsigned int buffer_len)
{
	return fread(buffer, sizeof(unsigned char), buffer_len, fd);
}

/* same as close() */
void fat16_close_file(FILE *fd)
{
	fclose(fd);
}

//void rprintf(char const *format, ...)
//{
//}

unsigned char sd_raw_sync(void)
{
	// does nothing
}

