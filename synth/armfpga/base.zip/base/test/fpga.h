/* fpga.h : FPGA driver code for LPC2148 ARM FPGA board */
/* 02-21-2009, E. Brombaugh                             */

#ifndef __fpga__
#define __fpga__

#define FPGA_CSL_BIT (1<<20)	// FPGA SPI CSL bit on Port0.20
#define FPGA_MOSI_BIT (1<<19)	// FPGA SPI MOSI bit on Port0.19
#define FPGA_MISO_BIT (1<<18)	// FPGA SPI MISO bit on Port0.18
#define FPGA_SCLK_BIT (1<<17)	// FPGA SPI SCLK bit on Port0.17
#define FPGA_PROG_BIT (1<<16)	// FPGA PROG_B bit on Port0.16
#define FPGA_IRQ_BIT (1<<15)	// FPGA IRQ bit on Port 0.15
#define FPGA_INIT_BIT (1<<13)	// FPGA INIT bit on Port 0.13
#define FPGA_DONE_BIT (1<<12)	// FPGA DONE bit on Port 0.12

void init_fpga(void);

int load_fpga_bs(char *bs_fname);

#endif
