gcc -g main.c fpga.c fat16.c -o tst_fpga
