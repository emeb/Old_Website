// AnalogOutBuf_1 address and mask defines
#pragma	ioport	AnalogOutBuf_1_Data_ADDR:	0x0
BYTE			AnalogOutBuf_1_Data_ADDR;
#pragma	ioport	AnalogOutBuf_1_DriveMode_0_ADDR:	0x100
BYTE			AnalogOutBuf_1_DriveMode_0_ADDR;
#pragma	ioport	AnalogOutBuf_1_DriveMode_1_ADDR:	0x101
BYTE			AnalogOutBuf_1_DriveMode_1_ADDR;
#pragma	ioport	AnalogOutBuf_1_DriveMode_2_ADDR:	0x3
BYTE			AnalogOutBuf_1_DriveMode_2_ADDR;
#pragma	ioport	AnalogOutBuf_1_GlobalSelect_ADDR:	0x2
BYTE			AnalogOutBuf_1_GlobalSelect_ADDR;
#pragma	ioport	AnalogOutBuf_1_IntCtrl_0_ADDR:	0x102
BYTE			AnalogOutBuf_1_IntCtrl_0_ADDR;
#pragma	ioport	AnalogOutBuf_1_IntCtrl_1_ADDR:	0x103
BYTE			AnalogOutBuf_1_IntCtrl_1_ADDR;
#pragma	ioport	AnalogOutBuf_1_IntEn_ADDR:	0x1
BYTE			AnalogOutBuf_1_IntEn_ADDR;
#define AnalogOutBuf_1_MASK 0x20
