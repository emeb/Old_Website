% create MSB/LSB split sawtooth table for the PSOC 11-bit DAC with 1/2 cycle

tblsz = 256;

tab = floor(920*((0:255)/255) + 0.5);

% mangle it
mag = abs(tab);
sgn = tab<0;

% MSB table
msb = floor(mag/32);
msb = msb + 32*sgn + 128;
disp('SawTabMSB:');
for k=0:tblsz/16-1
    data = 'db ';
    for l=1:16
        data = [data num2str(msb(l+16*k))];
        if l<16
            data = [data ','];
        end
    end
            
    disp([data]);
end

% LSB table
lsb = mod(mag,32);
lsb = lsb + 32*(sgn==0) + 128;
disp('SawTabLSB:');
for k=0:tblsz/16-1
    data = 'db ';
    for l=1:16
        data = [data num2str(lsb(l+16*k))];
        if l<16
            data = [data ','];
        end
    end
            
    disp([data]);
end

% plot results
hold off;
plot(msb, 'r');
hold on;
plot(lsb, 'g');
hold off;
