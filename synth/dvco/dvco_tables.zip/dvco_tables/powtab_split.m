% exptab.m
% compute exponential LUT for VCO

% Constants
Fsamp = 62500;  % Hz
DDS_bits = 24;
Fmin = 20;      % Hz
LUT_bits = 8;
ADC_bits = 11;
ADC_calbits = 16;
ADC_vref = 10.24;

% derived constants
DDS_scale = 2^DDS_bits;
LUT_scale = 2^LUT_bits;
Fmin_scale = DDS_scale * Fmin / Fsamp;
ADC_scale = 2^ADC_bits;
ADC_calscale = 2^ADC_calbits;

% Compute table of powers of 2 between 0 and 1 scaled to min freq
tab = floor(2.^((0:LUT_scale-1)/LUT_scale)*Fmin_scale + 0.5);

% MSB table
msb = floor(tab/256);
disp('PowTabMSB:');
for k=0:LUT_scale/16-1
    data = 'db ';
    for l=1:16
        data = [data num2str(msb(l+16*k))];
        if l<16
            data = [data ','];
        end
    end
            
    disp([data]);
end

% LSB table
lsb = mod(tab,256);
disp('PowTabLSB:');
for k=0:LUT_scale/16-1
    data = 'db ';
    for l=1:16
        data = [data num2str(lsb(l+16*k))];
        if l<16
            data = [data ','];
        end
    end
            
    disp([data]);
end

% Compute ADC calibration factor
ADC_cal = floor(LUT_scale/floor(ADC_scale*(1.0/ADC_vref))*ADC_calscale);

% print out ADC cal as 3 bytes
disp(['ADCcalL: equ ' num2str(mod(ADC_cal, 256))]);
disp(['ADCcalM: equ ' num2str(mod(floor(ADC_cal/256), 256))]);
disp(['ADCcalH: equ ' num2str(mod(floor(ADC_cal/65536), 256))]);

