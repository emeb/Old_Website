/***********************************************************************
 *    Project:        dsPICfun2                                        * 
 *    Author:         Eric Brombaugh                                   *
 *    Company:        KBADC                                            * 
 *    Filename:       main.c                                           *
 *    Date:           12/26/2008                                       *
 *    File Version:   0.03                                             *
 *    Other Files Required:                                            *
 *    Tools Used: MPLAB IDE -> 8.10                                    *
 *                Compiler  -> 3.10                                    *
 *                                                                     *
 *    Devices Supported:                                               *
 *                dsPIC33FJ128GP708                                    *
 *                                                                     *
 *                                                                     *
 ***********************************************************************
 * History:                                                            *
 *                                                                     *
 * V0.0  10/11/2008                                                    *
 *   - Initial                                                         *
 * V0.1  12/21/2008                                                    *
 *   - Added clock switching, ADC ins and DAC SPI test                 *
 * V0.2  12/23/2008                                                    *
 *   - Add LCD drive code                                              *
 * V0.3  12/26/2008                                                    *
 *   - Main timing derived from ADC DMA rate - set to ~48kHz           *
 *   - SPI interrupt driven                                            *
 *   - Fix ADC DMA buffer bugs                                         *
 *   - Display Pot values on LCD                                       *
 *                                                                     *
 **********************************************************************/
#include <p33FJ128GP708.h>
#include "dacdrv.h"
#include "lcd.h"

/************* Configuration Bits **********/
_FBS(BWRP_WRPROTECT_OFF)		// No Boot Protect
_FSS(SWRP_WRPROTECT_OFF)		// No Secure Protect 
_FGS(GSS_OFF)					// No Code Protect
_FOSCSEL(FNOSC_FRC)				// Start with Fast RC
_FOSC(FCKSM_CSECMD & OSCIOFNC_OFF & POSCMD_XT )
//Turn on clock switch, no monitor, OSC2 is XTAL
_FWDT(FWDTEN_OFF)				// Turn off Watchdog Timer
_FPOR(FPWRT_PWR16)				// Power-up Timer to 16msecs
_FICD(ICS_PGD1 & JTAGEN_OFF)	// Use PGC/D 1, no JTAG

/************* START OF GLOBAL DEFINITIONS **********/
unsigned int Tick_Cnt;								// 1kHz System Tick
unsigned int CVin[32] __attribute__((space(dma)));	// CV ADC data buf
unsigned int POTin[16] __attribute__((space(dma)));	// POT ADC data buf
const unsigned int POTmap[4] = {4,3,1,0};			// POT data index

/************** END OF GLOBAL DEFINITIONS ***********/

/* setup hardware */
void init_hw(void)
{
	/* Setup external Xtal OSC & PLL to Fcyc = 39.6MHz */
	// Configure PLL prescaler, PLL postscaler, PLL divisor
	PLLFBD=43;				// M=32
	CLKDIVbits.PLLPOST=0;	// N1=2
	CLKDIVbits.PLLPRE=0;	// N2=2

	// Initiate Clock Switch to Primary Oscillator with PLL (NOSC=0b011)
	__builtin_write_OSCCONH(0x78);
	__builtin_write_OSCCONH(0x9a);
	__builtin_write_OSCCONH(0x03);
	__builtin_write_OSCCONL(0x46);
	__builtin_write_OSCCONL(0x57);
	__builtin_write_OSCCONL(0x01);

	// Wait for Clock switch to occur
	while (OSCCONbits.COSC != 0b011);

	/* Setup Port B bits as outputs for LCD data */
	TRISBbits.TRISB12=0;	// D4
	TRISBbits.TRISB13=0;	// D5
	TRISBbits.TRISB14=0;	// D6
	TRISBbits.TRISB15=0;	// D7
	LATBbits.LATB12=0;
	LATBbits.LATB13=0;
	LATBbits.LATB14=0;
	LATBbits.LATB15=0;

	/* Setup RD14,RD15,RF4,RF5 for LCD ctrl */
	TRISDbits.TRISD14=0;	// RW
	TRISDbits.TRISD15=0;	// E
	TRISFbits.TRISF4=0;		// RS
	TRISFbits.TRISF5=0;		// BRT
	LATDbits.LATD14=0;
	LATDbits.LATD15=0;
	LATFbits.LATF4=0;
	LATFbits.LATF5=0;

	/* Setup RA2,RA3 for diagnostic output */
	TRISAbits.TRISA2=0;		// I2C_SCL - J302-8
	TRISAbits.TRISA3=0;		// I2C_SDA - J302-7
	LATAbits.LATA2=0;
	LATAbits.LATA3=0;
	
	/* Setup Timer 1 @ 1kHz for system tic timing */
	PR1 = 39600;	// timeout period for 1kHz based on 39.6MHz Fcy
	TMR1 = 0;		// Clear timer
	T1CON = 0;		// Tcy, 1:1, async

	/* Setup Timer 8 for LCD timing */
	PR8 = 0;	// time set on the fly as required
	TMR8 = 0;	// Clear timer
	T8CON = 0;	// Default clear
	T8CONbits.TCKPS = 0b01;	// 1:8 ratio

	/* Setup RG9 for SPI2 /ssel */
	TRISGbits.TRISG9 = 0;	// output
	LATGbits.LATG9 = 1;		// active low

	/* Setup SPI port 2 to talk to DAC7554 (SDO2=RG8, SCK2=RG6) */
	SPI2CON1 = 0x043b;	// 16-bit, data chg rise, ck act high, SS, cp, Master, 2:1, 1:1
	SPI2CON2bits.FRMEN = 0;		// no framing	
	SPI2STATbits.SPIROV = 0;	// 
	IFS2bits.SPI2IF = 0;		// Clear SPI2 interrupt
	IEC2bits.SPI2IE = 1;		// Enable SPI2 interrupt
	SPI2STATbits.SPIEN = 1;		// Enable SPI2 port

	/* ADC1 Setup to read CVs */
	AD1CON1 = 0x04E4;	// Scat/Gath, 12-bit, Integer, Auto, Samp
	AD1CON2 = 0x040C;	// Scan, 4 channels, AVDD & AVSS
	AD1CON3 = 0x0f06;	// Tad=Tcy*(ADCS+1)= (1/23M)*5 = 217ns (4.6Mhz)
	AD1CON4 = 0x0000;	// One sample per buffer
	AD1CHS0 = 0;		// Start CHS0 on AN0
	AD1CHS123 = 0;		// CHS123 unused in 12-bit mode
	AD1PCFGL = 0xFFFF;	// AN 0-15 disabled
	AD1PCFGH = 0xFFF0;	// AN 16-19 as Analog CV Input
	AD1CSSL = 0x0000;	// Don't scan AN 0-15
	AD1CSSH = 0x000F;	// Scan AN 16-19
	IFS0bits.AD1IF = 0;	// Clear the A/D interrupt flag bit
	IEC0bits.AD1IE = 0;	// Do Not Enable A/D interrupt
	AD1CON1bits.ADON = 1;	// Turn on the A/D converter
	
	/* DMA0 Setup to handle ADC1 in Scatter/Gather mode */
	DMA0CON = 0x0020;		// Peripheral indirect, Continuous
	DMA0PAD = &ADC1BUF0;	// Get data from ADC1BUF0
	DMA0CNT = 3;			// 4 transfers per interrupt
	DMA0REQ = 13;			// IRQ13 (ADC1) as source
	DMA0STA	= __builtin_dmaoffset(CVin);	// Buffer offset
	IFS0bits.DMA0IF	= 0;	// Clear DMA0IF
	IEC0bits.DMA0IE	= 1;	// Enable DMA0 interrupt
	DMA0CONbits.CHEN = 1;	// Enable DMA0

	/* ADC2 Setup to read Pots */
	AD2CON1 = 0x04E4;	// Scat/Gath, 12-bit, Integer, Auto, Samp
	AD2CON2 = 0x040C;	// Scan, 4 channels, AVDD & AVSS
	AD2CON3 = 0x0f06;	// Tad=Tcy*(ADCS+1)= (1/39.6M)*7 = 217ns (4.6Mhz)
	AD2CON4 = 0x0000;	// One sample per buffer
	AD2CHS0 = 0;		// Start CHS0 on AN0
	AD2CHS123 = 0;		// CHS123 unused in 12-bit mode
	AD2PCFGL = 0xFFE4;	// AN 0,1,3,4 as Analog Pot Input
	AD2CSSL = 0x001B;	// Scan AN 0,1,3,4
	IFS1bits.AD2IF = 0;	// Clear the A/D interrupt flag bit
	IEC1bits.AD2IE = 0;	// Do Not Enable A/D interrupt
	AD2CON1bits.ADON = 1;	// Turn on the A/D converter
	
	/* DMA1 Setup to handle ADC2 in Scatter/Gather mode */
	DMA1CON = 0x0020;		// Peripheral indirect, Continuous
	DMA1PAD = &ADC2BUF0;	// Get data from ADC2BUF0
	DMA1CNT = 3;			// 4 transfers per interrupt
	DMA1REQ = 21;			// IRQ21 (ADC2) as source
	DMA1STA	= __builtin_dmaoffset(POTin);	// Buffer offset
	IFS0bits.DMA1IF	= 0;	// Clear DMA1IF
	IEC0bits.DMA1IE	= 0;	// Disable DMA1 interrupt
	DMA1CONbits.CHEN = 1;	// Enable DMA1

	/* Enable Timer1 Interrupt */
	IPC0bits.T1IP1 = 1;	// Set priority of Timer 1 irq to 6
	IFS0bits.T1IF = 0;	// Clear Timer 1 interrupt
	IEC0bits.T1IE = 1;	// Enable Timer 1 interrupt
	T1CONbits.TON = 1;	// Turn on Timer 1
}

/************* START OF MAIN FUNCTION ***************/

int main ( void )
{
	int i;
	char buffer[17];

	/* Init Tick Count */
	Tick_Cnt = 0;

	/* initialized DAC driver state */
	init_dacdrv();
	
	/* Initialize hardware */
	init_hw();
	
	/* Initialize LCD */
	init_lcd();
	write_lcd("dsPICfun", 0);
	write_lcd("LCD Test", 1);
	brt_lcd(1);

	/* Loop forever */
	while(1)
	{
		if((Tick_Cnt & 0x3f) == 0)
		{
			/* Every 64 ms */
			//itohex(Tick_Cnt, 4, buffer);
			itohex(POTin[POTmap[0]], 3, &buffer[0]);
			buffer[3] = 0x20;
			itohex(POTin[POTmap[1]], 3, &buffer[4]);
			buffer[7] = 0x20;
			itohex(POTin[POTmap[2]], 3, &buffer[8]);
			buffer[11] = 0x20;
			itohex(POTin[POTmap[3]], 3, &buffer[12]);
			write_lcd(buffer, 1);
		}
	}
	
	return 0;
}

/****** START OF INTERRUPT SERVICE ROUTINES *********/

/* Timer 1 ISR runs @ 1kHz */
void __attribute__((interrupt, auto_psv)) _T1Interrupt(void)
{
	IFS0bits.T1IF = 0;			// Clear Timer 1 interrupt
	LATAbits.LATA3=1;			// Diag
	/* Update tick count */
	Tick_Cnt++;
	LATAbits.LATA3=0;
}

/* DMA0 ISR triggered when all 4 CV inputs are digitized */
/* Should happen at 4x ADC period, where ADC period is   */
/* Tcy*(ADCS+1)*(14 + SAMC), or about 5.3us -> 47kHz     */
void __attribute__((interrupt, auto_psv)) _DMA0Interrupt(void)
{
	int i;

	IFS0bits.DMA0IF = 0;	// Clear IRQ
	LATAbits.LATA2 = 1;		// Diag ADC cycle
	
	/* Grab ADC data */
	for(i=0;i<CHANNELS;i++)
		CHLOUT[i] = CVin[i+16];
		//CHLOUT[i] = Tick_Cnt & 0xFFF;

	/* send DAC data */
	dac_tx();

	LATAbits.LATA2 = 0;		// Diag ADC cycle
}

/********* END OF INTERRUPT SERVICE ROUTINES ********/
