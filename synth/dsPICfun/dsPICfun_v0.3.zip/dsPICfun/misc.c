/******************************************************************************/
/* Title: misc.c                                                              */
/*                                                                            */
/* Function: miscellaneous support routines for library functionality         */
/*                                                                            */
/* History: 2008-10-06 E. Brombaugh                                           */
/******************************************************************************/

#include "misc.h"

/* itohex - convert integer to hex string */
/* in is any integer */
/* out is at least 5 char string */
void itohex(int in, int digs, char *out)
{
	int i;
	char digit, *ptr;
	
	ptr = out;
	
	for(i=digs-1;i>=0;i--)
	{
		digit = (in >> i*4) & 0xf;
		digit = digit > 9 ? digit+55 : digit+48;
		*ptr++ = digit;
	}
	*ptr = 0;
}

/* my_strcpy - string copy (unsafe - no limits) */
void my_strcpy(char *dest, char *src)
{
    while(*dest++ = *src++);
}
