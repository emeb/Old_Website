/*...........................................................................*/
/* dacdrv.h - interface routines for 4-chl SPI DAC driver                    */
/* init & access code for DAC driver                                         */
/* 12/21/2008 E. Brombaugh                                                   */
/* 12/26/2008 E. Brombaugh - converted to IRQ driven                         */
/*...........................................................................*/

#ifndef __dacdrv__
#define __dacdrv__

#define CHANNELS 4

volatile extern int CHLOUT[];	// Array of DAC values

void init_dacdrv(void);

void dac_tx(void);

#endif
