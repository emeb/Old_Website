/******************************************************************************/
/* Title: misc.h                                                              */
/*                                                                            */
/* Function: miscellaneous support routines for library functionality         */
/*                                                                            */
/* History: 2008-10-06 E. Brombaugh                                           */
/******************************************************************************/

#ifndef __misc__
#define __misc__

void itohex(int in, int digs, char *out);
void my_strcpy(char *dest, char *src);

#endif
