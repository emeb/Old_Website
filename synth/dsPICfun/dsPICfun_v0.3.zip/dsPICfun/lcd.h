/* lcd.h : LCD driver code for dsPICfun                      */
/* 12-29-2008, E. Brombaugh                                  */

#ifndef __lcd__
#define __lcd__

void init_lcd();
void write_lcd(char *src, int line);
void slc_lcd(int cnt);
void brt_lcd(int brt);

#endif
