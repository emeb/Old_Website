/* lcd.c : LCD driver code for dsPICfun                      */
/* 12-29-2008, E. Brombaugh                                  */

#include <p33FJ128GP708.h>
#include "lcd.h"

/* sets time scaling. Ideally 202, but 102 helps some LCDs */
#define SCALE_LCDTIME(x) ((x)/102)

/* delay routine used to time LCD operations */
void delay_lcd(unsigned int time)
{
	/* wait for time delay */
	PR8 = time;			// set timeout
	TMR8 = 0;			// Clear timer	
	IFS3bits.T8IF = 0;	// Clear IRQ 
	T8CONbits.TON = 1;	// start timer
	while(!IFS3bits.T8IF);	// Wait for IRQ
	IFS3bits.T8IF = 0;	// Clear IRQ 
	T8CONbits.TON = 0;	// stop timer
}

/* Send a nybble to the LCD */
void nybble_lcd(int data, int rs)
{
	int outdat;

	/* Clear E, RW */
	LATDbits.LATD14=0;
	LATDbits.LATD15=0;

	/* Set RS? */
	if(rs)
		LATFbits.LATF4=1;
	else
		LATFbits.LATF4=0;
  
	/* Output data nybble */
	LATB = (PORTB & 0x0FFF) | (data<<12);

	/* Raise enable */
	LATDbits.LATD15=1;

	/* Wait 250ns */
	delay_lcd(SCALE_LCDTIME(250));

	/* drop enable - no explicit delay needed */
	LATDbits.LATD15=0;
}

/* Send a command byte to the LCD */
void cmd_lcd(int cmd)
{
	/* Upper 4 bits */
	nybble_lcd((cmd>>4)&0xf, 0);

	/* Wait 1us */
	delay_lcd(SCALE_LCDTIME(1000));

	/* Lower 4 bits */
	nybble_lcd(cmd&0xf, 0);
}

/* Send a data byte to the LCD */
void data_lcd(int data)
{
	/* Upper 4 bits */
	nybble_lcd((data>>4)&0xf, 1);

	/* Wait 1us */
	delay_lcd(SCALE_LCDTIME(1000));

	/* Lower 4 bits */
	nybble_lcd(data&0xf, 1);
}

/* initialize the LCD */
void init_lcd()
{
	/* Wait 15ms or longer */
	delay_lcd(65535);	// 13.2ms
	delay_lcd(65535);	// 13.2ms

	/* Write SF_D<11:8> = 0x3, pulse LCD_E High 240ns */
	nybble_lcd(3, 0);

	/* Wait 4.1ms or longer */
	delay_lcd(SCALE_LCDTIME(4100000));

	/* Write SF_D<11:8> = 0x3, pulse LCD_E High 240ns */
	nybble_lcd(3, 0);

	/* Wait 100us or longer */
	delay_lcd(SCALE_LCDTIME(100000));

	/* Write SF_D<11:8> = 0x3, pulse LCD_E High 240ns */
	nybble_lcd(3, 0);

	/* Wait 40us or longer */
	delay_lcd(SCALE_LCDTIME(40000));

	/* Write SF_D<11:8> = 0x2, pulse LCD_E High 240ns */
	nybble_lcd(2, 0);

	/* Wait 40us or longer */
	delay_lcd(SCALE_LCDTIME(40000));

	/* Function Set command */
	cmd_lcd(0x28);

	/* Wait 40us or longer */
	delay_lcd(SCALE_LCDTIME(40000));

	/* Entry mode command */
	cmd_lcd(0x06);

	/* Wait 40us or longer */
	delay_lcd(SCALE_LCDTIME(40000));

	/* Display on, cursor on */
	cmd_lcd(0x0E);

	/* Wait 40us or longer */
	delay_lcd(SCALE_LCDTIME(40000));
}

/* Send an ASCII string to the LCD */
void write_lcd(char *src, int line)
{
	int cnt = 20;

	switch(line&3)
	{
		/* DD Address 0 */
		case 0:
			cmd_lcd(0x80);
			break;
    
		/* DD Address 0x40 */
		case 1:
			cmd_lcd(0xC0);
			break;
    
		/* DD address 0x14 */
		case 2:
			cmd_lcd(0x94);
			break;
    
		/* DD address 0x54 */
		case 3:
			cmd_lcd(0xD4);
			break;
	}

	/* Wait 40us or longer */
	delay_lcd(SCALE_LCDTIME(40000));

	/* loop until end of string or 20 chars */
	while(cnt-- > 0)
	{
		if(*src!=0)
			data_lcd(*src++); /* send char */
		else
			data_lcd(0x20); /* send space */
    
		/* Wait 40 ?s or longer */
		delay_lcd(SCALE_LCDTIME(40000));
	}
}

/* Shift cursor left */
void slc_lcd(int cnt)
{
	while(cnt-- >0)
	{
		/* shift cursor left one char */
		cmd_lcd(0x10);

		/* Wait 40 ?s or longer */
		delay_lcd(SCALE_LCDTIME(40000));
	}
}

/* Control LCD Brightness */
void brt_lcd(int brt)
{
	if(brt)
		LATFbits.LATF5=1;
	else
		LATFbits.LATF5=0;
}
