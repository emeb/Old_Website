/*...........................................................................*/
/* dacdrv.c - interface routines for 4-chl SPI DAC driver                    */
/* init & access code for DAC driver                                         */
/* 12/21/2008 E. Brombaugh                                                   */
/* 12/26/2008 E. Brombaugh - converted to IRQ driven                         */
/*...........................................................................*/

#include <p33FJ128GP708.h>
#include "dacdrv.h"

volatile int CHLOUT[4];	// Array of DAC values
int CHLST;				// DAC Channel send state

/* Initialize DAC driver */
void init_dacdrv(void)
{
	int i;

	/* init variables */
	for(i=0;i<4;i++)
		CHLOUT[i] = 0x800;

	CHLST = 0;
}

/* Send data to DAC */
void dac_tx(void)
{
	int tx;

	if(CHLST == 0)	/* Check that we're not already sending */
	{
		/* Build DAC data word */
		tx = CHLOUT[0] & 0xfff | 0x8000;

		/* Start sending DAC data via SPI2 */
		LATGbits.LATG9 = 0;		// Drop CS
		SPI2BUF = tx;			// Send first channel
		CHLST++;				// set running flag, points to next data
	}
}

/****** START OF INTERRUPT SERVICE ROUTINES *********/

/* SPI2 ISR triggered when SPI finishes sending a word */
void __attribute__((interrupt, auto_psv)) _SPI2Interrupt(void)
{
	int tx;

	/* Clear previous transaction */
	IFS2bits.SPI2IF = 0;	// Clear SPI2 interrupt
	LATGbits.LATG9 = 1;		// raise CS
	tx = SPI2BUF;			// Dummy Read RX result

	if(CHLST < 4)	/* are we done? */
	{
		/* Build DAC data word */
		tx =	CHLOUT[CHLST] & 0xfff |		// Data
				((CHLST++ & 0x03)<<12) |	// Channel
				0x8000;						// Update output

		/* Start sending next word */
		LATGbits.LATG9 = 0;		// Drop CS
		SPI2BUF = tx;			// Send next channel
	}
	else
	{
		/* Stop & Reset */
		CHLST = 0;
	}
}

/********* END OF INTERRUPT SERVICE ROUTINES ********/
