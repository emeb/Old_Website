/***********************************************************************
 * cmd.c - Command parsing                                             *
 *    Project:        fpga1                                            * 
 *    Author:         Eric Brombaugh                                   *
 *    Company:        KBADC                                            * 
 *    Date:           01/16/2010                                       *
 *    File Version:   0.0                                              *
 **********************************************************************/
#include <p33FJ128GP204.h>
#include <stdio.h>
#include <string.h>
#include "FSIO.h"
#include "rprintf.h"
#include "fpga.h"
#include "uart.h"
#include "cmd.h"
#include "adc.h"
#include "flash.h"

char cmd_buffer[256];
char *cmd_wptr;
const char *cmd_commands[] = 
{
	"help",
	"dir",
	"cfg_fpga",
	"spi_read",
	"spi_write",
	"get_cv",
	"get_flash_status",
	"get_flash_security",
	"get_flash_page",
	"flash_write_page",
	""
};

void cmd_prompt(void)
{
	/* reset input buffer */
	cmd_wptr = &cmd_buffer[0];

	/* prompt user */
	U1printstring("\r\n\nCommand>");
}

/* SD filesystem directory */
void cmd_dir(char *name)
{
	int result;
	SearchRec rec;

	if((result = FindFirst(name, ATTR_MASK, &rec)))
	{
		U1printstring("File Not Found\r\n");
	}
	else
	{
		while(!result)
		{
			rprintf("%s\r\n", rec.filename);
			result = FindNext(&rec);
		}
	}
}

/* process command line after cr */
void cmd_proc(void)
{
	char *token, *argv[3];
	int argc, cmd, reg;
	unsigned long data;

	/* parse out three tokens: cmd arg arg */
	argc = 0;
	token = strtok(cmd_buffer, " ");
	while(token != NULL && argc < 3)
	{
		argv[argc++] = token;
		token = strtok(NULL, " ");
	}

	/* figure out which command it is */
	if(argc > 0)
	{
		cmd = 0;
		while(cmd_commands[cmd] != '\0')
		{
			if(strcmp(argv[0], cmd_commands[cmd])==0)
				break;
			cmd++;
		}
	
		/* Can we handle this? */
		if(cmd_commands[cmd] != '\0')
		{
			U1printstring("\r\n");

			/* Handle commands */
			switch(cmd)
			{
				case 0:		/* Help */
					U1printstring("help - this message\r\n");
					U1printstring("dir [<spec>] - SD Card directory\r\n");
					U1printstring("cfg_fpga <file> - Configure FPA with file\r\n");
					U1printstring("spi_read <reg> - FPGA SPI read reg\r\n");
					U1printstring("spi_write <reg> <data> - FPGA SPI write reg, data\r\n");
					U1printstring("get_cv <reg> - Get CV data\r\n");
					U1printstring("get_flash_status - Get Flash Status reg\r\n");
					U1printstring("get_flash_security - Get Flash Security reg\r\n");
					U1printstring("get_flash_page <reg> - Get Flash Page\r\n");
					U1printstring("flash_write_page <reg> - Test Write Flash Page\r\n");
					break;
	
				case 1: 	/* dir */
					if(argc < 2)
					{
						U1printstring("dir *.*\r\n");
						cmd_dir("*.*");
					}
					else
					{
						rprintf("dir %s\r\n", argv[1]);
						cmd_dir(argv[1]);
					}
					break;
	
				case 2: 	/* cfg_fpga */
					if(argc < 2)
						U1printstring("cfg_fpga - missing filename\r\n");
					else
					{
						rprintf("cfg_fpga %s\r\n", argv[1]);
						load_fpga_bs(argv[1]);
					}
					break;
	
				case 3: 	/* spi_read */
					if(argc < 2)
						U1printstring("spi_read - missing arg(s)\r\n");
					else
					{
						reg = (int)strtoul(argv[1], NULL, 0) & 0x7f;
						data = fpga_spi_read(reg);
						rprintf("spi_read: 0x%02X = 0x%08lX\r\n", reg, data);
					}
					break;
	
				case 4: 	/* spi_write */
					if(argc < 3)
						U1printstring("spi_write - missing arg(s)\r\n");
					else
					{
						reg = (int)strtoul(argv[1], NULL, 0) & 0x7f;
						data = strtoul(argv[2], NULL, 0);
						fpga_spi_write(reg, data);
						rprintf("spi_write: 0x%02X 0x%08lX\r\n", reg, data);
					}
					break;

				case 5: 	/* get_cv */
					if(argc < 2)
						U1printstring("get_cv - missing arg(s)\r\n");
					else
					{
						reg = (int)strtoul(argv[1], NULL, 0) & 0xf;
						//rprintf("get_cv: 0x%02X = %d\r\n", reg, ADC_buff[reg]);
						rprintf("get_cv: 0x%02X = %d\r\n", reg, cv_dat[reg&3]);
					}
					break;
	
				case 6: 	/* get_flash_status */
					rprintf("get_flash_status: = 0x%02X\r\n", flash_get_status());
					break;
	
				case 7: 	/* get_flash_security */
					U1printstring("get_flash_security:\r\n");
					{
						char buffer[128];
						int i;

						flash_get_security(buffer);
						for(i=0;i<128;i++)
						{
							rprintf("%02X ", buffer[i]&0xff);
							if(i%16 == 15)
								U1printstring("\r\n");
						}
					}
					break;
	
				case 8: 	/* get_flash_page */
					if(argc < 2)
						U1printstring("get_flash_page - missing arg(s)\r\n");
					else
					{
						char buffer[528];
						int i;

						reg = (int)strtoul(argv[1], NULL, 0) & 0x1fff;
						rprintf("get_flash_page: 0x%04X\r\n", reg);
						flash_cont_read(reg, 0, 528, buffer);
						for(i=0;i<528;i++)
						{
							rprintf("%02X ", buffer[i]&0xff);
							if(i%16 == 15)
								U1printstring("\r\n");
						}
						U1printstring("\r\n");
					}
					break;
	
				case 9: 	/* flash_write_page */
					if(argc < 2)
						U1printstring("flash_write_page - missing arg(s)\r\n");
					else
					{
						char buffer[528];
						int i;

						reg = (int)strtoul(argv[1], NULL, 0) & 0x1fff;
						rprintf("flash_write_page: 0x%04X\r\n", reg);
						for(i=0;i<528;i++)
							buffer[i] = i&0xFF;
						flash_buffer_write(0, 528, buffer);
						flash_buffer_page_write_erase(reg);
						U1printstring("\r\n");
					}
					break;
	
				default:	/* shouldn't get here */
					break;
			}
		}
		else
			U1printstring("Unknown command\r\n");
	}
}
	
void init_cmd(void)
{
	/* just prompts for now */
	cmd_prompt();
}

void cmd_parse(char ch)
{
	/* accumulate chars until cr, handle backspace */
	if(ch == '\b')
	{
		/* check for buffer underflow */
		if(cmd_wptr - &cmd_buffer[0] > 0)
		{
			U1printstring("\b \b");		/* Erase & backspace */
			cmd_wptr--;		/* remove previous char */
		}
	}
	else if(ch == '\r')
	{
		*cmd_wptr = '\0';	/* null terminate, no inc */
		cmd_proc();
		cmd_prompt();
	}
	else
	{
		/* check for buffer full (leave room for null) */
		if(cmd_wptr - &cmd_buffer[0] < 254)
		{
			*cmd_wptr++ = ch;	/* store to buffer */
			U1putc(ch);			/* echo */
		}
	}
}
