/* Bare-bones I2S setup code for F105 Quad DAC board              */
/* E. Brombaugh 01-31-2014                                        */

#include "stm32f10x.h"

#define BUFSZ 64

I2S_InitTypeDef I2S_InitStructure;
DMA_InitTypeDef DMA_InitStructure;
ADC_InitTypeDef ADC_InitStructure;
USART_InitTypeDef USART_InitStructure;

__IO int16_t I2S2_Buffer_Tx[BUFSZ], I2S3_Buffer_Tx[BUFSZ];
__IO uint16_t ADC1_Buffer[16], ADC1_Copy[16];
__IO uint16_t ADC1_DRdy;
int32_t i;

__IO uint32_t Freq[4], Phs[4];
uint16_t uart_dly;

void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);

int main(void)
{
	/* System clocks configuration ------------------------------------------*/
	RCC_Configuration();

	/* NVIC configuration ---------------------------------------------------*/
	NVIC_Configuration();

	/* GPIO configuration ---------------------------------------------------*/
	GPIO_Configuration();
	
	/* USART configuration --------------------------------------------------*/
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_Init(USART1, &USART_InitStructure);
	USART_Cmd(USART1, ENABLE);
	uart_dly = 0;
	
	/* DMA1 channel1 configuration ------------------------------------------*/
	DMA_DeInit(DMA1_Channel1);
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->DR;
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&ADC1_Buffer;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStructure.DMA_BufferSize = 8;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA1_Channel1, &DMA_InitStructure);

	/* Enable DMA1 channel1 */
	DMA_Cmd(DMA1_Channel1, ENABLE);

	/* ADC1 configuration ---------------------------------------------------*/
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_NbrOfChannel = 8;
	ADC_Init(ADC1, &ADC_InitStructure);

	/* ADC1 regular channel configuration */ 
	ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_71Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 2, ADC_SampleTime_71Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 3, ADC_SampleTime_71Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_3, 4, ADC_SampleTime_71Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_4, 5, ADC_SampleTime_71Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_5, 6, ADC_SampleTime_71Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_6, 7, ADC_SampleTime_71Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_7, 8, ADC_SampleTime_71Cycles5);

	/* Enable ADC1 DMA */
	ADC_DMACmd(ADC1, ENABLE);

	/* Enable ADC1 */
	ADC_Cmd(ADC1, ENABLE);

	/* Enable ADC1 reset calibration register */   
	ADC_ResetCalibration(ADC1);
	/* Check the end of ADC1 reset calibration register */
	while(ADC_GetResetCalibrationStatus(ADC1));

	/* Start ADC1 calibration */
	ADC_StartCalibration(ADC1);
	/* Check the end of ADC1 calibration */
	while(ADC_GetCalibrationStatus(ADC1));
	
	/* clear the ready flag */
	ADC1_DRdy = 0;
	
	/* Start ADC1 Software Conversion */ 
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);

	/* set up frequency & phase arrays */
	Freq[0] = 0x00101000;
	Freq[1] = 0x00503000;
	Freq[2] = 0x00510000;
	Freq[3] = 0x01100010;
	Phs[0] = 0;
	Phs[1] = 0;
	Phs[2] = 0;
	Phs[3] = 0;
	
	/* stuff the buffers */
	for(i=0;i<32;i++)
	{
		I2S2_Buffer_Tx[i] = 0;
		I2S3_Buffer_Tx[i] = 0;
	}

	/* DMA1 channel4 configuration */
	DMA_DeInit(DMA1_Channel5);
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&SPI2->DR;
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&I2S2_Buffer_Tx;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = BUFSZ;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA1_Channel5, &DMA_InitStructure);
	DMA_ITConfig(DMA1_Channel5, DMA_IT_TC | DMA_IT_HT, ENABLE);
	DMA_Cmd(DMA1_Channel5, ENABLE);

	/* I2S3 peripheral configuration */
	SPI_I2S_DeInit(SPI2);

	I2S_InitStructure.I2S_Standard = I2S_Standard_Phillips;
	I2S_InitStructure.I2S_DataFormat = I2S_DataFormat_16b;
	I2S_InitStructure.I2S_MCLKOutput = I2S_MCLKOutput_Enable;
	I2S_InitStructure.I2S_AudioFreq =  I2S_AudioFreq_96k;
	I2S_InitStructure.I2S_CPOL = I2S_CPOL_Low;
	I2S_InitStructure.I2S_Mode = I2S_Mode_MasterTx;

	I2S_Init(SPI2, &I2S_InitStructure);

	/* Enable the Tx DMA request */
	SPI_I2S_DMACmd(SPI2, SPI_I2S_DMAReq_Tx, ENABLE);

	/* DMA1 channel4 configuration */
	DMA_DeInit(DMA2_Channel2);
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&SPI3->DR;
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&I2S3_Buffer_Tx;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = BUFSZ;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA2_Channel2, &DMA_InitStructure);
	DMA_ITConfig(DMA2_Channel2, DMA_IT_TC | DMA_IT_HT, ENABLE);
	DMA_Cmd(DMA2_Channel2, ENABLE);

	/* I2S3 peripheral configuration */
	SPI_I2S_DeInit(SPI3);

	I2S_InitStructure.I2S_Standard = I2S_Standard_Phillips;
	I2S_InitStructure.I2S_DataFormat = I2S_DataFormat_16b;
	I2S_InitStructure.I2S_MCLKOutput = I2S_MCLKOutput_Enable;
	I2S_InitStructure.I2S_AudioFreq =  I2S_AudioFreq_96k;
	I2S_InitStructure.I2S_CPOL = I2S_CPOL_Low;
	I2S_InitStructure.I2S_Mode = I2S_Mode_MasterTx;

	I2S_Init(SPI3, &I2S_InitStructure);

	/* Enable the Tx DMA request */
	SPI_I2S_DMACmd(SPI3, SPI_I2S_DMAReq_Tx, ENABLE);

	/* Enable the I2S ports */
	I2S_Cmd(SPI2, ENABLE);
	I2S_Cmd(SPI3, ENABLE);

	/* Wait forever */
	while (1)
	{
		/* wait for I2S routines to run */
		while(ADC1_DRdy == 0) {}
	
		/* Active ISR */
		GPIOB->BSRR = 1<<7;	/* TxD, J6-4 */
	
		/* Frequency Updates */

		/* Clear ready flag for next go-around */
		ADC1_DRdy = 0;
		
		/* Inactive ISR */
		GPIOB->BRR = 1<<7;
		
		/* Send a status char? */
		if(uart_dly == 0)
		{
			/* Data register empty? */
			if(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == SET)
			{
				/* Yes, send it */
				USART_SendData(USART1, 'A');
				
				/* reset delay counter */
				uart_dly = 999;
			}
		}
		else
			uart_dly--;	/* count down */
		
		/* blink on-board LEDs */
		if(uart_dly & 512)
			GPIOB->BSRR = 1<<8;	/* Blue LED on */
		else
			GPIOB->BRR = 1<<8;	/* Blue LED off */
		if(uart_dly & 256)
			GPIOB->BSRR = 1<<9;	/* Green LED on */
		else
			GPIOB->BRR = 1<<9;	/* Green LED off */
		
		/* Go to sleep until next IRQ */
		//asm("wfi");
	}
}

/**
  * @brief  Configures the different system clocks.
  * @param  None
  * @retval None
  */
void RCC_Configuration(void)
{
	/* RCC system reset(for debug purpose) */
	RCC_DeInit();

	/* Enable HSE */
	RCC_HSEConfig(RCC_HSE_ON);

	/* Wait till HSE is ready */
	if(RCC_WaitForHSEStartUp() == SUCCESS)
	{
		/* Enable Prefetch Buffer */
		FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

		/* Flash 2 wait state */
		FLASH_SetLatency(FLASH_Latency_2);

		/* HCLK = SYSCLK */
		RCC_HCLKConfig(RCC_SYSCLK_Div1); 

		/* PCLK2 = HCLK */
		RCC_PCLK2Config(RCC_HCLK_Div1); 

		/* PCLK1 = HCLK/2 */
		RCC_PCLK1Config(RCC_HCLK_Div2);

		/* ADCCLK = PCLK2/4 */
		RCC_ADCCLKConfig(RCC_PCLK2_Div4); 

		/* Configure PLLs ****************************************************/
		/* PLL2 configuration: PLL2CLK = (HSE / 2) * 10 = 40 MHz */
		RCC_PREDIV2Config(RCC_PREDIV2_Div2);
		RCC_PLL2Config(RCC_PLL2Mul_10);

		/* Enable PLL2 */
		RCC_PLL2Cmd(ENABLE);

		/* Wait till PLL2 is ready */
		while (RCC_GetFlagStatus(RCC_FLAG_PLL2RDY) == RESET)
		{
		}

		/* PLL configuration: PLLCLK = (PLL2 / 5) * 9 = 72 MHz */ 
		RCC_PREDIV1Config(RCC_PREDIV1_Source_PLL2, RCC_PREDIV1_Div5);
		RCC_PLLConfig(RCC_PLLSource_PREDIV1, RCC_PLLMul_9);

		/* PLL3 configuration: PLL3CLK = (HSE / 2) * 14 = PLL3_VCO = 112 MHz */
		RCC_PLL3Config(RCC_PLL3Mul_14);

		/* Enable PLL3 */
		RCC_PLL3Cmd(ENABLE);

		/* Wait till PLL3 is ready */
		while (RCC_GetFlagStatus(RCC_FLAG_PLL3RDY) == RESET)
		{
		}

		/* Configure I2S clock source: On Connectivity Line Devices, the I2S
			can be clocked by PLL3 VCO instead of SYS_CLK in order to
			guarantee higher precision */
		RCC_I2S3CLKConfig(RCC_I2S3CLKSource_PLL3_VCO);
		RCC_I2S2CLKConfig(RCC_I2S2CLKSource_PLL3_VCO);  

		/* Enable PLL */ 
		RCC_PLLCmd(ENABLE);

		/* Wait till PLL is ready */
		while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
		{
		}

		/* Select PLL as system clock source */
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

		/* Wait till PLL is used as system clock source */
		while(RCC_GetSYSCLKSource() != 0x08)
		{
		}
	}  

	/* DMA clock enable */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1 | RCC_AHBPeriph_DMA2 |
							RCC_AHBPeriph_CRC, ENABLE);

	/* Enable peripheral clocks ---------------------------------------------*/
	/* GPIOA, GPIOB, GPIOC, AFIO, USART1 and ADC1 clocks enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |
							RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO | 
							RCC_APB2Periph_ADC1 | RCC_APB2Periph_USART1,
							ENABLE);

	/* SPI3 and SPI2 clocks enable */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3 | RCC_APB1Periph_SPI2, ENABLE);
}

/**
  * @brief  Configures the different GPIO ports.
  * @param  None
  * @retval None
  */
void GPIO_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* Disable the JTAG interface and enable the SWJ interface */
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);

	/* Configure SPI2 pins: CK, WS and SD -----------------------------------*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	/* Configure SPI3 pins: CK and SD ---------------------------------------*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_5;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	/* Configure SPI3 pins: WS ----------------------------------------------*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/* Configure MCLK pins: -------------------------------------------------*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	/* Configure PB.8, PB.9 as output push-pull (LED) -----------------------*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

#if 0
	/* Configure PB.6, PB.7 as output push-pull (diags) ---------------------*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
#else
	/* Configure PB.6, PB.7 as output push-pull (USART1) --------------------*/
	GPIO_PinRemapConfig(GPIO_Remap_USART1, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
#endif

	/* Configure PA.0 - PA.7 (ADC Channel0-7) as analog inputs --------------*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | 
							GPIO_Pin_3 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

/**
  * @brief  Configure the nested vectored interrupt controller.
  * @param  None
  * @retval None
  */
void NVIC_Configuration(void)
{
	NVIC_EnableIRQ(DMA1_Channel5_IRQn);
	NVIC_EnableIRQ(DMA2_Channel2_IRQn);
}

/**
  * @brief  Fill a buffer of L/R samples with data from 2 oscillators
  * @param  *offset: pointer to the start of the 16-sample buffer
  * @param  osc: index into the oscillator array
  * @retval None
  */
void BufferFill(__IO int16_t *offset, uint16_t osc)
{
	for(i=0;i<BUFSZ/2;i+=2)
	{
		// L oscillator
		Phs[osc] += Freq[osc];
		*offset++ = Phs[osc] >> 16;
		
		// R oscillator
		Phs[osc+1] += Freq[osc+1];
		*offset++ = Phs[osc+1] >> 16;
	}
}

/**
  * @brief  This function handles DMA1_Channel5 (I2S2) interrupt request.
			It is the first of the two I2S ISRs to run.
  * @param  None
  * @retval None
  */
void DMA1_Channel5_IRQHandler(void)
{
	/* Active ISR */
	GPIOB->BSRR = 1<<6;	/* RxD, J6-5 */

	/* which interrupt? */
	uint32_t temp = (DMA1->ISR & 0xF0000)>>16;

	/* Clear DMA1_Channel5 interrupt */
	DMA1->IFCR = DMA_IFCR_CGIF5;

	/* Toggle bit */
	if(temp&0x04)
	{
		/* Half transfer - refill 1st half buffer*/
		BufferFill(&I2S2_Buffer_Tx[0], 0);
	}
	else
	{
		/* Transfer complete - refill 2nd half buffer */
		BufferFill(&I2S2_Buffer_Tx[BUFSZ/2], 0);
	}
	
	/* Inactive ISR */
	GPIOB->BRR = 1<<6;
}

/**
  * @brief  This function handles DMA2_Channel2 (I2S3) interrupt request.
			It is the last of the two I2S ISRs to run.
  * @param  None
  * @retval None
  */
void DMA2_Channel2_IRQHandler(void)
{
	/* Active ISR */
	//GPIOB->BSRR = 1<<7;	/* TxD, J6-4 */

	/* which interrupt? */
	uint32_t temp = (DMA2->ISR & 0xF0)>>4;

	/* Clear DMA2_Channel2 interrupt */
	DMA2->IFCR = DMA_IFCR_CGIF2;

	/* Toggle bit */
	if(temp&0x04)
	{
		/* Half transfer - refill 1st half buffer*/
		BufferFill(&I2S3_Buffer_Tx[0], 2);
	}
	else
	{
		/* Transfer complete - refill 2nd half buffer */
		BufferFill(&I2S3_Buffer_Tx[BUFSZ/2], 2);
	}
	
	/* Tell main loop to process ADC data */
	ADC1_DRdy = 1;
	
	/* Inactive ISR */
	//GPIOB->BRR = 1<<7;
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {}
}

#endif

/**
  * @}
  */ 

/**
  * @}
  */

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
