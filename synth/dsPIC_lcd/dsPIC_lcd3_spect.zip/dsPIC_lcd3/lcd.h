/***********************************************************************
* lcd.h - Interface routines for Goldmine LCD                          *
* 09/15/2009 - E. Brombaugh                                            *
***********************************************************************/
#ifndef __lcd__
#define __lcd__

/* LCD Interface bits in LATB */
#define CS1B	LATBbits.LATB15
#define RESETB	LATBbits.LATB14
#define RS		LATBbits.LATB13

void spi_send(unsigned char data);
void lcd_send_cmd(unsigned char data);
void lcd_send_data(unsigned char data);
void lcd_init();
void lcd_fill(unsigned char bits);
void lcd_send_bitmap(unsigned char *bitmap);

#endif


