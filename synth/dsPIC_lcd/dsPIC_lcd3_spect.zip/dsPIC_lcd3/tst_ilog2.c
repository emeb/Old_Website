/* tst_ilog2.c - test integer log2() function */
/* 09-22-09 E. Brombaugh                      */

#include <stdio.h>
#include <math.h>

/* integer log2() scaled so 512 => 64 */
int ilog2(int x)
{
	int ex, ma, y;
	
	/* find msb - exponent */
	for(ex=9;ex>2;ex--)
	{
		if(x&256)
			break;
		x<<=1;
	}
	
	/* mask off mantissa */
	ma = (x>>5)&7;
	
	/* build output */
	y = ((ex<<3) | ma)-16;
	return y;
}

int main(int argc, char **argv)
{
	int x, y;
	
	for(x=0;x<512;x++)
		fprintf(stdout, "% 4d  % 3d\n", x, ilog2(x));
}
