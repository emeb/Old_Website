/*...........................................................................*/
/* timing.h - interface routines for 1kHz system time tick                   */
/* 12/27/2008 E. Brombaugh                                                   */
/*...........................................................................*/

#ifndef __timing__
#define __timing__

extern unsigned int Tick_Cnt;

void init_timing(void);
unsigned int get_tick();
int diff_tick(unsigned int prev);
void dly_tick(unsigned int ticks);

#endif
