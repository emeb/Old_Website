% bh4-window.m - spit out an n-sample BH4 window for use in FFT
	
sz = 128;

% compute omega vector for window
w = 2*pi*(0:sz-1)'/sz;

% generate a 4-term BH window
bh4 = (0.35875 - 0.48829 * cos(w) + 0.14128 * cos(2.0 * w) - 0.01168 * cos(3.0 *
 w))/0.36;

% scale it up to +/- 32767 & convert to int
bh4 = floor((bh4./(max(bh4))) * (2^15-1) + 0.5);

% print out as a C array
ofile = fopen("window.h", "w");

fprintf(ofile, "int window[] =\n{\n");

for x = 0:8:120
	fprintf(ofile, "\t");
	for y = 1:8
		if (x==120) & (y==8)
			fprintf(ofile, "0x%04x", bh4(x+y));
		else
			fprintf(ofile, "0x%04x, ", bh4(x+y));
		end
	end
	fprintf(ofile, "\n");
end
fprintf(ofile, "};\n");
fclose(ofile);

