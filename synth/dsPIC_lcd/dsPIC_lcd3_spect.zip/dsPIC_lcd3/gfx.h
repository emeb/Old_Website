/***********************************************************************
* gfx.h - Graphics primitives                                          *
* 09/15/2009 - E. Brombaugh                                            *
***********************************************************************/
#ifndef __gfx__
#define __gfx__

void gfx_refresh(void);
void gfx_fill(unsigned char pattern);
void gfx_put(unsigned char *map);
void gfx_get(unsigned char *map);
void gfx_plot(char x, char y, char mode);
void gfx_rect_empty(char x0, char y0, char x1, char y1, char mode);
void gfx_rect_fill(char x0, char y0, char x1, char y1, char mode);
void gfx_line(char x0, char y0, char x1, char y1, char mode);
void gfx_putchar(char x, char y, char c, char mode);
void gfx_putstr(char x, char y, char *c, char mode);

#endif
