/***********************************************************************
* font.h - font lookup code                                            *
* 09/23/2009 - E. Brombaugh                                            *
***********************************************************************/
#ifndef __font__
#define __font__
extern long getfont(int val);
#endif
