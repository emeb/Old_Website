/******************************************************************************/
/* Title: misc.c                                                              */
/*                                                                            */
/* Function: miscellaneous support routines for library functionality         */
/*                                                                            */
/* History: 2008-10-06 E. Brombaugh                                           */
/******************************************************************************/

#include "misc.h"

/* itohex - convert integer to hex string */
/* in is any integer */
/* out is at least 5 char string */
void itohex(int in, int digs, char *out)
{
	int i;
	char digit, *ptr;
	
	ptr = out;
	
	for(i=digs-1;i>=0;i--)
	{
		digit = (in >> i*4) & 0xf;
		digit = digit > 9 ? digit+55 : digit+48;
		*ptr++ = digit;
	}
	*ptr = 0;
}

/* reverse:  reverse string s in place */
void reverse(char s[])
{
    int c, i, j;

    for (i = 0, j = strlen(s)-1; i<j; i++, j--) {
        c = s[i];
        s[i] = s[j];
        s[j] = c;
    }
}

/* itoa:  convert n to characters in s */
void itoa(int n, char s[])
{
    int i, sign;

    if ((sign = n) < 0)  /* record sign */
        n = -n;          /* make n positive */
    i = 0;
    do {       /* generate digits in reverse order */
        s[i++] = n % 10 + '0';   /* get next digit */
    } while ((n /= 10) > 0);     /* delete it */
    if (sign < 0)
        s[i++] = '-';
    s[i] = '\0';
    reverse(s);
} 

/* my_strcpy - string copy (unsafe - no limits) */
void my_strcpy(char *dest, char *src)
{
    while(*dest++ = *src++);
}
