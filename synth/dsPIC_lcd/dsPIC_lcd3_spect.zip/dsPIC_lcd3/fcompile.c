/* Font Compiler Util */
/* Originally from Pilot VT100 utility source */
/* Converted for dsPIC_lcd3 by E. Brombaugh, 9-23-09 */

#include <stdio.h>
#include <stdlib.h>

#define WIDTH 4
#define HEIGHT 6
#define CCOUNT 128
#define CPERLINE 16

void die(char *s)
{
    fprintf(stderr,"%s\n",s);
    exit(1);    
}

int main(int argc, char *argv[])
{
    unsigned char font[CCOUNT][WIDTH];
    int i,j,k,l,c;
    FILE *fp;
    char line[128];
    
    if(argc != 3) die("usage: fcompile <in> <out>");

    /* load font data from textfile */
    if(!(fp = fopen(argv[1],"r"))) die("error: cannot open infile");
    for(i=0;i < (CCOUNT/CPERLINE);i++){
	/* clear font mem */
	c = i*CPERLINE;            
	for(k=0;k<CPERLINE*WIDTH;k+=WIDTH){
	    for(l=0;l<WIDTH;l++){
		font[c][l] = 0;
	    }
	    c++;
	}
	
	/* load font mem */
        for(j=0;j<HEIGHT;j++){            
            fgets(line,128,fp);
            c = i*CPERLINE;            
            for(k=0;k<CPERLINE*WIDTH;k+=WIDTH){
                for(l=0;l<WIDTH;l++){
		    font[c][l] |= (line[k+l] == '#' ? (1<<j) : 0);
 		}
		c++;
            }
        }
    }
    fclose(fp);

    /* write out font data as a dsPIC assembly include */
    if(!(fp = fopen(argv[2],"w"))) die("error: cannot open outfile");
    fprintf(fp,"font:\n");
    for(i=0;i<CCOUNT;i+=4){
        fprintf(fp,"\t.pword ");
        for(j=0;j<4;j++){
	    c = font[i+j][0] << 16 |
		font[i+j][1] << 8 |
		font[i+j][2];
            fprintf(fp,"0x%06x%s",c,j == 3 ? "\n" : ", ");
        }
    }
    fclose(fp);
}
