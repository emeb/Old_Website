/***********************************************************************
* gfx.c - Graphics primitives                                          *
* 09/15/2009 - E. Brombaugh                                            *
***********************************************************************/
#include <string.h>
#include "lcd.h"
#include "font.h"
#include "gfx.h"

unsigned char gfx_map[768];

void gfx_refresh(void)
{
	lcd_send_bitmap(gfx_map);	// Send RAM image to LCD
}

void gfx_fill(unsigned char pattern)
{
	memset(gfx_map, pattern, 768);
}

void gfx_put(unsigned char *map)
{
	memcpy(gfx_map, map, 768);
}

void gfx_get(unsigned char *map)
{
	memcpy(map, gfx_map, 768);
}

void gfx_plot(char x, char y, char mode)
{
	unsigned char binbit = 1<<(y&0x07);
	unsigned char *byte = gfx_map + (y>>3)*96 + x;
	
	switch(mode)
	{
		case 0:	/* clear */
			*byte &= ~binbit;
			break;

		case 1:	/* set */
			*byte |= binbit;
			break;

		case 2:	/* toggle */
			*byte ^= binbit;
	}
}

char gfx_abs(char x)
{
	return (x<0) ? -x : x;
}

void gfx_swap(char *z0, char *z1)
{
	char temp = *z0;
	*z0 = *z1;
	*z1 = temp;
}

void gfx_sort(char *z0, char *z1)
{
	if(*z0>*z1)
	{
		gfx_swap(z0, z1);
	}
}

void gfx_rect_empty(char x0, char y0, char x1, char y1, char mode)
{
	char i;

	/* sort x, y in ascending order */
	gfx_sort(&x0, &x1);
	gfx_sort(&y0, &y1);

	/* top & bottom */
	for(i=x0;i<=x1;i++)
	{
		gfx_plot(i, y0, mode);
		gfx_plot(i, y1, mode);
	}

	/* left & right */
	for(i=y0+1;i<y1;i++)
	{
		gfx_plot(x0, i, mode);
		gfx_plot(x1, i, mode);
	}
}

void gfx_rect_fill(char x0, char y0, char x1, char y1, char mode)
{
	char x, y;

	/* sort x, y in ascending order*/
	gfx_sort(&x0, &x1);
	gfx_sort(&y0, &y1);

	/* iterate through all points in rect */
	for(x=x0;x<=x1;x++)
	{
		for(y=y0;y<=y1;y++)
		{
			gfx_plot(x, y, mode);
		}
	}		
}

/* Bresenham line draw routine swiped from Wikipedia */
void gfx_line(char x0, char y0, char x1, char y1, char mode)
{
	char steep;
	char deltax, deltay, error, ystep, x, y;
	
	/* flip sense 45deg to keep error calc in range */
	steep = (gfx_abs(y1 - y0) > gfx_abs(x1 - x0));
	
	if(steep)
	{
		gfx_swap(&x0, &y0);
		gfx_swap(&x1, &y1);
	}
	
	/* run low->high */
	if(x0 > x1)
	{
		gfx_swap(&x0, &x1);
		gfx_swap(&y0, &y1);
	}
	
	/* set up loop initial conditions */
	deltax = x1 - x0;
	deltay = gfx_abs(y1 - y0);
	error = deltax/2;
	y = y0;
	if(y0 < y1)
		ystep = 1;
	else
		ystep = -1;
	
	/* loop x */
	for(x=x0;x<=x1;x++)
	{
		/* plot point */
		if(steep)
			/* flip point & plot */
			gfx_plot(y, x, mode);
		else
			/* just plot */
			gfx_plot(x, y, mode);
		
		/* update error */
		error = error - deltay;
		
		/* update y */
		if(error < 0)
		{
			y = y + ystep;
			error = error + deltax;
		}
	}
}

void gfx_putchar(char x, char y, char c, char mode)
{
	unsigned char *byte = gfx_map + (y>>3)*96 + x;
	long charbits = getfont(c);	// get font bits for this char
	
	switch(mode)
	{
		case 0:	/* clear */
			*byte++ &= ~((charbits >> 16)&0xff);
			*byte++ &= ~((charbits >> 8)&0xff);
			*byte   &= ~(charbits&0xff);
			break;

		case 1:	/* set */
			*byte++ |= ((charbits >> 16)&0xff);
			*byte++ |= ((charbits >> 8)&0xff);
			*byte   |= (charbits&0xff);
			break;

		case 2:	/* toggle */
			*byte++ ^= ((charbits >> 16)&0xff);
			*byte++ ^= ((charbits >> 8)&0xff);
			*byte   ^= (charbits&0xff);
	}
}

void gfx_putstr(char x, char y, char *c, char mode)
{
	while(*c)
	{
		gfx_putchar(x, y, *c++, mode);
		x+= 4;
	}
}