/***********************************************************************
 *    Project:        dsPIC_lcd3 - graphic LCD driver                  * 
 *    Author:         Eric Brombaugh                                   *
 *    Company:        KBADC                                            * 
 *    Filename:       main.c                                           *
 *    Date:           09/24/2009                                       *
 *    File Version:   0.3                                              *
 *    Tools Used: MPLAB IDE -> 8.10                                    *
 *                Compiler  -> 3.10                                    *
 *                                                                     *
 *    Devices Supported:                                               *
 *                dsPIC33FJ32GP302                                     *
 *                                                                     *
 ***********************************************************************
 * History:                                                            *
 *                                                                     *
 * V0.0  09/21/2009                                                    *
 *   - Initial copied from dsPIC_lcd2                                  *
 *   - Update for new PMD, ADC stuff                                   *
 *   - add DSP stuff                                                   *
 * V0.1  09/22/2009                                                    *
 *   - Spectrum Analyzer works                                         *
 * V0.2  09/23/2009                                                    *
 *   - Add font                                                        *
 * V0.3  09/24/2009                                                    *
 *   - Add clip detect                                                 *
 *   - Add peak find                                                   *
 *   - Add splash screen                                               *
 *                                                                     *
 **********************************************************************/
#include <p33FJ32GP302.h>
#include <dsp.h>
#include <string.h>
#include <stdlib.h>
#include "timing.h"
#include "lcd.h"
#include "gfx.h"
#include "bitmap.h"
#include "window.h"
#include "twiddle.h"

/************* Configuration Bits **********/
_FBS(BWRP_WRPROTECT_OFF)		// No Boot Protect
_FGS(GSS_OFF)					// No Code Protect
_FOSCSEL(FNOSC_FRCPLL)			// Fast RC and PLL
_FOSC(FCKSM_CSDCMD & OSCIOFNC_ON & IOL1WAY_OFF)
//Turn off clock switch & monitor, OSC2 is GPIO, allow multiple IOLOCKs
_FWDT(FWDTEN_OFF)				// Turn off Watchdog Timer
_FPOR(FPWRT_PWR16)				// Power-up Timer to 16msecs
_FICD(ICS_PGD1 & JTAGEN_OFF)	// Use PGC/D 1, no JTAG

/************* START OF GLOBAL DEFINITIONS **********/

fractional adcbuf[128];		/* ADC input buffer */
fractional winbuf[128];		/* window buffer */
fractcomplex fftbuf[128] __attribute__ ((space(ymemory), aligned(128*2*2)));	/* in-place FFT buffer */
int adcbuf_ptr;			/* ADC input sample pointer */
int adcbuf_clip;		/* clip detector */	
char obuf[96];			/* scope buffer */
unsigned char gbuf[768];	/* backup buffer */

/************** MACRO DEFINITIONS ***********/

/* setup hardware */
void init_hw(void)
{
	/* Setup Port B bits as outputs for mux ctl A0, A1, A2 & MUX */
	CS1B = 1;				// CS1B idles high
	RESETB = 0;				// RESETB starts off deasserted
	RS = 1;					// RS idles high
	TRISBbits.TRISB15=0;	// CS1B Output
	TRISBbits.TRISB14=0;	// RESETB Output
	TRISBbits.TRISB13=0;	// RS Output

	/* Setup SPI port to talk to DAC8550 (SDO=RB6, SCK=RB7, SYNC=RB10) */
	SPI1CON1 = 0x007b;	// 8-bit, data chg fall, ck act low, Master, 2:1, 1:1
						// 11.76MHz SPI clock
	SPI1CON2 = 0;		// no framing	
	SPI1STATbits.SPIROV = 0;	// Clear rx ovfl
	SPI1STATbits.SPIEN = 1;		// Enable SPI1 port

	/* Setup Peripheral Pin Select for SPI and UART I/O */
	__builtin_write_OSCCONL(OSCCON & ~(1<<6));	// Unlock access to RP registers

	RPOR3 = 0x0700;		// RP out code for SDO1 on RP7
	RPOR6 = 0x0008;		// RP out code for SCK1 on RP12
		
	__builtin_write_OSCCONL(OSCCON | (1<<6));	// Lock access to RP registers

	/* Setup Timer 1 @ 1kHz for system tic timing */
	PR1 = 23300;	// timeout period for 1kHz based on 23.3MHz Fcy
	TMR1 = 0;		// Clear timer
	T1CON = 0;		// Tcy, 1:1, async

	/* ADC1 Setup */
	AD1CON1 = 0x17E4;	// Signed Fraction, Continuous sample, 12-bit, conv. order
	AD1CON2 = 0x0400;	// Scan, 1 channel, AVDD & AVSS
	AD1CON3 = 0x0f04;	// Tad=Tcy*(ADCS+1)= (1/23M)*5 = 217ns (4.6Mhz)
	AD1CON4 = 0x0000;	// 1 word buffer
	AD1CHS0 = 0x0404;	// Start CHS0 on AN4
	AD1CHS123 = 0;		// CHS123 unused in 12-bit mode
	AD1PCFGL = 0xFFEF;	// AN4 as Analog Input
	AD1CSSL = 0x0010;	// Scan AN4
	IFS0bits.AD1IF = 0;	// Clear the A/D interrupt flag bit
	IEC0bits.AD1IE = 0;	// Do Not Enable A/D interrupt
	AD1CON1bits.ADON = 1;	// Turn on the A/D converter
	
	/* Disable unused peripherals with PMD registers */
	PMD1bits.SPI2MD = 1;	// disable SPI2
	PMD1bits.U1MD = 1;		// disable UART1
	PMD1bits.U2MD = 1;		// disable UART2
	PMD1bits.I2C1MD = 1;	// disable I2C1
	PMD1bits.DCIMD = 1;		// disable DCI
	PMD1bits.T2MD = 1;		// disable T2
	PMD1bits.T3MD = 1;		// disable T3
	PMD1bits.T4MD = 1;		// disable T4
	PMD1bits.T5MD = 1;		// disable T5
	PMD2bits.OC1MD = 1;		// disable Output Compare
	PMD2bits.OC2MD = 1;		// disable Output Compare
	PMD2bits.OC3MD = 1;		// disable Output Compare
	PMD2bits.OC4MD = 1;		// disable Output Compare
	PMD2bits.IC1MD = 1;		// disable Input Compare
	PMD2bits.IC2MD = 1;		// disable Input Compare
	PMD2bits.IC7MD = 1;		// disable Input Compare
	PMD2bits.IC8MD = 1;		// disable Input Compare
	PMD3bits.CRCMD = 1;		// disable CRC
	PMD3bits.PMPMD = 1;		// disable PMP
	PMD3bits.RTCCMD = 1;	// disable RTC
	PMD3bits.CMPMD = 1;		// disable Analog comparator

	/* Enable Timer1 Interrupt */
	IPC0bits.T1IP0 = 1;	// Set priority of Timer 1 irq to 5
	IFS0bits.T1IF = 0;	// Clear Timer 1 interrupt
	IEC0bits.T1IE = 1;	// Enable Timer 1 interrupt
	T1CONbits.TON = 1;	// Turn on Timer 1

	/* Enable ADC1 Interrupt */
	IPC3bits.AD1IP1 = 1;	// Set priority of ADC1 irq to 6
	IFS0bits.AD1IF = 0;	// Clear Timer 1 interrupt
	IEC0bits.AD1IE = 1;	// Enable Timer 1 interrupt
}

/* integer log2() scaled so 512 => 64 */
int ilog2(int x)
{
	int ex, ma, y;
	
	/* find msb - exponent */
	for(ex=9;ex>2;ex--)
	{
		if(x&256)
			break;
		x<<=1;
	}
	
	/* mask off mantissa */
	ma = (x>>5)&7;
	
	/* build output */
	y = ((ex<<3) | ma)-16;
	return y;
}

/************* MAIN FUNCTION ***************/
int main ( void )
{
	unsigned int adc_cnt;
	int idx;
	long test;
	int pk_bin;
	char pk_txt[8];

	test = getfont(0);

	/* init globals */
	adcbuf_ptr = 0;
	adcbuf_clip = 0;
	
	/* Initialize dsPIC hardware */
	init_hw();
	
	/* Initialize 1kHz timer tick */
	init_timing();
	
	/* Initialize LCD */
	lcd_init();
	
	/* Splash Screen */
	gfx_put((unsigned char *)image);	// Earl!
	gfx_putstr(64, 0, "dsPIC", 1);
	gfx_putstr(64, 8, "Spect.", 1);
	gfx_putstr(64, 16, "Analyze", 1);
	gfx_putstr(64, 24, "v0.3", 1);
	gfx_refresh();

	/* wait 2 seconds */
	adc_cnt = get_tick();
	while(diff_tick(adc_cnt) < 2000){}

	/* Init blank screen */
	gfx_fill(0x00);
	
	/* graticle */
	gfx_line(31, 0, 31, 63, 1);

	/* Test Text */
	gfx_putstr(0, 0, "Peak:", 1);
	gfx_get(gbuf);

	/* init window */
	memcpy(winbuf, window, 256);

	/* Loop forever */
	adc_cnt = get_tick();

	while(1)
	{
		/* 2/10 sec non-blocking delay */
		if(diff_tick(adc_cnt) > 100)
		{
			/* Update tick count for next time */
			adc_cnt = get_tick();
			
			if(adcbuf_ptr == 128)
			{
				/* apply window to input data */
				VectorMultiply(128, adcbuf, adcbuf, winbuf);

				/* convert to complex & scale down to 1/2 */
				for(idx=0;idx<128;idx++)
				{
					fftbuf[idx].real = adcbuf[idx]>>1;
					fftbuf[idx].imag = 0;
				}

				/* FFT */
				FFTComplexIP(7, fftbuf,
					(fractcomplex *) __builtin_psvoffset(twiddleFactors),
					__builtin_psvpage(twiddleFactors));
				
				/* swap'em around */
				BitReverseComplex(7, fftbuf);

				/* Magnitude back in ADC buffer */
				SquareMagnitudeCplx(128, fftbuf, adcbuf);

				/* find peak bin */
				VectorMax(64, adcbuf, &pk_bin);

				/* scale & load output buffer */
				for(idx=0;idx<64;idx++)
				{
					obuf[idx] = ilog2(adcbuf[idx]);
				}

				/* erase previous */
				gfx_put(gbuf);
				
				/* display peak bin */
				itoa(pk_bin, pk_txt);
				gfx_putstr(0, 8, pk_txt, 1);

				/* Clip indicator */	
				if(adcbuf_clip)
				{
					gfx_putstr(0, 56, ">Clip<", 1);
					adcbuf_clip = 0;
				}

				/* draw waveform */
				for(idx=0;idx<64;idx++)
				{
					gfx_line(idx+32, 63, idx+32, 63-obuf[idx], 1);
				}

				/* update display */
				gfx_refresh();

				/* start next capture */
				adcbuf_ptr = 0;
			}
		}
	}
	
	return 0;
}

/****** START OF INTERRUPT SERVICE ROUTINES *********/

/* ADC1 ISR invoked when new ADC data ready */
void __attribute__((interrupt, auto_psv)) _ADC1Interrupt(void)
{
	IFS0bits.AD1IF = 0;			// Clear interrupt
	
	/* Acquiring? */
	if(adcbuf_ptr < 128)
	{
		int tmp = ADCBUF0;

		adcbuf[adcbuf_ptr++] = tmp;
		
		/* clipping? */
		if((tmp < -32700)||(tmp > 32700))
		{
			adcbuf_clip = 1;
		}
	}
}



/********* END OF INTERRUPT SERVICE ROUTINES ********/

