/***********************************************************************
* lcd.c - Interface routines for Goldmine LCD                          *
* 09/15/2009 - E. Brombaugh                                            *
***********************************************************************/
#include <p33FJ12GP202.h>
#include "timing.h"
#include "lcd.h"

/************* HW SPI Functions ***************/
void spi_send(unsigned char data)
{
	unsigned int dummy;

	/* drop CS line */
	CS1B = 0;

	dummy = SPI1BUF;	// clear previous SPIRBF
	SPI1BUF = data;		// Send data via SPI

	/* wait for data sent */
	while(SPI1STATbits.SPIRBF == 0);

	/* raise CS line */
	CS1B = 1;
}

/************* LCD Functions ***************/
void lcd_send_cmd(unsigned char data)
{
	/* RS low for commands */
	RS = 0;

	spi_send(data);
}

void lcd_send_data(unsigned char data)
{
	/* RS high for commands */
	RS = 1;

	spi_send(data);
}

void lcd_init()
{
	/* while RESETB is low, wait 1ms */
	dly_tick(1);

	/* raise RESETB */
	RESETB = 1;

	/* set command regs */
	lcd_send_cmd(0x48);		// Set Duty #1
	lcd_send_cmd(0x40);		// Set Duty #2 - 64
	lcd_send_cmd(0xAB);		// OSC ON
	lcd_send_cmd(0x66);		// DC Boost 5x
	lcd_send_cmd(0x22);		// VR Level 2
	lcd_send_cmd(0x81);		// EVR #1
	lcd_send_cmd(0x30);		// EVR #2 - 48
	lcd_send_cmd(0x55);		// Bias 9
	lcd_send_cmd(0x2F);		// Power All On
	lcd_send_cmd(0xAF);		// Display on
}

void lcd_fill(unsigned char bits)
{
	int pg_cmd = 0xB0;		// initial page = 0
	int col;

	/* loop over pages */
	while(pg_cmd < 0xB8)
	{
		/* set page */
		lcd_send_cmd(pg_cmd);

		/* Set column 0 */
		lcd_send_cmd(0x10);
		lcd_send_cmd(0x00);

		/* loop over columns */
		for(col=96;col>0;col--)
		{
			lcd_send_data(bits);
		}

		/* next page */
		pg_cmd++;
	}
}

void lcd_send_bitmap(unsigned char *bitmap)
{
	int pg_cmd = 0xB0;		// initial page = 0
	int col;

	/* loop over pages */
	while(pg_cmd < 0xB8)
	{
		/* set page */
		lcd_send_cmd(pg_cmd);

		/* Set column 0 */
		lcd_send_cmd(0x10);
		lcd_send_cmd(0x00);

		/* loop over columns */
		for(col=96;col>0;col--)
		{
			lcd_send_data(*bitmap++);
		}

		/* next page */
		pg_cmd++;
	}
}


