/*...........................................................................*/
/* timing.c - interface routines for 1kHz system time tick                   */
/* 12/27/2008 E. Brombaugh                                                   */
/*...........................................................................*/

#include <p33FJ12GP202.h>
#include "timing.h"

unsigned int Tick_Cnt;

void init_timing(void)
{
	/* Init Tick Count */
	Tick_Cnt = 0;
}

/* get current time plus offset for non-blocking timeouts */
unsigned int get_tick(void)
{
	return Tick_Cnt;
}

/* return difference of current time from previous time */
int diff_tick(unsigned int prev)
{
	unsigned int curr = Tick_Cnt;
	
	/* as setup here, Tick_Cnt only overflows every 64 seconds */
	/* still need to handle that case though */
	if(curr > prev)
		return curr - prev;	/* no overflow */
	else
		return (0xFFFF - prev) + curr + 1;
}

/* blocking wait for time expiration in usecs */
void dly_tick(unsigned int ticks)
{
	unsigned int starttime = Tick_Cnt;

	while(diff_tick(starttime) < ticks);
}

/****** START OF INTERRUPT SERVICE ROUTINES *********/

/* Timer 1 ISR runs @ 1kHz */
void __attribute__((interrupt, auto_psv)) _T1Interrupt(void)
{
	IFS0bits.T1IF = 0;			// Clear Timer 1 interrupt
	Tick_Cnt++;					// Update tick count
}

/********* END OF INTERRUPT SERVICE ROUTINES ********/
