/***********************************************************************
 *    Project:        dsPIC_lcd2 - graphic LCD driver                  * 
 *    Author:         Eric Brombaugh                                   *
 *    Company:        KBADC                                            * 
 *    Filename:       main.c                                           *
 *    Date:           09/15/2009                                       *
 *    File Version:   0.2                                             *
 *    Other Files Required: p30f6014.h, p30f6014.gld                   *
 *    Tools Used: MPLAB IDE -> 8.10                                    *
 *                Compiler  -> 3.10                                    *
 *                                                                     *
 *    Devices Supported:                                               *
 *                dsPIC33FJ12GP202                                     *
 *                                                                     *
 ***********************************************************************
 * History:                                                            *
 *                                                                     *
 * V0.0  09/13/2009                                                    *
 *   - Initial conversion from assembly                                *
 * V0.1  09/15/2009                                                    *
 *   - Hardware SPI                                                    *
 * V0.2  09/13/2009                                                    *
 *   - RAM bitmap                                                      *
 *   - split out low-level funcs                                       *
 *   - graphics primitives                                             *
 *   - remove Earl :(                                                  *
 * V0.3  09/17/2009                                                    *
 *   - Hardware timing functions                                       *
 *   - ADC stuff                                                       *
 *                                                                     *
 **********************************************************************/
#include <p33FJ12GP202.h>
#include "timing.h"
#include "lcd.h"
#include "gfx.h"

/************* Configuration Bits **********/
_FBS(BWRP_WRPROTECT_OFF)		// No Boot Protect
_FGS(GSS_OFF)					// No Code Protect
_FOSCSEL(FNOSC_FRCPLL)			// Fast RC and PLL
_FOSC(FCKSM_CSDCMD & OSCIOFNC_ON & IOL1WAY_OFF)
//Turn off clock switch & monitor, OSC2 is GPIO, allow multiple IOLOCKs
_FWDT(FWDTEN_OFF)				// Turn off Watchdog Timer
_FPOR(FPWRT_PWR16)				// Power-up Timer to 16msecs
_FICD(ICS_PGD1 & JTAGEN_OFF)	// Use PGC/D 1, no JTAG

/************* START OF GLOBAL DEFINITIONS **********/

/************** MACRO DEFINITIONS ***********/

/* setup hardware */
void init_hw(void)
{
	/* Setup Port B bits as outputs for mux ctl A0, A1, A2 & MUX */
	CS1B = 1;				// CS1B idles high
	RESETB = 0;				// RESETB starts off deasserted
	RS = 1;					// RS idles high
	TRISBbits.TRISB15=0;	// CS1B Output
	TRISBbits.TRISB14=0;	// RESETB Output
	TRISBbits.TRISB13=0;	// RS Output

	/* Setup SPI port to talk to DAC8550 (SDO=RB6, SCK=RB7, SYNC=RB10) */
	SPI1CON1 = 0x007b;	// 8-bit, data chg fall, ck act low, Master, 2:1, 1:1
						// 11.76MHz SPI clock
	SPI1CON2 = 0;		// no framing	
	SPI1STATbits.SPIROV = 0;	// Clear rx ovfl
	SPI1STATbits.SPIEN = 1;		// Enable SPI1 port

	/* Setup Peripheral Pin Select for SPI and UART I/O */
	__builtin_write_OSCCONL(OSCCON & ~(1<<6));	// Unlock access to RP registers

	RPOR3 = 0x0700;		// RP out code for SDO1 on RP7
	RPOR6 = 0x0008;		// RP out code for SCK1 on RP12
		
	__builtin_write_OSCCONL(OSCCON | (1<<6));	// Lock access to RP registers

	/* Setup Timer 1 @ 1kHz for system tic timing */
	PR1 = 23300;	// timeout period for 1kHz based on 23.3MHz Fcy
	TMR1 = 0;		// Clear timer
	T1CON = 0;		// Tcy, 1:1, async

	/* ADC1 Setup */
	AD1CON1 = 0x14E4;	// Fraction, Continuous sample, 12-bit, conv. order
	AD1CON2 = 0x0404;	// Scan, 2 channels, AVDD & AVSS
	AD1CON3 = 0x0f04;	// Tad=Tcy*(ADCS+1)= (1/23M)*5 = 217ns (4.6Mhz)
	AD1CHS0 = 0;		// Start CHS0 on AN0
	AD1CHS123 = 0;		// CHS123 unused in 12-bit mode
	AD1PCFGL = 0xFFCF;	// AN4-AN5 as Analog Input
	AD1CSSL = 0x0030;	// Scan AN4-AN5
	IFS0bits.AD1IF = 0;	// Clear the A/D interrupt flag bit
	IEC0bits.AD1IE = 0;	// Do Not Enable A/D interrupt
	AD1CON1bits.ADON = 1;	// Turn on the A/D converter
	
	/* Disable unused peripherals with PMD registers */
	PMD1bits.U1MD = 1;		// disable UART1
	PMD1bits.I2C1MD = 1;	// disable I2C1
	PMD1bits.T2MD = 1;		// disable T2
	PMD1bits.T3MD = 1;		// disable T3
	PMD2bits.OC1MD = 1;		// disable Output Compare
	PMD2bits.OC2MD = 1;		// disable Output Compare
	PMD2bits.IC1MD = 1;		// disable Input Compare
	PMD2bits.IC2MD = 1;		// disable Input Compare
	PMD2bits.IC7MD = 1;		// disable Input Compare
	PMD2bits.IC8MD = 1;		// disable Input Compare

	/* Enable Timer1 Interrupt */
	IPC0bits.T1IP1 = 1;	// Set priority of Timer 1 irq to 6
	IFS0bits.T1IF = 0;	// Clear Timer 1 interrupt
	IEC0bits.T1IE = 1;	// Enable Timer 1 interrupt
	T1CONbits.TON = 1;	// Turn on Timer 1
}

/************* MAIN FUNCTION ***************/
int main ( void )
{
	unsigned int adc_cnt, blink_cnt, temp;

	/* init globals */

	/* Initialize dsPIC hardware */
	init_hw();
	
	/* Initialize 1kHz timer tick */
	init_timing();
	
	/* Initialize LCD */
	lcd_init();

	gfx_fill(0x00);						// Clear buffer
	gfx_rect_empty(0, 0, 95 ,63 , 1);	// outer border
	gfx_rect_empty(14, 14, 81, 25, 1);	// bargraph border for AN0
	gfx_rect_empty(14, 34, 81, 45, 1);	// bargraph border for AN1
	gfx_refresh();						// Send RAM image to LCD

	/* Loop forever */
	adc_cnt = blink_cnt = get_tick();

	while(1)
	{
		/* 1/10 sec non-blocking delay */
		if(diff_tick(adc_cnt) > 100)
		{
			/* Update tick count for next time */
			adc_cnt = get_tick();
			
			/* make sure ADC has new data */
			if(IFS0bits.AD1IF)
			{
				/* clear ADC ready flag */
				IFS0bits.AD1IF = 0;
				
				/* clear previous bargraphs */
				gfx_rect_fill(16, 16, 79, 23, 0);
				gfx_rect_fill(16, 36, 79, 43, 0);
				
				/* update new bargraphs */
				temp = ADCBUF0; temp = (temp>>6)&0x3f;
				gfx_rect_fill(16, 16, 16+temp, 23, 1);
				temp = ADCBUF1; temp = (temp>>6)&0x3f;
				gfx_rect_fill(16, 36, 16+temp, 43, 1);
				gfx_refresh();
			}
		}
		
		/* 1/2 sec non-blocking delay */
		if(diff_tick(blink_cnt) > 500)
		{
			/* Update tick count for next time */
			blink_cnt = get_tick();
		
			/* blinking box */
			gfx_rect_fill(44, 52, 51, 59, 2);
			gfx_refresh();
		}
	}
	
	return 0;
}

/****** START OF INTERRUPT SERVICE ROUTINES *********/


/********* END OF INTERRUPT SERVICE ROUTINES ********/

