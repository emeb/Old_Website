/*...........................................................................*/
/* spi.c - interface routines for spi driver                                 */
/* 06/07/2009 E. Brombaugh                                                   */
/*...........................................................................*/

#include <p33FJ64GP802.h>
#include "spi.h"

#define SPI_MAXLOOP 300

void init_spi()
{
	/* Setup Peripheral Pin Select for SPI on RB9:8 */
	//__builtin_write_OSCCONL(OSCCON & ~(1<<6));	// Unlock access to RP registers
	//RPOR4 = 0x0708;		// SDO1 on RP9 & SCK1 on RP8	
	//__builtin_write_OSCCONL(OSCCON | (1<<6));	// Lock access to RP registers

	/* Setup SPI port to talk to W8731 (SDO=RB6, SCK=RB7, SYNC=RB10) */
	SPI1CON1 = 0x0533;	// 16-bit, data chg fall, ck act high, Master, 4:1, 1:1
						// 5.88MHz SPI clock, 16-bit: 1 xfers = ~2.8us
	SPI1CON2 = 0;				// no framing	
	SPI1STATbits.SPIROV = 0;	// 
	SPI1STATbits.SPIEN = 1;		// Enable SPI1 port
	TRISBbits.TRISB6 = 0;		// Set port B6 to output for CSB
	LATBbits.LATB6 = 1;			// de-assert CSB
}

int write_spi(unsigned int data)
{
	unsigned int dummy, lpcnt;

	// Drop CSB
	LATBbits.LATB6 = 0;

	// Dummy read to clear SPI read buffer flag
	dummy = SPI1BUF;

	// Send data via SPI1
	SPI1BUF = data;
	
	// Wait for SPI TX done
	lpcnt = 0;
	while(!SPI1STATbits.SPIRBF)
	{
		if(lpcnt++ > SPI_MAXLOOP)
			goto wrt_spi_err;
	}
	LATBbits.LATB6 = 1;			// de-assert CSB
	
	// return success
	return 0;
	
	// Error condition
wrt_spi_err:
	LATBbits.LATB6 = 1;			// de-assert CSB
	return -1;
}

int read_spi(unsigned int *data)
{
	// Not implemented yet
	return -1;
}

