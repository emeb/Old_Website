/*...........................................................................*/
/* dac.h - header file for dci driver                                        */
/* declares data structures and access routines used by DAC ISR              */
/* 08/11/2010 E. Brombaugh                                                   */
/*...........................................................................*/

#ifndef __dac__
#define __dac__

volatile extern int FREQ0;			// Chl 0 freq value
volatile extern int FREQ1;	 		// Chl 1 freq value

void init_dac();

#endif
