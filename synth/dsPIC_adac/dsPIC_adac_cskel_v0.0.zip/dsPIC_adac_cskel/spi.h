/*...........................................................................*/
/* spi.h - header file for spi driver                                        */
/* 05/30/2009 E. Brombaugh                                                   */
/*...........................................................................*/

#ifndef __spi__
#define __spi__

void init_spi(void);
int write_spi(unsigned int cnt);
int read_spi(unsigned int *data);

#endif
