/***********************************************************************
 *    Project:        dsPIC_adac_cskel                                 * 
 *    Author:         Eric Brombaugh                                   *
 *    Company:        KBADC                                            * 
 *    Filename:       main.c                                           *
 *    Date:           08/11/2010                                       *
 *    File Version:   0.0                                              *
 *    Other Files Required: (see project)                              *
 *    Tools Used: MPLAB IDE -> 8.53                                    *
 *                Compiler  -> 3.24                                    *
 *                                                                     *
 *    Devices Supported:                                               *
 *                dsPIC33FJ64GP802                                     *
 *                                                                     *
 ***********************************************************************
 * History:                                                            *
 *                                                                     *
 * V0.0  08/11/2010                                                    *
 *   - Started based on previous dsPIC_sp project                      *
 *                                                                     *
 **********************************************************************/
#include <p33FJ64GP802.h>
#include "adc.h"
#include "dac.h"
#include "spi.h"
#include "i2c.h"
#include "uart.h"

/************* Configuration Bits **********/
_FBS(BWRP_WRPROTECT_OFF)		// No Boot Protect
_FGS(GSS_OFF)					// No Code Protect
_FOSCSEL(FNOSC_FRC)				// Fast RC to start
_FOSC(POSCMD_HS & FCKSM_CSECMD & IOL1WAY_OFF)
// Primary HS, clock switch, no monitor, allow multiple IOLOCKs
_FWDT(FWDTEN_OFF)				// Turn off Watchdog Timer
_FPOR(FPWRT_PWR16)				// Power-up Timer to 16msecs
_FICD(ICS_PGD2 & JTAGEN_OFF)	// Use PGC/D 2, no JTAG

/************* START OF GLOBAL DEFINITIONS **********/

/************** END OF GLOBAL DEFINITIONS ***********/

/* setup clock PLL */
void init_clk(void)
{
	/* Program PLL for 38MHz from 7.37MHz HS Xtal */
	CLKDIVbits.PLLPRE = 0;		// PLL PRE = 2
	CLKDIVbits.PLLPRE = 0;		// PLL POST = 2
	PLLFBD = 39;				// PLL FDBK = 41

	/* Switch clock source to PLL */
	__builtin_write_OSCCONH(3); // NOSC = 3 : HS + PLL
	__builtin_write_OSCCONL(1); // OSWEN = 1 : switch clock source

	/* Wait for clock switch */
	while(OSCCON & 1)
	{
		/* do nothing */
	}
}

/* setup hardware */
void init_hw(void)
{
	/* Switch to 38MHz clock */
	init_clk();

	/* Setup ADC & DMA */
	init_adc();

	/* Setup DCI */
	init_dac();

	/* Setup SPI */
	//init_spi();

	/* Setup I2C */
	//init_i2c();

	/* Setup UART */
	//U1init();
}

/************* START OF MAIN FUNCTION ***************/

int main ( void )
{
	/* Initialize hardware */
	init_hw();

	/* Loop forever */
	while(1)
	{
		if(ADCRDY)
		{
			ADCRDY = 0;

			/* handle ADC */
			FREQ0 = CV[0];
			FREQ1 = CV[1];
		}
	}
	
	return 0;
}

