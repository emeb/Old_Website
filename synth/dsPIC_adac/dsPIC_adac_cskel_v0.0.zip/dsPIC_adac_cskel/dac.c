/*...........................................................................*/
/* dac.c - interface routines for dci driver                                 */
/* 08/11/2010 E. Brombaugh - started based on dci.c                          */
/*...........................................................................*/

#include <p33FJ64GP802.h>
#include "dac.h"

void init_dac()
{
	/* Setup RB3 for diagnostics */
	TRISBbits.TRISB3 = 0;	// Set port B bit 3 to output
	LATBbits.LATB3 = 0;		// Clear

	/* Setup ACLK for DAC */
	ACLKCON = 0x0600;		// Divide PLL clock by 1 for ACLK

	/* Setup DAC */
	DAC1STATbits.LOEN = 1;		// Enable L chl
	DAC1STATbits.ROEN = 1;		// Enable R chl
	DAC1STATbits.RITYPE = 1;	// Interrupt if not full
	DAC1CONbits.FORM = 1;		// 2's comp
	DAC1CONbits.DACFDIV = 2;	// Divide ratio = 3
	DAC1DFLT = 0;				// Default to midpoint
	DAC1CONbits.DACEN = 1;		// Turn on DAC

	IFS4bits.DAC1RIF = 0;		// Clear DAC1R interrupt
	IEC4bits.DAC1RIE = 1;		// Enable DAC1R interrupt
}
