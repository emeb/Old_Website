/*...........................................................................*/
/* adc_isr.c - interface routines for adc driver                             */
/* 05/30/2009 E. Brombaugh                                                   */
/* 08/11/2010 E. Brombaugh cut back to 4 scanned channels                    */
/*...........................................................................*/

#include <p33FJ64GP802.h>
#include "adc.h"

void init_adc()
{
	/* Setup RB2 for diagnostics */
	TRISBbits.TRISB2 = 0;	// Set port B bit 2 to output
	LATBbits.LATB2 = 0;		// ClearS
	
	/* ADC1 Setup */
	AD1CON1 = 0x04E4;	// Scat/Gath, Integer, Continuous sample
	AD1CON2 = 0x040C;	// Scan, 4 channels, AVDD & AVSS
	AD1CON3 = 0x0707;	// Tad=Tcy*(ADCS+1)= (1/23M)*8 = 350ns (2.9Mhz)
						// Tsamp = 8 * Tad = 2.78us
	AD1CON4 = 0;		// 1 sample/chl in buffer
	AD1CHS0 = 0;		// Start CHS0 on AN0
	AD1CHS123 = 0;		// CHS123 unused in 12-bit mode
	AD1PCFGL = 0xFFF0;	// AN0-AN3 as Analog Input
	AD1CSSL = 0x000f;	// Scan AN0-AN3
	IFS0bits.AD1IF = 0;	// Clear the A/D interrupt flag bit
	IEC0bits.AD1IE = 0;	// Do Not Enable A/D interrupt
	AD1CON1bits.ADON = 1;	// Turn on the A/D converter
	
	/* DMA0 Setup for ADC1 */
	DMA0CON = 0x0020;		// Peripheral indirect, Continuous
	DMA0PAD	= (volatile unsigned int) &ADC1BUF0;	// Get data from ADC1BUF0
	DMA0CNT	= 3;			// 4 transfers per interrupt
	DMA0REQ	= 13;			// IRQ13 (ADC1) as source
	DMA0STA	= __builtin_dmaoffset(ADCCHL);	// Buffer location
	IFS0bits.DMA0IF	= 0;	//Clear DMA0IF
	IEC0bits.DMA0IE = 1;	// Enable DMA0 interrupt
	IPC1bits.DMA0IP0 = 1;	// Set priority of DMA0 irq to 5
	DMA0CONbits.CHEN = 1;	// Enable DMA0
}
