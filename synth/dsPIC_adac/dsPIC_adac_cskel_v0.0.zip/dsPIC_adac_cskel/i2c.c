/*...........................................................................*/
/* i2c.c - interface routines for i2c driver                                 */
/* 06/07/2009 E. Brombaugh                                                   */
/*...........................................................................*/

#include <p33FJ64GP802.h>
#include "i2c.h"

#define I2C_MAXLOOP 2100

void init_i2c()
{
	// Configre SCA/SDA pin as open-drain
	ODCBbits.ODCB8 = 1;
	ODCBbits.ODCB9 = 1;

	I2C1CONbits.A10M = 0;		// 7-bit address
	I2C1CONbits.SCLREL = 1;		// No clock stretch
	I2C1BRG = 209;				// for Fcy = 23.03MHz

	I2C1ADD = 0;
	I2C1MSK = 0;
	
	I2C1CONbits.I2CEN = 1;		// Enable I2C
}

int write_i2c(unsigned int addr, unsigned int *data, unsigned int cnt)
{
	unsigned int lpcnt;
	
	// Wait for bus idle
//	lpcnt = 0;
//	while(!I2C1STATbits.P)
//	{
//		if(lpcnt++ > I2C_MAXLOOP)
//			goto wrt_i2c_err;
//	}
	
	// Assert Start condition
	I2C1CONbits.SEN = 1;		// Assert Start
	
	// Wait for Start to clear (1 bit time = 10us = 230*Fcy)
	lpcnt = 0;
	while(I2C1CONbits.SEN)
	{
		if(lpcnt++ > I2C_MAXLOOP)
			goto wrt_i2c_err;
	}
	
	// Send Address & W bit
	I2C1TRN = ((addr & 0x7f) << 1);
	
	// Wait for ACK (9 bit time = 90us = 2072*Fcy)
	while(I2C1STATbits.TRSTAT)
	{
		if(lpcnt++ > I2C_MAXLOOP)
			goto wrt_i2c_err;
	}
	if(I2C1STATbits.ACKSTAT)
		goto wrt_i2c_err;
	
	// loop sending data bytes with intervening ACK
	while(cnt-- > 0)
	{
		// send data
		I2C1TRN	= *data++;
		
		// wait for ACK (9 bit time = 90us = 2072*Fcy)
		lpcnt = 0;
		while(I2C1STATbits.TRSTAT)
		{
			if(lpcnt++ > I2C_MAXLOOP)
				goto wrt_i2c_err;
		}
		if(I2C1STATbits.ACKSTAT)
			goto wrt_i2c_err;
	}
		
	// Send Stop condition
	I2C1CONbits.PEN = 1;
	
	// Wait for end of stop (1 bit time = 10us = 230*Fcy)
	lpcnt = 0;
	while(I2C1CONbits.PEN)
	{
		if(lpcnt++ > I2C_MAXLOOP)
			goto wrt_i2c_err;
	}

	// Final check for idle state
	if(!I2C1STATbits.P)
		goto wrt_i2c_err;
	
	// return success
	return 0;
	
	// Error condition
wrt_i2c_err:
	return -1;
}

int read_i2c(unsigned int addr, unsigned int *data, unsigned int cnt)
{
	// Not implemented yet
	return -1;
}

