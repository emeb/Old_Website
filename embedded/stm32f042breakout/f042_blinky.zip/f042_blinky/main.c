/*
 * Blinky Lights for STM32F042
 * E. Brombaugh 06-10-2015
 */

#include "stm32f0xx.h"
#include "led.h"
#include "systick.h"

int main(void)
{
	/* initialize the hardware */
	led_init();
	systick_init();
		
	/* Loop forever */
	while(1)
	{
		/* wait a bit & flash light */
		systick_delayms(100);
		led_on(LED1);
		systick_delayms(100);
		led_off(LED1);
	}
}
