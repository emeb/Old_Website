/*
 * adc.c - ADC routines for STM32Friend
 * 06-15-2015 E. Brombaugh
 */

#ifndef __adc__
#define __adc__

#include "stm32f0xx.h"

#define ADC_NUMCHLS 5

void adc_init(void);
uint16_t adc_get_data(uint8_t index);
uint16_t adc_get_temp(uint8_t index);

#endif
