/*
 * friend_hw.h - hardware setup for STM32F042F6-based STM32Friend
 * 06-13-15 E. Brombaugh
 */

#ifndef __friend_hw__
#define __friend_hw_

#include "stm32f0xx.h"

// this enables the internal USP pullup
#define INTERNAL_PULLUP

typedef enum 
{
  COM1 = 0,
  COM2 = 1
} COM_TypeDef;   

#define COMn                             1

#define EVAL_COM1                        USART2
   
#define EVAL_COM1_IRQn                   USART2_IRQn

void STM_EVAL_COMInit(COM_TypeDef COM, USART_InitTypeDef* USART_InitStruct);

#endif
