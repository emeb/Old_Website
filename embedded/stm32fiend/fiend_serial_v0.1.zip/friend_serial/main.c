/*
 * Blinky Lights for STM32F042
 * E. Brombaugh 06-10-2015
 */

#include "stm32f0xx.h"
#include "systick.h"
#include "usbd_cdc_core.h"
#include "usbd_usr.h"

USB_CORE_HANDLE  USB_Device_dev ;

int main(void)
{
	/* initialize the hardware */
	systick_init();
	
	/* Remap PA11-12 to PA9-10 for USB */
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGCOMPEN;	
	SYSCFG->CFGR1 |= SYSCFG_CFGR1_PA11_PA12_RMP;
		
	/* The Application layer has only to call USBD_Init to 
	initialize the USB low level driver, the USB device library, the USB clock 
	,pins and interrupt service routine (BSP) to start the Library*/
	USBD_Init(&USB_Device_dev,
            &USR_desc, 
            &USBD_CDC_cb, 
            &USR_cb);
	
	/* Loop forever */
	while(1)
	{
	}
}
