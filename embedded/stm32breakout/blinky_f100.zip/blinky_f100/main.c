/*************************************************************************
 *
 * blinky_f100 - simple blinking LED for the STM32F100C4T6B breakout board
 * 08-26-2011 E. Brombaugh
 *
 *************************************************************************/
#include "stm32f10x.h"
#include "bits.h"

#define NVIC_CCR ((volatile unsigned long *)(0xE000ED14))

//Declarations
void myDelay(unsigned long delay );
void Clk_Init (void);

// VARIABLES
GPIO_InitTypeDef GPIO_InitStructure;
//int _init[] = {0,0};

/*************************************************************************
 * Function Name: main
 * Parameters: none
 * Return: Int32U
 *
 * Description: The main subroutine
 *
 *************************************************************************/
int main(void)
{
 	// Set STKALIGN in NVIC
	*NVIC_CCR = *NVIC_CCR | 0x200;

	// Init clock system
	Clk_Init();

	// Turn on GPIO clocks
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOA, ENABLE);

	// Configure PB.11 as output push-pull (LED)
	GPIO_WriteBit(GPIOB,GPIO_Pin_11,Bit_SET);
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	// Blink forever
	while(1)
	{

		GPIOB->BRR |= 0x00000800;
		myDelay(500000);
		GPIOB->BSRR |= 0x00000800;
		myDelay(1500000);
	}
}

//Functions definitions
void myDelay(unsigned long delay )
{
	while(delay--)
	{
		asm("nop");		// This prevents optimization of the loop to nothing
	}
}

/*************************************************************************
 * Function Name: Clk_Init
 * Parameters: Int32U Frequency
 * Return: Int32U
 *
 * Description: Init clock system
 *
 *************************************************************************/

void Clk_Init (void)
{
	// 1. Clocking the controller from internal HSI RC (8 MHz)
	RCC_HSICmd(ENABLE);
	// wait until the HSI is ready
	while(RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET);
	RCC_SYSCLKConfig(RCC_SYSCLKSource_HSI);
	// 2. Init PLL
	RCC_PLLConfig(RCC_PLLSource_HSI_Div2,RCC_PLLMul_6); // 24MHz
	//RCC_PLLConfig(RCC_PLLSource_HSI_Div2,RCC_PLLMul_12); // 48MHz works too
	RCC_PLLCmd(ENABLE);
	// wait until the PLL is ready
	while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);
	// 3. Set system clock divders
	//RCC_USBCLKConfig(RCC_USBCLKSource_PLLCLK_1Div5);
	//RCC_ADCCLKConfig(RCC_PCLK2_Div8);
	//RCC_PCLK2Config(RCC_HCLK_Div1);
	//RCC_PCLK1Config(RCC_HCLK_Div2);
	//RCC_HCLKConfig(RCC_SYSCLK_Div1);
	// Flash 1 wait state
	//*(vu32 *)0x40022000 = 0x12;
	// 5. Clock system from PLL
	RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
}

// Needed as a destination for errors
void assert_failed(const uint8_t* file, const uint8_t* function, uint32_t line)
{
  while (1);
}
