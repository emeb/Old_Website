readme.txt - Info about this directory
--------------------------------------

This directory is a 'blinky LED' test app for the STM32F100C4T6B board based
on a combination of the following:

* Martin Thomas' STM32 c++ project base:

http://gandalf.arubi.uni-kl.de/avr_projects/arm_projects/index.html#cm3_cpp1

* Adam Schabtach's mods for his own development environment which consisted
mainly of ripping the C++ support out of Martin Thomas' project and using
the baseline startup code, along with RAISONANCE / Lanchon's loader scripts.

* A simple 'LED blink' app I grabbed - probably from the Olimex website.

It's been thoroughly modified to work on the 'Value Line' STM32 device. A few
things to note:

- You'll need OpenOCD >= 0.5.0 for support of the Value Line devices. On Ubuntu
this means you'll have to download the source from the git repo and configure &
compile locally since the most recent pkg is 0.4.0.

- You'll need a copy of the STM32 API libraries located in an adjacent directory.
More about how to get this set up elsewhere...

- I'm using the CodeSourcery free ARM toolchain. If you're using a
different toolchain then you will have to hack on the makefile to change the
prefix.

- the openocd flash script used by 'make program' invokes my customized
board script "emeb_stm32f100_breakout.cfg" which will need to be accessible in
the /usr/local/share/openocd/scripts/board/ directory. Copy it there.

- I've included a couple other openocd scripts for checking the JTAG connection and
verifying a correct flash download.
