/*
 * Blinky Lights for STM32F030
 * E. Brombaugh 03-30-2015
 */

#include <string.h>
#include <stdlib.h>
#include "stm32f0xx.h"
#include "led.h"
#include "systick.h"
#include "oled.h"
#include "adc.h"

int i2a(char *s, int n){
    div_t qr;
    int pos;

    if(n == 0) return 0;

    qr = div(n, 10);
    pos = i2a(s, qr.quot);
    s[pos] = qr.rem + '0';
	
    return pos + 1;
}

char* my_itoa(char *output_buff, int num){
    char *p = output_buff;
    if(num < 0){
        *p++ = '-';
        num *= -1;
    } else if(num == 0)
        *p++ = '0';
	
    p[i2a(p, num)]='\0';
    return output_buff;
}

int main(void)
{
	uint8_t *oled_buffer;
	char number_str[16];
	uint16_t i;
	int8_t e;
	
	/* initialize the hardware */
	led_init();
	systick_init();
	systick_delayms(10);	// let OLED power up a bit before initializing
	oled_init();
	adc_init();
	
#if 0
	/* simple text */
	oled_drawstr(0,0, "This is a test", 1);
	oled_drawstr(0,8, "of the emergency", 1);
	oled_drawstr(0,16, "broadcasting", 1);
	oled_drawstr(0,24, "system", 1);
	oled_refresh();
#endif
	
#if 0
	/* full-screen concentric rects */
	oled_clear(0);
	oled_refresh();
	for(i=0;i<OLED_H/2;i++)
	{
		oled_xorrect(i, i, OLED_W-2*i, OLED_H-2*i);
		oled_refresh();
	}
#endif

	/* Loop forever */
	i=e=0;
	while(1)
	{
		/* wait a bit & flash light */
		systick_delayms(10);
		led_on(LED1);
		
		systick_delayms(10);
		led_off(LED1);
		
#if 0
		/* concentric rects */
		if(i==0)
			oled_drawrect(0, 0, OLED_W, OLED_H, 1);
		else
			oled_xorrect(i, i, OLED_W-2*i, OLED_H-2*i);
		
		oled_refresh();
		i++;
		if(i==16)
			i=0;
#endif
#if 1
		/* displaying large font */
		i = (10*adc_get_data(0))/409;	// get adc value scaled to %
		my_itoa(number_str, i);
		strcat(number_str, "   ");
		oled_drawbitfont(0, 0, number_str);
		
		e += systick_get_encoder();
		e = e > 9 ? 0 : e;
		e = e < 0 ? 9 : e;
		my_itoa(number_str, e);
		//my_itoa(number_str, systick_get_button());
		strcat(number_str, " ");
		oled_drawbitfont(48, 0, number_str);
		oled_refresh();
		//i++;	// counting
#endif
	}
}
