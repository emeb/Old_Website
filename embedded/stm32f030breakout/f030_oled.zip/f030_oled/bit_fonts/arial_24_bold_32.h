#ifndef arial_24_bold_32H
#define arial_24_bold_32H

#ifndef SMfgTypes
#define SMfgTypes

/*======= binar input =======*/
#define b2b(b7,b6,b5,b4,b3,b2,b1,b0) ((unsigned char)((b7u)*128u + (b6u)*64u + (b5u)*32u + (b4u)*16u + (b3u)*8u + (b2u)*4u + (b1u)*2u + (b0u)))

/*============================================================================*/
/* You have to manualy set correct types TCDATA and TCLISTP                   */
/* for your platform and compiler.                                            */
/*                                                                            */
/* Keil C51 example:                                                          */
/* Character data (TCDATA) are stored in code memory,                         */
/* array of pointers to characters (TCLISTP) is stored in code memory         */
/* and pointers are pointing into code memory.                                */
/*                                                                            */
/* typedef unsigned char code TCDATA;                                         */
/* typedef TCDATA * code TCLISTP;                                             */
/*============================================================================*/

typedef unsigned char TCDATA;
typedef TCDATA* TCLISTP;

#endif

/*======= Character pointers table =======*/
extern TCLISTP arial_24_bold_32[256];

/*======= Characters data =======*/
TCDATA arial_24_bold_32_ssp[17];
TCDATA arial_24_bold_32_sexc[17];
TCDATA arial_24_bold_32_sdq[49];
TCDATA arial_24_bold_32_sfr[73];
TCDATA arial_24_bold_32_sdlr[61];
TCDATA arial_24_bold_32_sprc[93];
TCDATA arial_24_bold_32_sand[85];
TCDATA arial_24_bold_32_sap[17];
TCDATA arial_24_bold_32_sprl[33];
TCDATA arial_24_bold_32_sprr[33];
TCDATA arial_24_bold_32_sstr[45];
TCDATA arial_24_bold_32_spls[65];
TCDATA arial_24_bold_32_scmm[17];
TCDATA arial_24_bold_32_smin[37];
TCDATA arial_24_bold_32_sssp[17];
TCDATA arial_24_bold_32_sslh[37];
TCDATA arial_24_bold_32_n0[65];
TCDATA arial_24_bold_32_n1[53];
TCDATA arial_24_bold_32_n2[65];
TCDATA arial_24_bold_32_n3[65];
TCDATA arial_24_bold_32_n4[69];
TCDATA arial_24_bold_32_n5[69];
TCDATA arial_24_bold_32_n6[65];
TCDATA arial_24_bold_32_n7[65];
TCDATA arial_24_bold_32_n8[65];
TCDATA arial_24_bold_32_n9[65];
TCDATA arial_24_bold_32_scln[17];
TCDATA arial_24_bold_32_ssmc[17];
TCDATA arial_24_bold_32_sbrl[65];
TCDATA arial_24_bold_32_seql[65];
TCDATA arial_24_bold_32_sbrr[65];
TCDATA arial_24_bold_32_sqst[69];
TCDATA arial_24_bold_32_szvn[121];
TCDATA arial_24_bold_32_UA[93];
TCDATA arial_24_bold_32_UB[77];
TCDATA arial_24_bold_32_UC[81];
TCDATA arial_24_bold_32_UD[81];
TCDATA arial_24_bold_32_UE[69];
TCDATA arial_24_bold_32_UF[65];
TCDATA arial_24_bold_32_UG[89];
TCDATA arial_24_bold_32_UH[73];
TCDATA arial_24_bold_32_UI[17];
TCDATA arial_24_bold_32_UJ[57];
TCDATA arial_24_bold_32_UK[81];
TCDATA arial_24_bold_32_UL[69];
TCDATA arial_24_bold_32_UM[93];
TCDATA arial_24_bold_32_UN[73];
TCDATA arial_24_bold_32_UO[89];
TCDATA arial_24_bold_32_UP[69];
TCDATA arial_24_bold_32_UQ[93];
TCDATA arial_24_bold_32_UR[81];
TCDATA arial_24_bold_32_US[73];
TCDATA arial_24_bold_32_UT[73];
TCDATA arial_24_bold_32_UU[73];
TCDATA arial_24_bold_32_UV[85];
TCDATA arial_24_bold_32_UW[125];
TCDATA arial_24_bold_32_UX[77];
TCDATA arial_24_bold_32_UY[81];
TCDATA arial_24_bold_32_UZ[77];
TCDATA arial_24_bold_32_sbl[33];
TCDATA arial_24_bold_32_sbsl[37];
TCDATA arial_24_bold_32_sbr[33];
TCDATA arial_24_bold_32_ssqr[65];
TCDATA arial_24_bold_32_sul[129];
TCDATA arial_24_bold_32_shc[29];
TCDATA arial_24_bold_32_la[65];
TCDATA arial_24_bold_32_lb[65];
TCDATA arial_24_bold_32_lc[65];
TCDATA arial_24_bold_32_ld[65];
TCDATA arial_24_bold_32_le[65];
TCDATA arial_24_bold_32_lf[41];
TCDATA arial_24_bold_32_lg[65];
TCDATA arial_24_bold_32_lh[61];
TCDATA arial_24_bold_32_li[17];
TCDATA arial_24_bold_32_lj[17];
TCDATA arial_24_bold_32_lk[57];
TCDATA arial_24_bold_32_ll[17];
TCDATA arial_24_bold_32_lm[97];
TCDATA arial_24_bold_32_ln[61];
TCDATA arial_24_bold_32_lo[69];
TCDATA arial_24_bold_32_lp[65];
TCDATA arial_24_bold_32_lq[65];
TCDATA arial_24_bold_32_lr[41];
TCDATA arial_24_bold_32_ls[61];
TCDATA arial_24_bold_32_lt[37];
TCDATA arial_24_bold_32_lu[61];
TCDATA arial_24_bold_32_lv[61];
TCDATA arial_24_bold_32_lw[101];
TCDATA arial_24_bold_32_lx[65];
TCDATA arial_24_bold_32_ly[61];
TCDATA arial_24_bold_32_lz[57];
TCDATA arial_24_bold_32_spsl[41];
TCDATA arial_24_bold_32_svli[13];
TCDATA arial_24_bold_32_spsh[41];
TCDATA arial_24_bold_32_svwe[69];
TCDATA arial_24_bold_32_c127[37];
TCDATA arial_24_bold_32_blank[33];

#endif
